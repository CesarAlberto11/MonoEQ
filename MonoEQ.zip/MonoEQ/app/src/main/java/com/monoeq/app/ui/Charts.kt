package com.monoeq.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.monoeq.app.audio.SpectrumFrame
import com.monoeq.app.domain.ResponseCurve
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

private const val F_MIN = 20f
private const val F_MAX = 20000f
private val LOG_MIN = log10(F_MIN)
private val LOG_RANGE = log10(F_MAX) - log10(F_MIN)

fun xForFreq(f: Float, width: Float): Float = ((log10(f.coerceIn(F_MIN, F_MAX)) - LOG_MIN) / LOG_RANGE) * width

fun DrawScope.drawFreqGrid(lineColor: Color, centerLine: Boolean) {
    listOf(100f, 1000f, 10000f).forEach { f ->
        val x = xForFreq(f, size.width)
        drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), 1f)
    }
    if (centerLine) drawLine(lineColor, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1f)
}

fun DrawScope.drawEqCurve(freqs: FloatArray, gains: FloatArray, color: Color, widthPx: Float, rangeDb: Float, dashed: Boolean) {
    if (freqs.isEmpty()) return
    val path = Path()
    val points = ResponseCurve.logSpaced(120)
    points.forEachIndexed { i, f ->
        val g = ResponseCurve.gainAt(freqs, gains, f).coerceIn(-rangeDb, rangeDb)
        val x = xForFreq(f, size.width)
        val y = size.height / 2f - (g / rangeDb) * (size.height / 2f)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    drawPath(path, color, style = Stroke(width = widthPx, pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(14f, 10f)) else null))
}

/** Curva de respuesta construida con los parámetros que el motor tiene aplicados (o una vista previa si está apagado). */
@Composable
fun EqCurveView(freqs: FloatArray, gains: FloatArray, preview: Boolean, modifier: Modifier = Modifier) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    val line = if (preview) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        drawFreqGrid(grid, centerLine = true)
        drawEqCurve(freqs, gains, line, 3.dp.toPx(), 15f, dashed = preview)
        freqs.forEachIndexed { i, f ->
            val y = size.height / 2f - (gains[i].coerceIn(-15f, 15f) / 15f) * (size.height / 2f)
            drawCircle(line, 3.dp.toPx(), Offset(xForFreq(f, size.width), y))
        }
    }
}

@Composable
fun SpectrumBars(bars: FloatArray, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.primary
    val base = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        val n = bars.size
        val gap = 3.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        bars.forEachIndexed { i, v ->
            val x = i * (bw + gap)
            drawRect(base, Offset(x, size.height - 2.dp.toPx()), Size(bw, 2.dp.toPx()))
            val h = (v.coerceIn(0f, 1f) * size.height).coerceAtLeast(0f)
            if (h > 0f) drawRect(color, Offset(x, size.height - h), Size(bw, h))
        }
    }
}

/** Espectro real (línea clara) con la curva del ecualizador superpuesta (línea discontinua). */
@Composable
fun SpectrumCurve(frame: SpectrumFrame, eqFreqs: FloatArray, eqGains: FloatArray, modifier: Modifier = Modifier) {
    val spectrum = MaterialTheme.colorScheme.primary
    val eq = MaterialTheme.colorScheme.outline
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        drawFreqGrid(grid, centerLine = false)
        val path = Path()
        val points = ResponseCurve.logSpaced(140, 30f, min(16000f, frame.binHz * frame.spectrumDb.size))
        points.forEachIndexed { i, f ->
            val k = (f / frame.binHz).toInt().coerceIn(1, frame.spectrumDb.size - 1)
            var db = frame.spectrumDb[k]
            if (k + 1 < frame.spectrumDb.size) db = max(db, frame.spectrumDb[k + 1])
            val x = xForFreq(f, size.width)
            val y = size.height * (1f - ((db + 60f) / 60f).coerceIn(0f, 1f))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, spectrum, style = Stroke(width = 2.dp.toPx()))
        drawEqCurve(eqFreqs, eqGains, eq, 1.5.dp.toPx(), 15f, dashed = true)
    }
}

/** Medidor RMS y pico en dBFS (de -60 a 0). */
@Composable
fun LevelMeter(rmsDb: Float, peakDb: Float, peakHoldDb: Float, modifier: Modifier = Modifier) {
    val fill = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.outlineVariant
    val hold = MaterialTheme.colorScheme.onSurface
    fun frac(db: Float) = ((db + 60f) / 60f).coerceIn(0f, 1f)
    Canvas(modifier) {
        val barH = size.height / 2f - 6.dp.toPx()
        listOf(rmsDb to 0f, peakDb to (barH + 12.dp.toPx())).forEach { (db, top) ->
            drawRect(track, Offset(0f, top), Size(size.width, barH))
            drawRect(fill, Offset(0f, top), Size(size.width * frac(db), barH))
        }
        val hx = size.width * frac(peakHoldDb)
        drawLine(hold, Offset(hx, barH + 12.dp.toPx()), Offset(hx, size.height), 2.dp.toPx())
        listOf(-48f, -36f, -24f, -12f, -6f).forEach { t ->
            val x = size.width * frac(t)
            drawLine(Color.Black.copy(alpha = 0.6f), Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
        }
    }
}
