package com.monoeq.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AudioController
import com.monoeq.app.domain.ReverbPreset
import kotlin.math.roundToInt

private fun pct(v: Float) = "${(v * 100f).roundToInt()} %"

@Composable
fun EffectsScreen(controller: AudioController) {
    val params by controller.params.collectAsStateWithLifecycle()
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val bypass by controller.userBypass.collectAsStateWithLifecycle()
    val caps = engine.capabilities

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader("Efectos", "Solo se muestran efectos que Android puede aplicar")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = bypass,
                onClick = { controller.setBypass(!bypass) },
                label = { Text("Comparar con el original") },
                enabled = engine.running,
            )
        }
        if (caps == null) InfoText("La compatibilidad real se comprueba al activar el motor o con el autodiagnóstico (Ajustes → Diagnóstico).")

        SectionCard("Graves y voces") {
            ValueSlider("Refuerzo de graves", pct(params.bassBoost), params.bassBoost, { v -> controller.updateParams { it.copy(bassBoost = v) } }, 0f..1f)
            if (caps?.bassBoostNative == false) InfoText("Sin BassBoost nativo en este dispositivo: se emula subiendo hasta 6 dB los graves del ecualizador.")
            ValueSlider("Claridad vocal", pct(params.vocalClarity), params.vocalClarity, { v -> controller.updateParams { it.copy(vocalClarity = v) } }, 0f..1f)
            InfoText("La claridad vocal se implementa con la curva del ecualizador: realza 2–4 kHz y recorta suavemente cerca de 300 Hz.")
        }

        SectionCard("Espacio") {
            ValueSlider(
                "Amplitud estéreo", pct(params.stereoWidth), params.stereoWidth,
                { v -> controller.updateParams { it.copy(stereoWidth = v) } }, 0f..1f,
                enabled = caps?.virtualizer != false,
            )
            InfoText(
                "Usa el Virtualizer de Android (ensanchado espacial). No es sonido 3D posicional real: " +
                    "Android no permite que una APK active el Spatializer del sistema."
            )
            if (caps?.virtualizer == false) InfoText("Este dispositivo no ofrece Virtualizer.")
            Text("Reverberación", style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReverbPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = params.reverb == preset,
                        onClick = { controller.updateParams { it.copy(reverb = preset) } },
                        label = { Text(preset.label) },
                        enabled = caps?.reverb != false,
                    )
                }
            }
            if (caps?.reverb == false) InfoText("Este dispositivo no ofrece reverberación por preajuste.")
            else InfoText("Android solo permite elegir preajustes. En algunos dispositivos la reverberación se acepta pero casi no se oye.")
        }

        SectionCard("Dinámica") {
            SwitchRow(
                "Limitador", "Evita el clipping cuando subes ganancia o bandas.",
                params.limiterEnabled, onChange = { v -> controller.updateParams { it.copy(limiterEnabled = v) } },
                enabled = caps?.limiter != false,
            )
            if (params.limiterEnabled) {
                ValueSlider(
                    "Umbral", formatDb(params.limiterThresholdDb), params.limiterThresholdDb,
                    { v -> controller.updateParams { it.copy(limiterThresholdDb = v) } }, -24f..0f,
                )
            }
            if (caps?.limiter == false) InfoText("El limitador requiere DynamicsProcessing (Android 9+), que este dispositivo no ofrece.")
        }
    }
}
