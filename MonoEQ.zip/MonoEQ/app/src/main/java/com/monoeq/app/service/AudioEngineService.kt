package com.monoeq.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.monoeq.app.MainActivity
import com.monoeq.app.MonoEqApp
import com.monoeq.app.R
import com.monoeq.app.audio.AudioController
import com.monoeq.app.audio.ChainKind
import com.monoeq.app.audio.EngineState
import com.monoeq.app.i18n.AppStrings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Servicio en primer plano. Mantiene vivo el proceso para que el motor reciba las sesiones de audio
 * que anuncian las apps. Estar en primer plano NO da acceso al audio de otras apps por sí mismo.
 */
class AudioEngineService : Service() {
    private lateinit var controller: AudioController
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var receiverRegistered = false

    private val sessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEffect.ERROR_BAD_VALUE)
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> controller.onSessionOpened(
                    session,
                    intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME),
                    intent.getIntExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC),
                )
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> controller.onSessionClosed(session)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        controller = (application as MonoEqApp).container.controller
        val initial = controller.strings.value
        createChannel(initial)
        goForeground(buildNotification(initial, initial.notifStarting, paused = false))

        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        // Las apps que anuncian la sesión son externas: el receptor debe estar exportado.
        ContextCompat.registerReceiver(this, sessionReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
        receiverRegistered = true

        controller.onServiceCreated(this)

        val manager = getSystemService(NotificationManager::class.java)
        scope.launch {
            combine(controller.engine.state, controller.effectiveBypass, controller.strings) { state, paused, t -> Triple(state, paused, t) }
                .collect { (state, paused, t) ->
                    createChannel(t)
                    manager.notify(NOTIFICATION_ID, buildNotification(t, statusText(t, state, paused), paused))
                }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                controller.persistEngineEnabled(false)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_PAUSE -> controller.setBypass(!controller.userBypass.value)
        }
        val t = controller.strings.value
        val paused = controller.effectiveBypass.value
        goForeground(buildNotification(t, statusText(t, controller.engine.state.value, paused), paused))
        return START_STICKY
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(sessionReceiver) } catch (e: Exception) { Log.w(TAG, "receiver", e) }
            receiverRegistered = false
        }
        scope.cancel()
        controller.onServiceDestroyed()
        super.onDestroy()
    }

    private fun statusText(t: AppStrings, state: EngineState, paused: Boolean): String {
        val sessions = state.chains.count { it.kind != ChainKind.TEST && it.backend != com.monoeq.app.audio.EqBackend.NONE }
        return when {
            !state.running -> t.notifStarting
            paused -> t.notifPaused
            state.suspended -> t.notifStandby
            sessions == 0 -> t.notifWaiting
            else -> t.notifActive(sessions)
        }
    }

    private fun createChannel(t: AppStrings) {
        val channel = NotificationChannel(CHANNEL_ID, t.channelName, NotificationManager.IMPORTANCE_LOW)
        channel.description = t.channelDescription
        channel.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun goForeground(notification: Notification) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun buildNotification(t: AppStrings, text: String, paused: Boolean): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags)
        val toggle = PendingIntent.getService(this, 1, Intent(this, AudioEngineService::class.java).setAction(ACTION_TOGGLE_PAUSE), flags)
        val stop = PendingIntent.getService(this, 2, Intent(this, AudioEngineService::class.java).setAction(ACTION_STOP), flags)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_eq)
            .setContentTitle("MONO EQ")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, if (paused) t.notifResume else t.notifPause, toggle)
            .addAction(0, t.notifStop, stop)
            .build()
    }

    companion object {
        const val ACTION_START = "com.monoeq.app.action.START"
        const val ACTION_STOP = "com.monoeq.app.action.STOP"
        const val ACTION_TOGGLE_PAUSE = "com.monoeq.app.action.TOGGLE_PAUSE"
        private const val CHANNEL_ID = "mono_eq_engine"
        private const val NOTIFICATION_ID = 1001
        private const val TAG = "MonoEqService"
    }
}

object ServiceLauncher {
    fun start(context: Context): Boolean = try {
        ContextCompat.startForegroundService(
            context,
            Intent(context, AudioEngineService::class.java).setAction(AudioEngineService.ACTION_START)
        )
        true
    } catch (e: Exception) {
        // Android 12+ puede rechazar el arranque desde segundo plano.
        Log.w("MonoEqService", "No se pudo iniciar el servicio", e)
        false
    }

    fun stop(context: Context) {
        context.stopService(Intent(context, AudioEngineService::class.java))
    }
}
