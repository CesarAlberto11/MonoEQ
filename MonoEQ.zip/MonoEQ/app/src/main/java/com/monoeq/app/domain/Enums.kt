package com.monoeq.app.domain

enum class AppLanguage(val code: String, val nativeName: String) {
    EN("en", "English"),
    ES("es", "Español")
}

/** Cómo se engancha el motor al audio del sistema. */
enum class CoverageMode {
    SESSIONS,
    GLOBAL,
    BOTH;

    val usesGlobal get() = this != SESSIONS
    val usesSessions get() = this != GLOBAL
}

enum class RouteType {
    SPEAKER, WIRED, USB, BLUETOOTH, UNKNOWN;

    val isExternal get() = this == WIRED || this == USB || this == BLUETOOTH
}

enum class VisualizerMode { BARS, CURVE, METER }

enum class AccentChoice(val argb: Long) {
    WHITE(0xFFFFFFFF),
    STEEL(0xFF9DB3CF),
    SAGE(0xFF9DBFA8),
    AMBER(0xFFCDB07A),
    ROSE(0xFFC9A0AF)
}

enum class ReverbPreset { OFF, SMALL_ROOM, MEDIUM_ROOM, LARGE_ROOM, MEDIUM_HALL, LARGE_HALL, PLATE }
