package com.monoeq.app

import com.monoeq.app.audio.Fft
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class FftTest {
    @Test
    fun sinePeaksAtExpectedBinWithNearFullScaleLevel() {
        val n = 1024
        val sampleRate = 44100f
        val freq = 1000f
        val x = FloatArray(n) { sin(2.0 * PI * freq * it / sampleRate).toFloat() }
        val db = Fft(n).magnitudeDbFs(x)
        val peak = db.indices.maxByOrNull { db[it] }!!
        assertEquals(freq / (sampleRate / n), peak.toFloat(), 1.5f)
        assertTrue("pico fuera de rango: ${db[peak]}", db[peak] > -3f && db[peak] < 1f)
    }

    @Test
    fun silenceStaysAtTheFloor() {
        val db = Fft(256).magnitudeDbFs(FloatArray(256))
        assertTrue(db.all { it <= -100f })
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsNonPowerOfTwo() {
        Fft(300)
    }
}
