package com.monoeq.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.monoeq.app.MonoEqApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Reinicia el motor tras encender el dispositivo o actualizar la app, solo si estaba activado. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        val appContext = context.applicationContext
        val container = (appContext as MonoEqApp).container
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val s = container.settingsRepo.settings.first()
                if (s.startOnBoot && s.engineEnabled) ServiceLauncher.start(appContext)
            } catch (e: Exception) {
                Log.w("MonoEqBoot", "Fallo al iniciar tras el arranque", e)
            } finally {
                pending.finish()
            }
        }
    }
}
