# R8 trabaja sin reglas adicionales: el proyecto no usa reflexión.
