package com.monoeq.app

import android.media.AudioManager
import android.media.audiofx.Equalizer
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.monoeq.app.audio.EqEngine
import com.monoeq.app.domain.AudioParams
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeNoException
import org.junit.Test
import org.junit.runner.RunWith

/** Pruebas de integración: requieren un dispositivo o emulador con efectos de audio. */
@RunWith(AndroidJUnit4::class)
class EffectsInstrumentedTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun equalizerCanBeCreatedOnOwnSession() {
        val session = (context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId()
        val eq = try {
            Equalizer(0, session)
        } catch (e: Exception) {
            assumeNoException("Equalizer no disponible en este dispositivo", e)
            return
        }
        try {
            assertTrue(eq.numberOfBands > 0)
        } finally {
            eq.release()
        }
    }

    @Test
    fun engineSelfTestProducesAReport() = runBlocking {
        val engine = EqEngine(context)
        engine.runSelfTest(AudioParams(bassDb = 3f))
        val state = withTimeout(5_000) { engine.state.first { it.selfTest != null } }
        assertNotNull(state.selfTest)
        assertTrue(state.selfTest!!.effects.isNotEmpty())
    }
}
