package com.monoeq.app.domain

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

/** Pesos suaves (escala logarítmica) para los controles de tono y la claridad vocal. */
object ToneCurve {
    private val LN2 = ln(2f)
    private fun oct(f: Float, ref: Float) = ln(f / ref) / LN2
    private fun smooth(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
    private fun bell(f: Float, center: Float, widthOct: Float) = 1f - smooth(abs(oct(f, center)) / widthOct)

    fun bass(f: Float) = 1f - smooth(oct(f, 125f) / 2f)
    fun mid(f: Float) = bell(f, 1000f, 2f)
    fun treble(f: Float) = smooth(oct(f, 2000f) / 2f)

    /** Realce 2–4 kHz y pequeño recorte hacia 300 Hz, en dB con claridad = 1. */
    fun clarityDb(f: Float) = 4f * bell(f, 3000f, 1.5f) - 1.5f * bell(f, 300f, 1f)

    /** Forma de la emulación de refuerzo de graves cuando el dispositivo no ofrece BassBoost. */
    fun bassBoostShape(f: Float) = 1f - smooth(oct(f, 62f) / 2f)
}

object Balance {
    /** Ganancias (izquierda, derecha) en dB para un balance de -1 (izq.) a +1 (der.). */
    fun gainsDb(balance: Float): Pair<Float, Float> {
        fun att(x: Float): Float = if (x <= 0f) 0f else (20f * log10(max(1f - x, 0.001f))).coerceAtLeast(-60f)
        return att(balance) to att(-balance)
    }
}

object ResponseCurve {
    /** Interpolación coseno en escala logarítmica entre puntos (freqs ascendentes). */
    fun gainAt(freqs: FloatArray, gains: FloatArray, f: Float): Float {
        if (freqs.isEmpty() || gains.isEmpty()) return 0f
        if (freqs.size == 1 || f <= freqs.first()) return gains.first()
        if (f >= freqs.last()) return gains[freqs.size - 1]
        var i = 0
        while (i < freqs.size - 2 && f > freqs[i + 1]) i++
        val x0 = ln(freqs[i])
        val x1 = ln(freqs[i + 1])
        val t = ((ln(f) - x0) / (x1 - x0)).coerceIn(0f, 1f)
        val s = (1f - cos(t * PI.toFloat())) / 2f
        return gains[i] + (gains[i + 1] - gains[i]) * s
    }

    fun logSpaced(points: Int, fMin: Float = 20f, fMax: Float = 20000f): FloatArray =
        FloatArray(points) { i -> fMin * (fMax / fMin).pow(i / (points - 1).toFloat()) }
}
