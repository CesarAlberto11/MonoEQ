package com.monoeq.app.ui

import androidx.compose.runtime.staticCompositionLocalOf
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.i18n.AppStrings

/** Textos del idioma activo; MonoEqRoot lo provee según los ajustes. */
val LocalStrings = staticCompositionLocalOf { AppStrings.of(AppLanguage.EN) }
