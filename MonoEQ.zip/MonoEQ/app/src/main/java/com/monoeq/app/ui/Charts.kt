package com.monoeq.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.monoeq.app.audio.SpectrumFrame
import com.monoeq.app.domain.ResponseCurve
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

private const val F_MIN = 20f
private const val F_MAX = 20000f
private val LOG_MIN = log10(F_MIN)
private val LOG_RANGE = log10(F_MAX) - log10(F_MIN)

fun xForFreq(f: Float, width: Float): Float = ((log10(f.coerceIn(F_MIN, F_MAX)) - LOG_MIN) / LOG_RANGE) * width

fun DrawScope.drawFreqGrid(lineColor: Color, centerLine: Boolean) {
    listOf(100f, 1000f, 10000f).forEach { f ->
        val x = xForFreq(f, size.width)
        drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), 1f)
    }
    if (centerLine) drawLine(lineColor, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1f)
}

fun DrawScope.drawEqCurve(freqs: FloatArray, gains: FloatArray, color: Color, widthPx: Float, rangeDb: Float, dashed: Boolean) {
    if (freqs.isEmpty()) return
    val path = Path()
    ResponseCurve.logSpaced(120).forEachIndexed { i, f ->
        val g = ResponseCurve.gainAt(freqs, gains, f).coerceIn(-rangeDb, rangeDb)
        val x = xForFreq(f, size.width)
        val y = size.height / 2f - (g / rangeDb) * (size.height / 2f)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    drawPath(path, color, style = Stroke(width = widthPx, cap = StrokeCap.Round, pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(14f, 10f)) else null))
}

/** Curva de respuesta construida con los parámetros aplicados al motor (o una vista previa si está apagado). */
@Composable
fun EqCurveView(freqs: FloatArray, gains: FloatArray, preview: Boolean, modifier: Modifier = Modifier) {
    val grid = MonoColors.Hairline
    val line = if (preview) MonoColors.MidGray else MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        drawFreqGrid(grid, centerLine = true)
        drawEqCurve(freqs, gains, line, 2.5.dp.toPx(), 15f, dashed = preview)
        freqs.forEachIndexed { i, f ->
            val y = size.height / 2f - (gains[i].coerceIn(-15f, 15f) / 15f) * (size.height / 2f)
            drawCircle(line, 3.dp.toPx(), Offset(xForFreq(f, size.width), y))
        }
    }
}

/** Barras finas con degradado gris y marcas de pico, como el espectro de la referencia. */
@Composable
fun SpectrumBars(bars: FloatArray, caps: FloatArray, modifier: Modifier = Modifier) {
    val base = MonoColors.Hairline
    val capColor = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        val n = bars.size
        val gap = 2.dp.toPx()
        val bw = ((size.width - gap * (n - 1)) / n).coerceAtLeast(1f)
        val brush = Brush.verticalGradient(listOf(Color(0xFFE2E2E6), Color(0xFF55555C)), startY = 0f, endY = size.height)
        val corner = CornerRadius(bw / 2f, bw / 2f)
        for (i in 0 until n) {
            val x = i * (bw + gap)
            drawRoundRect(base, Offset(x, size.height - 2.dp.toPx()), Size(bw, 2.dp.toPx()), corner)
            val h = bars[i].coerceIn(0f, 1f) * size.height
            if (h > 2.dp.toPx()) drawRoundRect(brush, Offset(x, size.height - h), Size(bw, h), corner)
            val capH = caps.getOrElse(i) { 0f }.coerceIn(0f, 1f) * size.height
            if (capH > 4.dp.toPx()) drawRect(capColor, Offset(x, size.height - capH - 3.dp.toPx()), Size(bw, 2.dp.toPx()))
        }
    }
}

/** Espectro real (línea clara) con la curva del ecualizador superpuesta (línea discontinua). */
@Composable
fun SpectrumCurve(frame: SpectrumFrame, eqFreqs: FloatArray, eqGains: FloatArray, modifier: Modifier = Modifier) {
    val spectrum = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        drawFreqGrid(MonoColors.Hairline, centerLine = false)
        val path = Path()
        val fTop = min(16000f, frame.binHz * frame.spectrumDb.size)
        ResponseCurve.logSpaced(140, 30f, fTop).forEachIndexed { i, f ->
            val k = (f / frame.binHz).toInt().coerceIn(1, frame.spectrumDb.size - 1)
            var db = frame.spectrumDb[k]
            if (k + 1 < frame.spectrumDb.size) db = max(db, frame.spectrumDb[k + 1])
            val x = xForFreq(f, size.width)
            val y = size.height * (1f - ((db + 72f) / 60f).coerceIn(0f, 1f))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, spectrum, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
        drawEqCurve(eqFreqs, eqGains, MonoColors.MidGray, 1.5.dp.toPx(), 15f, dashed = true)
    }
}

/** Barra horizontal de nivel en dBFS (de -60 a 0) con marca de retención opcional. */
@Composable
fun LevelBar(levelDb: Float, modifier: Modifier = Modifier, holdDb: Float? = null) {
    val fill = MaterialTheme.colorScheme.primary
    fun frac(db: Float) = ((db + 60f) / 60f).coerceIn(0f, 1f)
    Canvas(modifier) {
        val r = CornerRadius(size.height / 2f, size.height / 2f)
        drawRoundRect(Color(0xFF2E2E33), Offset.Zero, size, r)
        val w = size.width * frac(levelDb)
        if (w > 0f) drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFF55555C), fill), startX = 0f, endX = size.width), Offset.Zero, Size(w, size.height), r)
        if (holdDb != null) {
            val x = size.width * frac(holdDb)
            drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), 2.dp.toPx())
        }
    }
}
