package com.monoeq.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Random
import kotlin.math.max

/**
 * Ruido rosa a volumen moderado en una sesión de audio propia.
 * Permite oír y medir si los efectos realmente cambian el sonido, sin depender de otras apps.
 */
class TestSignalPlayer(private val context: Context) {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    @Volatile var sessionId: Int = 0
        private set

    private var thread: Thread? = null
    @Volatile private var stopFlag = false

    @Synchronized
    fun start(): Int {
        if (thread != null) return sessionId
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val session = am.generateAudioSessionId()
        val sampleRate = 44100
        val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuffer, 4096) * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setSessionId(session)
            .build()
        track.setVolume(0.3f)
        track.play()
        sessionId = session
        stopFlag = false
        _running.value = true
        thread = Thread({
            val random = Random()
            val buffer = ShortArray(2048)
            var b0 = 0f; var b1 = 0f; var b2 = 0f
            while (!stopFlag) {
                var i = 0
                while (i < buffer.size) {
                    val white = random.nextFloat() * 2f - 1f
                    b0 = 0.99765f * b0 + white * 0.0990460f
                    b1 = 0.96300f * b1 + white * 0.2965164f
                    b2 = 0.57000f * b2 + white * 1.0526913f
                    val pink = (b0 + b1 + b2 + white * 0.1848f) * 0.11f
                    val s = (pink * 0.5f * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                    buffer[i++] = s
                    buffer[i++] = s
                }
                if (track.write(buffer, 0, buffer.size) < 0) break
            }
            try { track.stop() } catch (_: Exception) { }
            track.release()
            _running.value = false
        }, "mono-eq-test-signal").also { it.start() }
        return session
    }

    @Synchronized
    fun stop() {
        stopFlag = true
        try { thread?.join(800) } catch (_: InterruptedException) { }
        thread = null
        _running.value = false
    }
}
