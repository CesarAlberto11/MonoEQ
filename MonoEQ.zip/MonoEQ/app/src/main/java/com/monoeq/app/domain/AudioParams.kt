package com.monoeq.app.domain

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

/** Todos los parámetros de sonido. Cada perfil guarda uno de estos objetos. */
data class AudioParams(
    val bands: List<Float> = List(Bands.COUNT) { 0f },
    val bassDb: Float = 0f,
    val midDb: Float = 0f,
    val trebleDb: Float = 0f,
    val preampDb: Float = 0f,
    val masterDb: Float = 0f,
    val balance: Float = 0f,
    val bassBoost: Float = 0f,
    val vocalClarity: Float = 0f,
    val stereoWidth: Float = 0f,
    val reverb: ReverbPreset = ReverbPreset.OFF,
    val limiterEnabled: Boolean = false,
    val limiterThresholdDb: Float = -3f,
    val autoHeadroom: Boolean = true,
) {
    /** Valida y recorta todos los valores. Se aplica siempre antes de enviarlos al motor o guardarlos. */
    fun sanitized(): AudioParams = copy(
        bands = List(Bands.COUNT) { i -> bands.getOrNull(i).clampOr(Bands.USER_MIN_DB, Bands.USER_MAX_DB, 0f) },
        bassDb = bassDb.clampOr(-10f, 10f, 0f),
        midDb = midDb.clampOr(-10f, 10f, 0f),
        trebleDb = trebleDb.clampOr(-10f, 10f, 0f),
        preampDb = preampDb.clampOr(-12f, 12f, 0f),
        masterDb = masterDb.clampOr(-12f, 12f, 0f),
        balance = balance.clampOr(-1f, 1f, 0f),
        bassBoost = bassBoost.clampOr(0f, 1f, 0f),
        vocalClarity = vocalClarity.clampOr(0f, 1f, 0f),
        stereoWidth = stereoWidth.clampOr(0f, 1f, 0f),
        limiterThresholdDb = limiterThresholdDb.clampOr(-24f, 0f, -3f),
    )

    /**
     * Ganancia final por banda (dB) incluyendo tono, claridad vocal y, si [emulateBass], el refuerzo de graves.
     * Es exactamente lo que se envía al motor de efectos.
     */
    fun effectiveBandGains(emulateBass: Boolean): FloatArray = FloatArray(Bands.COUNT) { i ->
        val f = Bands.centersHz[i]
        var g = bands.getOrElse(i) { 0f }
        g += bassDb * ToneCurve.bass(f) + midDb * ToneCurve.mid(f) + trebleDb * ToneCurve.treble(f)
        g += vocalClarity * ToneCurve.clarityDb(f)
        if (emulateBass) g += bassBoost * 6f * ToneCurve.bassBoostShape(f)
        g.coerceIn(-Bands.ENGINE_LIMIT_DB, Bands.ENGINE_LIMIT_DB)
    }

    /** Preamplificación efectiva: la del usuario más el margen automático contra clipping. */
    fun effectivePreampDb(gains: FloatArray): Float {
        val headroom = if (autoHeadroom) -max(0f, gains.maxOrNull() ?: 0f) else 0f
        return (preampDb + headroom).coerceIn(-30f, 12f)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("bands", JSONArray().also { a -> bands.forEach { a.put(it.toDouble()) } })
        put("bassDb", bassDb.toDouble())
        put("midDb", midDb.toDouble())
        put("trebleDb", trebleDb.toDouble())
        put("preampDb", preampDb.toDouble())
        put("masterDb", masterDb.toDouble())
        put("balance", balance.toDouble())
        put("bassBoost", bassBoost.toDouble())
        put("vocalClarity", vocalClarity.toDouble())
        put("stereoWidth", stereoWidth.toDouble())
        put("reverb", reverb.name)
        put("limiterEnabled", limiterEnabled)
        put("limiterThresholdDb", limiterThresholdDb.toDouble())
        put("autoHeadroom", autoHeadroom)
    }

    companion object {
        fun fromJson(o: JSONObject): AudioParams {
            val arr = o.optJSONArray("bands")
            fun f(key: String, def: Float = 0f) = o.optDouble(key, def.toDouble()).toFloat()
            return AudioParams(
                bands = List(Bands.COUNT) { i -> arr?.optDouble(i, 0.0)?.toFloat() ?: 0f },
                bassDb = f("bassDb"), midDb = f("midDb"), trebleDb = f("trebleDb"),
                preampDb = f("preampDb"), masterDb = f("masterDb"), balance = f("balance"),
                bassBoost = f("bassBoost"), vocalClarity = f("vocalClarity"), stereoWidth = f("stereoWidth"),
                reverb = ReverbPreset.entries.firstOrNull { it.name == o.optString("reverb") } ?: ReverbPreset.OFF,
                limiterEnabled = o.optBoolean("limiterEnabled", false),
                limiterThresholdDb = f("limiterThresholdDb", -3f),
                autoHeadroom = o.optBoolean("autoHeadroom", true),
            ).sanitized()
        }
    }
}

private fun Float?.clampOr(min: Float, max: Float, def: Float): Float {
    val v = this ?: def
    return if (v.isNaN() || v.isInfinite()) def else v.coerceIn(min, max)
}
