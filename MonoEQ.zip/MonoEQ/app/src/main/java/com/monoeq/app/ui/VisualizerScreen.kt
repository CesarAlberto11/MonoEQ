package com.monoeq.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AnalyzerStatus
import com.monoeq.app.audio.AudioController
import com.monoeq.app.audio.SourceKind
import com.monoeq.app.audio.SpectrumFrame
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.Bands
import com.monoeq.app.domain.VisualizerMode
import kotlin.math.roundToInt

@Composable
fun VisualizerScreen(controller: AudioController, settings: AppSettings) {
    val t = LocalStrings.current
    val ctx = LocalContext.current
    val frame by controller.analyzer.frame.collectAsStateWithLifecycle()
    val status by controller.analyzer.status.collectAsStateWithLifecycle()
    val serviceActive by controller.serviceActive.collectAsStateWithLifecycle()
    val sessions by controller.sessions.collectAsStateWithLifecycle()
    val testRunning by controller.testSignal.running.collectAsStateWithLifecycle()
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val params by controller.params.collectAsStateWithLifecycle()

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    var source by rememberSaveable { mutableStateOf<Int?>(null) }
    var peakHold by remember { mutableFloatStateOf(-60f) }

    // Fuente automática: señal de prueba, si no la última sesión anunciada por una app, si no la mezcla global (0).
    val target = source ?: (if (testRunning) controller.testSignal.sessionId else sessions.lastOrNull()?.sessionId ?: 0)

    // El análisis solo corre con esta pantalla visible (ahorra batería) y solo se reinicia si cambia la fuente.
    LifecycleResumeEffect(target, hasPermission, serviceActive) {
        if (hasPermission && serviceActive) controller.startSpectrum(target)
        onPauseOrDispose { controller.stopSpectrum() }
    }
    LaunchedEffect(frame) {
        val f = frame
        peakHold = if (f != null && f.peakDb > peakHold) f.peakDb else (peakHold - 1.5f).coerceAtLeast(-60f)
    }

    val eqFreqs = if (engine.appliedBands.isEmpty()) Bands.centersHz else engine.appliedBands.map { it.freqHz }.toFloatArray()
    val eqGains = if (engine.appliedBands.isEmpty()) params.effectiveBandGains(false) else engine.appliedBands.map { it.gainDb }.toFloatArray()
    val f = frame
    val live = f != null && f.hasSignal && hasPermission && serviceActive && status !is AnalyzerStatus.Failed

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader(t.vizTitle, t.vizSubtitle)

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VisualizerMode.entries.forEach { m ->
                PillButton(t.vizModeName(m), settings.visualizerMode == m, { controller.updateSettings { it.copy(visualizerMode = m) } })
            }
        }

        MonoCard {
            Box(Modifier.fillMaxWidth().height(200.dp)) {
                when {
                    !serviceActive -> Placeholder(t.vizNeedsEngine)
                    !hasPermission -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(t.vizPermissionText, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MonoColors.MidGray)
                        Spacer(Modifier.height(12.dp))
                        PillButton(t.vizGrantPermission, true, { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) })
                    }
                    status is AnalyzerStatus.Failed -> Placeholder(t.vizFailed((status as AnalyzerStatus.Failed).reason))
                    f == null || !live -> Placeholder(t.vizNoSignal)
                    else -> when (settings.visualizerMode) {
                        VisualizerMode.BARS -> SpectrumBars(f.bars, f.caps, Modifier.fillMaxSize().padding(top = 18.dp))
                        VisualizerMode.CURVE -> SpectrumCurve(f, eqFreqs, eqGains, Modifier.fillMaxSize().padding(top = 18.dp))
                        VisualizerMode.METER -> MeterBody(t.vizRms, t.vizPeak, f, peakHold)
                    }
                }
                CapsLabel(t.vizLive, Modifier.align(Alignment.TopStart))
                if (live && settings.visualizerMode == VisualizerMode.CURVE) {
                    CapsLabel(t.vizLegend, Modifier.align(Alignment.TopEnd))
                }
            }
            if (settings.visualizerMode == VisualizerMode.CURVE) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { InfoText("20 Hz"); InfoText("20 kHz") }
            } else if (settings.visualizerMode == VisualizerMode.BARS) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { InfoText("30 Hz"); InfoText("16 kHz") }
            }

            // Franja de nivel de entrada: ocupa siempre el mismo espacio para que el diseño no salte.
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    CapsLabel(t.vizInputLevel, Modifier.weight(1f))
                    Text(
                        if (live && f != null) "${f.peakDb.roundToInt()} dBFS" else "— dBFS",
                        style = MonoStyle.caps, color = MonoColors.LightGray, maxLines = 1,
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        t.vizClip.uppercase(), style = MonoStyle.caps, maxLines = 1,
                        color = if (live && f != null && f.clipping) Color(0xFFE29A9A) else MonoColors.Hairline,
                    )
                }
                LevelBar(if (live && f != null) f.peakDb else -60f, Modifier.fillMaxWidth().height(6.dp), if (live) peakHold else null)
            }
        }

        MonoCard(title = t.cardSource) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton(t.srcAuto, source == null, { source = null })
                controller.spectrumSources().forEach { src ->
                    val name = when (src.kind) {
                        SourceKind.GLOBAL -> t.srcGlobal
                        SourceKind.TEST -> t.srcTest
                        SourceKind.APP -> src.label
                    }
                    PillButton(name, source == src.sessionId, { source = src.sessionId })
                }
            }
            InfoText(t.srcHint)
            PillButton(
                if (testRunning) t.testStop else t.testStart,
                testRunning,
                { if (testRunning) controller.stopTest() else controller.startTest(withEffects = true) },
                enabled = serviceActive,
            )
            MonoSlider(
                t.vizSmoothing, "${(settings.smoothing * 100f).roundToInt()} %", settings.smoothing,
                { v -> controller.updateSettings { it.copy(smoothing = v) } }, 0f..0.95f,
            )
            InfoText(t.vizResolutionNote)
        }
    }
}

@Composable
private fun MeterBody(rmsLabel: String, peakLabel: String, f: SpectrumFrame, peakHold: Float) {
    Column(Modifier.fillMaxSize().padding(top = 18.dp), verticalArrangement = Arrangement.Center) {
        Row(Modifier.fillMaxWidth()) {
            CapsLabel(rmsLabel, Modifier.weight(1f)); Text("${f.rmsDb.roundToInt()} dBFS", style = MonoStyle.caps, color = MonoColors.LightGray)
        }
        Spacer(Modifier.height(6.dp))
        LevelBar(f.rmsDb, Modifier.fillMaxWidth().height(12.dp))
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth()) {
            CapsLabel(peakLabel, Modifier.weight(1f)); Text("${f.peakDb.roundToInt()} dBFS", style = MonoStyle.caps, color = MonoColors.LightGray)
        }
        Spacer(Modifier.height(6.dp))
        LevelBar(f.peakDb, Modifier.fillMaxWidth().height(12.dp), peakHold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            InfoText("-60"); InfoText("-36"); InfoText("-12"); InfoText("0")
        }
    }
}

@Composable
private fun Placeholder(text: String) {
    Box(Modifier.fillMaxSize().padding(top = 18.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MonoColors.MidGray)
    }
}
