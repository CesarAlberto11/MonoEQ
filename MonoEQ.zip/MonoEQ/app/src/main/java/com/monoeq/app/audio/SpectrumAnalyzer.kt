package com.monoeq.app.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

class SpectrumFrame(
    /** 0..1 por barra (32 barras logarítmicas, -60..0 dBFS). */
    val bars: FloatArray,
    /** Espectro completo en dBFS por bin. */
    val spectrumDb: FloatArray,
    val binHz: Float,
    val peakDb: Float,
    val rmsDb: Float,
    val clipping: Boolean,
    val hasSignal: Boolean,
)

sealed interface AnalyzerStatus {
    data object Idle : AnalyzerStatus
    data object NoPermission : AnalyzerStatus
    data class Running(val sessionId: Int) : AnalyzerStatus
    data class Failed(val reason: String) : AnalyzerStatus
}

/**
 * Espectro REAL de la señal de una sesión mediante android.media.audiofx.Visualizer.
 * Limitaciones: resolución de 8 bits, requiere RECORD_AUDIO (aunque no graba el micrófono)
 * y muchas apps o la sesión global devuelven silencio. Nunca se inventan datos.
 */
class SpectrumAnalyzer {
    private val _frame = MutableStateFlow<SpectrumFrame?>(null)
    val frame: StateFlow<SpectrumFrame?> = _frame.asStateFlow()
    private val _status = MutableStateFlow<AnalyzerStatus>(AnalyzerStatus.Idle)
    val status: StateFlow<AnalyzerStatus> = _status.asStateFlow()

    @Volatile var smoothing: Float = 0.6f

    private var visualizer: Visualizer? = null
    private var previousBars = FloatArray(BAR_COUNT)

    @Synchronized
    fun start(context: Context, sessionId: Int) {
        stop()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _status.value = AnalyzerStatus.NoPermission
            return
        }
        try {
            val v = Visualizer(sessionId)
            v.setEnabled(false)
            val sizes = Visualizer.getCaptureSizeRange()
            v.setCaptureSize(sizes[1])
            val rate = min(Visualizer.getMaxCaptureRate(), 20_000)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                    if (waveform != null) process(waveform, samplingRate / 1000)
                }
                override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) = Unit
            }, rate, true, false)
            v.setEnabled(true)
            visualizer = v
            previousBars = FloatArray(BAR_COUNT)
            _status.value = AnalyzerStatus.Running(sessionId)
        } catch (e: Exception) {
            _status.value = AnalyzerStatus.Failed("${e.javaClass.simpleName}: ${e.message ?: "sin detalle"}")
            releaseVisualizer()
        }
    }

    @Synchronized
    fun stop() {
        releaseVisualizer()
        _frame.value = null
        if (_status.value !is AnalyzerStatus.Failed && _status.value !is AnalyzerStatus.NoPermission) {
            _status.value = AnalyzerStatus.Idle
        }
    }

    private fun releaseVisualizer() {
        val v = visualizer ?: return
        visualizer = null
        try { v.setEnabled(false) } catch (_: Exception) { }
        try { v.release() } catch (_: Exception) { }
    }

    private var fft: Fft? = null

    private fun process(waveform: ByteArray, sampleRate: Int) {
        var size = Integer.highestOneBit(waveform.size)
        if (size < 128) return
        if (fft?.n != size) fft = Fft(size)
        val samples = FloatArray(size)
        var peak = 0f
        var sumSq = 0f
        var extremes = 0
        for (i in 0 until size) {
            val raw = waveform[i].toInt() and 0xFF
            val s = (raw - 128) / 128f
            samples[i] = s
            peak = max(peak, abs(s))
            sumSq += s * s
            if (raw == 0 || raw == 255) extremes++
        }
        val hasSignal = peak > 1.5f / 128f
        val rms = sqrt(sumSq / size)
        val db = fft!!.magnitudeDbFs(samples)
        val sr = if (sampleRate > 0) sampleRate else 44100
        val binHz = sr.toFloat() / size

        val bars = FloatArray(BAR_COUNT)
        val fMax = min(16000f, sr / 2f)
        for (b in 0 until BAR_COUNT) {
            val lo = F_MIN * (fMax / F_MIN).pow(b / BAR_COUNT.toFloat())
            val hi = F_MIN * (fMax / F_MIN).pow((b + 1) / BAR_COUNT.toFloat())
            val first = (lo / binHz).toInt().coerceIn(1, db.size - 1)
            val last = (hi / binHz).toInt().coerceIn(first, db.size - 1)
            var best = -120f
            for (k in first..last) best = max(best, db[k])
            val target = if (hasSignal) ((best + 60f) / 60f).coerceIn(0f, 1f) else 0f
            val prev = previousBars[b]
            val a = smoothing.coerceIn(0f, 0.95f)
            val factor = if (target > prev) a * 0.5f else a
            bars[b] = prev * factor + target * (1f - factor)
        }
        previousBars = bars
        _frame.value = SpectrumFrame(
            bars = bars,
            spectrumDb = db,
            binHz = binHz,
            peakDb = 20f * log10(max(peak, 1e-6f)),
            rmsDb = 20f * log10(max(rms, 1e-6f)),
            clipping = extremes >= 2,
            hasSignal = hasSignal,
        )
    }

    companion object {
        const val BAR_COUNT = 32
        private const val F_MIN = 40f
    }
}
