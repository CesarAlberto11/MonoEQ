package com.monoeq.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AudioController
import com.monoeq.app.audio.EngineState
import com.monoeq.app.audio.EqBackend
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.Bands
import com.monoeq.app.i18n.AppStrings

private data class StatusInfo(val level: StatusLevel, val title: String, val detail: String)

@Composable
fun EqualizerScreen(controller: AudioController, settings: AppSettings) {
    val t = LocalStrings.current
    val ctx = LocalContext.current
    val params by controller.params.collectAsStateWithLifecycle()
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val bypass by controller.userBypass.collectAsStateWithLifecycle()
    val route by controller.route.collectAsStateWithLifecycle()

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // El servicio funciona aunque se rechace el permiso; solo se oculta la notificación.
        controller.setEngineEnabled(ctx, true)
    }
    fun toggleEngine(on: Boolean) {
        val needsPermission = on && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else controller.setEngineEnabled(ctx, on)
    }

    val status = describeStatus(t, engine, settings.engineEnabled, bypass)
    val gains = remember(params, engine.capabilities) { params.effectiveBandGains(emulateBass = engine.capabilities?.bassBoostNative == false) }
    val applied = engine.appliedBands
    val preview = applied.isEmpty()
    val curveFreqs = if (preview) Bands.centersHz else applied.map { it.freqHz }.toFloatArray()
    val curveGains = if (preview) gains else applied.map { it.gainDb }.toFloatArray()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader(
            title = "MONO EQ",
            subtitle = t.outputLine(t.routeName(route.type), route.deviceName),
            trailing = { PowerButton(settings.engineEnabled, { toggleEngine(!settings.engineEnabled) }, t.powerDescription) },
        )
        StatusCard(status.title, status.detail, status.level)

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton(t.pillOriginal, bypass, { controller.setBypass(!bypass) }, enabled = engine.running)
            PillButton(t.pillHeadroom, params.autoHeadroom, { controller.updateParams { it.copy(autoHeadroom = !it.autoHeadroom) } })
        }

        MonoCard(
            title = if (preview) t.cardResponsePreview else t.cardResponse,
            trailing = { PillButton(t.pillReset, false, { controller.resetParams() }) },
        ) {
            EqCurveView(curveFreqs, curveGains, preview, Modifier.fillMaxWidth().height(130.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                InfoText("20 Hz"); InfoText("±15 dB"); InfoText("20 kHz")
            }
            InfoText(if (preview) t.responsePreviewNote else t.responseAppliedNote)
            if (engine.backend == EqBackend.EQUALIZER) InfoText(t.responseFewBands(applied.size))
        }

        MonoCard(title = t.cardBands) {
            Row(Modifier.fillMaxWidth().height(230.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (i in 0 until Bands.COUNT) {
                    BandSlider(
                        label = Bands.labels[i],
                        value = params.bands[i],
                        onValueChange = { v -> controller.updateParams { p -> p.copy(bands = p.bands.toMutableList().also { it[i] = v }) } },
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    )
                }
            }
            InfoText(t.bandsHint)
        }

        MonoCard(title = t.cardTone) {
            MonoSlider(t.toneBass, formatDb(params.bassDb), params.bassDb, { v -> controller.updateParams { it.copy(bassDb = v) } }, -10f..10f, fromCenter = true)
            MonoSlider(t.toneMid, formatDb(params.midDb), params.midDb, { v -> controller.updateParams { it.copy(midDb = v) } }, -10f..10f, fromCenter = true)
            MonoSlider(t.toneTreble, formatDb(params.trebleDb), params.trebleDb, { v -> controller.updateParams { it.copy(trebleDb = v) } }, -10f..10f, bigKnob = true, fromCenter = true)
        }

        MonoCard(title = t.cardGain) {
            val balanceSupported = engine.capabilities?.balance != false
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Knob(t.knobPreamp, formatDb(params.preampDb), params.preampDb, { v -> controller.updateParams { it.copy(preampDb = v) } }, -12f..12f)
                Knob(t.knobMaster, formatDb(params.masterDb), params.masterDb, { v -> controller.updateParams { it.copy(masterDb = v) } }, -12f..12f)
                Knob(t.knobBalance, t.balanceText(params.balance), params.balance, { v -> controller.updateParams { it.copy(balance = v) } }, -1f..1f, enabled = balanceSupported)
            }
            InfoText(t.knobsHint)
            if (!balanceSupported) InfoText(t.balanceUnsupported)
            if (params.masterDb > 0f && !params.limiterEnabled) InfoText(t.masterClipWarning)
        }
    }
}

private fun describeStatus(t: AppStrings, e: EngineState, enabled: Boolean, bypass: Boolean): StatusInfo {
    val sessions = e.chains.count { it.backend != EqBackend.NONE }
    return when {
        !enabled || !e.running -> StatusInfo(StatusLevel.IDLE, t.statusOffTitle, t.statusOffDetail)
        bypass -> StatusInfo(StatusLevel.WARNING, t.statusOriginalTitle, t.statusOriginalDetail)
        e.suspended -> StatusInfo(StatusLevel.IDLE, t.statusStandbyTitle, t.statusStandbyDetail)
        e.chains.isEmpty() -> StatusInfo(StatusLevel.IDLE, t.statusNoSessionsTitle, t.statusNoSessionsDetail)
        sessions == 0 -> StatusInfo(StatusLevel.WARNING, t.statusNoEffectsTitle, t.statusNoEffectsDetail)
        else -> StatusInfo(StatusLevel.ACTIVE, t.statusActiveTitle(sessions), t.statusActiveDetail(t.backendName(e.backend)))
    }
}
