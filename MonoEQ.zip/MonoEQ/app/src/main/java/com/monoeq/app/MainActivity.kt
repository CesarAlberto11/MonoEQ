package com.monoeq.app

import android.content.Intent
import android.media.audiofx.AudioEffect
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.monoeq.app.audio.AudioController
import com.monoeq.app.service.ServiceLauncher
import com.monoeq.app.ui.MonoEqRoot
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var controller: AudioController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val transparent = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(transparent),
            navigationBarStyle = SystemBarStyle.dark(transparent),
        )
        controller = (application as MonoEqApp).container.controller
        handleEffectPanelIntent(intent)

        // Si el motor estaba activado y Android mató el servicio, se recupera al abrir la app.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                val s = controller.settings.filterNotNull().first()
                if (s.engineEnabled) ServiceLauncher.start(applicationContext)
            }
        }
        setContent { MonoEqRoot(controller) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleEffectPanelIntent(intent)
    }

    /** Un reproductor nos abrió como "ecualizador del sistema" y nos indica su sesión de audio. */
    private fun handleEffectPanelIntent(i: Intent?) {
        if (i?.action != AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL) return
        val session = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEffect.ERROR_BAD_VALUE)
        controller.onSessionOpened(
            session,
            i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME),
            i.getIntExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC),
        )
    }
}
