package com.monoeq.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.monoeq.app.domain.Profile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

/** Perfiles personalizados. Los predefinidos viven en el código ([com.monoeq.app.domain.BuiltInProfiles]). */
class ProfileRepository(private val context: Context) {
    private val key = stringPreferencesKey("custom_profiles")

    val profiles: Flow<List<Profile>> = context.monoDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { Profile.listFromJson(it[key]) }

    suspend fun upsert(profile: Profile) = edit { list ->
        if (list.any { it.id == profile.id }) list.map { if (it.id == profile.id) profile else it }
        else (list + profile).take(Profile.MAX_CUSTOM)
    }

    suspend fun delete(id: String) = edit { list -> list.filterNot { it.id == id } }

    private suspend fun edit(transform: (List<Profile>) -> List<Profile>) {
        context.monoDataStore.edit { prefs ->
            prefs[key] = Profile.listToJson(transform(Profile.listFromJson(prefs[key])))
        }
    }
}
