package com.monoeq.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.monoeq.app.domain.Bands
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object MonoStyle {
    val cardShape = RoundedCornerShape(20.dp)
    val cardBrush = Brush.verticalGradient(listOf(Color(0xFF1C1C20), Color(0xFF111113)))
    val cardBorder = Brush.verticalGradient(listOf(Color(0x38FFFFFF), Color(0x0FFFFFFF)))
    val buttonBrush = Brush.verticalGradient(listOf(Color(0xFF232327), Color(0xFF151518)))
    val knobBrush = Brush.radialGradient(listOf(Color(0xFF3A3A40), Color(0xFF17171A)))
    val caps = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.6.sp)
    val capsSmall = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.2.sp)
}

enum class StatusLevel { ACTIVE, IDLE, WARNING }

fun formatDb(v: Float): String {
    val r = (v * 10f).roundToInt() / 10f
    return if (r > 0f) "+$r dB" else "$r dB"
}

@Composable
fun CapsLabel(text: String, modifier: Modifier = Modifier, color: Color = MonoColors.MidGray) {
    Text(text.uppercase(), modifier, color = color, style = MonoStyle.caps, maxLines = 1)
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title.uppercase(), style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MonoColors.MidGray)
        }
        trailing?.invoke()
    }
}

/** Tarjeta oscura con degradado sutil y borde fino; el título va en mayúsculas espaciadas. */
@Composable
fun MonoCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(MonoStyle.cardShape)
            .background(MonoStyle.cardBrush)
            .border(1.dp, MonoStyle.cardBorder, MonoStyle.cardShape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (title != null || trailing != null) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (title != null) CapsLabel(title, Modifier.weight(1f)) else Spacer(Modifier.weight(1f))
                trailing?.invoke()
            }
        }
        content()
    }
}

@Composable
fun InfoText(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, style = MaterialTheme.typography.bodySmall, color = MonoColors.MidGray)
}

@Composable
fun StatusCard(title: String, detail: String, level: StatusLevel, modifier: Modifier = Modifier) {
    val dot = when (level) {
        StatusLevel.ACTIVE -> MaterialTheme.colorScheme.primary
        StatusLevel.IDLE -> MonoColors.MidGray
        StatusLevel.WARNING -> Color(0xFFCDB07A)
    }
    MonoCard(modifier) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.padding(top = 4.dp).size(8.dp).background(dot, CircleShape))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(detail, style = MaterialTheme.typography.bodySmall, color = MonoColors.MidGray)
            }
        }
    }
}

/** Botón en forma de píldora, como «AI LIMIT» o «SAFE BASS» de la referencia. */
@Composable
fun PillButton(text: String, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val accent = MaterialTheme.colorScheme.primary
    val textColor = when {
        !enabled -> MonoColors.MidGray.copy(alpha = 0.5f)
        active -> accent
        else -> MonoColors.LightGray
    }
    Box(
        modifier
            .height(36.dp)
            .clip(CircleShape)
            .background(MonoStyle.buttonBrush)
            .border(1.dp, if (active && enabled) accent.copy(alpha = 0.85f) else MonoColors.Hairline, CircleShape)
            .semantics { this.selected = active }
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text.uppercase(), style = MonoStyle.caps, color = textColor, maxLines = 1)
    }
}

/** Botón circular con título y subtítulo («BASS / EPICENTER» en la referencia). */
@Composable
fun RoundToggle(
    title: String,
    caption: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 70.dp,
    enabled: Boolean = true,
) {
    val accent = MaterialTheme.colorScheme.primary
    Box(
        modifier
            .size(size)
            .drawBehind {
                if (active && enabled) drawCircle(accent.copy(alpha = 0.14f), radius = this.size.minDimension / 2f + 6.dp.toPx())
            }
            .clip(CircleShape)
            .background(MonoStyle.knobBrush)
            .border(1.5.dp, if (active && enabled) accent else Color(0xFF3A3A40), CircleShape)
            .semantics { this.selected = active }
            .clickable(enabled = enabled, role = Role.Switch, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        val color = when {
            !enabled -> MonoColors.MidGray.copy(alpha = 0.5f)
            active -> MonoColors.White
            else -> MonoColors.LightGray
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title.uppercase(), style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp), color = color, maxLines = 1, softWrap = false, textAlign = TextAlign.Center)
            Text(caption.uppercase(), style = MonoStyle.capsSmall.copy(fontSize = 7.5.sp), color = MonoColors.MidGray, maxLines = 1, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun PowerButton(on: Boolean, onClick: () -> Unit, description: String, modifier: Modifier = Modifier) {
    val accent = MaterialTheme.colorScheme.primary
    Box(
        modifier
            .size(48.dp)
            .drawBehind { if (on) drawCircle(accent.copy(alpha = 0.14f), radius = size.minDimension / 2f + 5.dp.toPx()) }
            .clip(CircleShape)
            .background(MonoStyle.knobBrush)
            .border(1.5.dp, if (on) accent else Color(0xFF3A3A40), CircleShape)
            .semantics { contentDescription = description; this.selected = on }
            .clickable(role = Role.Switch, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(20.dp)) {
            val color = if (on) accent else MonoColors.LightGray
            val stroke = Stroke(2.dp.toPx(), cap = StrokeCap.Round)
            val pad = 2.dp.toPx()
            drawArc(color, -60f, 300f, false, topLeft = Offset(pad, pad + 1.dp.toPx()), size = Size(size.width - 2 * pad, size.height - 2 * pad - 1.dp.toPx()), style = stroke)
            drawLine(color, Offset(size.width / 2f, 1.dp.toPx()), Offset(size.width / 2f, size.height * 0.5f), 2.dp.toPx(), StrokeCap.Round)
        }
    }
}

/**
 * Slider horizontal propio: etiqueta en mayúsculas a la izquierda, valor a la derecha y perilla redonda.
 * [bigKnob] reproduce el estilo de la perilla blanca grande de la referencia.
 */
@Composable
fun MonoSlider(
    label: String,
    valueText: String,
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    bigKnob: Boolean = false,
    fromCenter: Boolean = false,
) {
    val onChangeState by rememberUpdatedState(onChange)
    val accent = MaterialTheme.colorScheme.primary
    Column(modifier) {
        Row(Modifier.fillMaxWidth()) {
            CapsLabel(label, Modifier.weight(1f), if (enabled) MonoColors.MidGray else MonoColors.MidGray.copy(alpha = 0.5f))
            Text(valueText.uppercase(), style = MonoStyle.caps, color = if (enabled) MonoColors.LightGray else MonoColors.MidGray.copy(alpha = 0.5f), maxLines = 1)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(34.dp)
                .semantics {
                    contentDescription = "$label $valueText"
                    progressBarRangeInfo = ProgressBarRangeInfo(value.coerceIn(range.start, range.endInclusive), range)
                    setProgress { v -> onChangeState(v.coerceIn(range.start, range.endInclusive)); true }
                }
                .pointerInput(enabled, range) {
                    if (!enabled) return@pointerInput
                    val pad = (if (bigKnob) 12.dp else 8.dp).toPx()
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        fun report(x: Float) {
                            val usable = (size.width - 2 * pad).coerceAtLeast(1f)
                            val frac = ((x - pad) / usable).coerceIn(0f, 1f)
                            onChangeState(range.start + frac * (range.endInclusive - range.start))
                        }
                        report(down.position.x)
                        do {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            if (change.pressed) {
                                report(change.position.x)
                                change.consume()
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .drawBehind {
                    val pad = (if (bigKnob) 12.dp else 8.dp).toPx()
                    val y = size.height / 2f
                    val span = range.endInclusive - range.start
                    val frac = ((value - range.start) / span).coerceIn(0f, 1f)
                    val kx = pad + frac * (size.width - 2 * pad)
                    val originX = if (fromCenter) pad + ((0f - range.start) / span).coerceIn(0f, 1f) * (size.width - 2 * pad) else pad
                    drawLine(Color(0xFF2E2E33), Offset(pad, y), Offset(size.width - pad, y), 3.dp.toPx(), StrokeCap.Round)
                    drawLine(if (enabled) accent.copy(alpha = 0.75f) else MonoColors.MidGray, Offset(originX, y), Offset(kx, y), 3.dp.toPx(), StrokeCap.Round)
                    if (bigKnob) {
                        drawCircle(Color(0x40000000), 13.dp.toPx(), Offset(kx, y + 1.dp.toPx()))
                        drawCircle(if (enabled) Color.White else MonoColors.LightGray, 11.dp.toPx(), Offset(kx, y))
                    } else {
                        drawCircle(Color(0xFF55555C), 8.dp.toPx(), Offset(kx, y))
                        drawCircle(if (enabled) Color(0xFF9A9AA2) else Color(0xFF5A5A60), 6.dp.toPx(), Offset(kx, y))
                    }
                }
        )
    }
}

/** Perilla giratoria: se cambia arrastrando en vertical; doble toque la devuelve a su valor inicial. */
@Composable
fun Knob(
    label: String,
    valueText: String,
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    defaultValue: Float = 0f,
) {
    val current by rememberUpdatedState(value)
    val onChangeState by rememberUpdatedState(onChange)
    val accent = MaterialTheme.colorScheme.primary
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier
                .size(84.dp)
                .semantics {
                    contentDescription = "$label $valueText"
                    progressBarRangeInfo = ProgressBarRangeInfo(value.coerceIn(range.start, range.endInclusive), range)
                    setProgress { v -> onChangeState(v.coerceIn(range.start, range.endInclusive)); true }
                }
                .pointerInput(enabled, range) {
                    if (!enabled) return@pointerInput
                    detectVerticalDragGestures { change, dragAmount ->
                        change.consume()
                        val span = range.endInclusive - range.start
                        onChangeState((current - dragAmount / 240.dp.toPx() * span).coerceIn(range.start, range.endInclusive))
                    }
                }
                .pointerInput(enabled, defaultValue) {
                    if (enabled) detectTapGestures(onDoubleTap = { onChangeState(defaultValue) })
                }
                .drawBehind {
                    val c = center
                    val r = size.minDimension / 2f
                    val ringPad = 4.dp.toPx()
                    val ringSize = Size(size.width - 2 * ringPad, size.height - 2 * ringPad)
                    val frac = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
                    val stroke = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                    drawArc(Color(0xFF2E2E33), 135f, 270f, false, topLeft = Offset(ringPad, ringPad), size = ringSize, style = stroke)
                    if (frac > 0f) drawArc(if (enabled) accent else MonoColors.MidGray, 135f, 270f * frac, false, topLeft = Offset(ringPad, ringPad), size = ringSize, style = stroke)
                    val body = r - 12.dp.toPx()
                    drawCircle(Brush.radialGradient(listOf(Color(0xFF45454B), Color(0xFF17171A)), center = Offset(c.x - r * 0.25f, c.y - r * 0.3f), radius = r), body, c)
                    drawCircle(Color(0xFF4A4A50), body, c, style = Stroke(1.dp.toPx()))
                    val angle = Math.toRadians((135f + 270f * frac).toDouble())
                    val cs = cos(angle).toFloat()
                    val sn = sin(angle).toFloat()
                    drawLine(
                        if (enabled) Color.White else MonoColors.MidGray,
                        Offset(c.x + cs * body * 0.4f, c.y + sn * body * 0.4f),
                        Offset(c.x + cs * (body - 4.dp.toPx()), c.y + sn * (body - 4.dp.toPx())),
                        3.dp.toPx(), StrokeCap.Round,
                    )
                }
        )
        Text(valueText.uppercase(), style = MonoStyle.caps, color = MonoColors.LightGray, maxLines = 1)
        CapsLabel(label)
    }
}

/** Control vertical de una banda del ecualizador (arrastrar o tocar). */
@Composable
fun BandSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    min: Float = Bands.USER_MIN_DB,
    max: Float = Bands.USER_MAX_DB,
) {
    val onChange by rememberUpdatedState(onValueChange)
    val accent = MaterialTheme.colorScheme.primary
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            if (abs(value) < 0.05f) "0" else ((value * 10f).roundToInt() / 10f).toString(),
            style = MonoStyle.capsSmall, color = MonoColors.LightGray, maxLines = 1, textAlign = TextAlign.Center,
        )
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .semantics {
                    contentDescription = "$label Hz ${formatDb(value)}"
                    progressBarRangeInfo = ProgressBarRangeInfo(value.coerceIn(min, max), min..max)
                    setProgress { v -> onChange(v.coerceIn(min, max)); true }
                }
                .pointerInput(min, max) {
                    val pad = 10.dp.toPx()
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        fun report(y: Float) {
                            val usable = (size.height - 2 * pad).coerceAtLeast(1f)
                            val frac = 1f - ((y - pad) / usable).coerceIn(0f, 1f)
                            onChange(((min + frac * (max - min)) * 2f).roundToInt() / 2f)
                        }
                        report(down.position.y)
                        do {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            if (change.pressed) {
                                report(change.position.y)
                                change.consume()
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .drawBehind {
                    val pad = 10.dp.toPx()
                    val cx = size.width / 2f
                    val usable = size.height - 2 * pad
                    val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
                    val y = pad + usable * (1f - frac)
                    val yZero = pad + usable * (1f - (0f - min) / (max - min))
                    drawLine(Color(0xFF2E2E33), Offset(cx, pad), Offset(cx, size.height - pad), 3.dp.toPx(), StrokeCap.Round)
                    drawLine(MonoColors.MidGray, Offset(cx - 9.dp.toPx(), yZero), Offset(cx + 9.dp.toPx(), yZero), 1.dp.toPx())
                    drawLine(accent.copy(alpha = 0.75f), Offset(cx, yZero), Offset(cx, y), 3.dp.toPx(), StrokeCap.Round)
                    drawCircle(Color(0xFF55555C), 9.dp.toPx(), Offset(cx, y))
                    drawCircle(Color(0xFF9A9AA2), 7.dp.toPx(), Offset(cx, y))
                }
        )
        Text(label, style = MonoStyle.capsSmall, color = MonoColors.MidGray, maxLines = 1)
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = if (enabled) MaterialTheme.colorScheme.onSurface else MonoColors.MidGray)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MonoColors.MidGray)
        }
        Switch(
            checked = checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MonoColors.Black,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = MonoColors.LightGray,
                uncheckedTrackColor = MonoColors.DarkGray,
                uncheckedBorderColor = MonoColors.MidGray,
            ),
        )
    }
}

@Composable
fun AccentDot(color: Color, selected: Boolean, label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .background(color, CircleShape)
            .border(BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MonoColors.White else MonoColors.Hairline), CircleShape)
            .semantics { contentDescription = label; this.selected = selected }
            .clickable(role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Box(Modifier.size(10.dp).background(MonoColors.Black, CircleShape))
    }
}
