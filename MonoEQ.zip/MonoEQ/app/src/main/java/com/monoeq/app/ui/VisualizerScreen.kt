package com.monoeq.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AnalyzerStatus
import com.monoeq.app.audio.AudioController
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.Bands
import com.monoeq.app.domain.VisualizerMode
import kotlin.math.roundToInt

@Composable
fun VisualizerScreen(controller: AudioController, settings: AppSettings) {
    val ctx = LocalContext.current
    val frame by controller.analyzer.frame.collectAsStateWithLifecycle()
    val status by controller.analyzer.status.collectAsStateWithLifecycle()
    val serviceActive by controller.serviceActive.collectAsStateWithLifecycle()
    val sessions by controller.sessions.collectAsStateWithLifecycle()
    val testRunning by controller.testSignal.running.collectAsStateWithLifecycle()
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val params by controller.params.collectAsStateWithLifecycle()

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    var source by rememberSaveable { mutableStateOf<Int?>(null) }
    var peakHold by remember { mutableFloatStateOf(-60f) }

    // El análisis solo corre con esta pantalla visible: ahorra batería.
    LifecycleResumeEffect(source, hasPermission, serviceActive, testRunning, sessions.size) {
        if (hasPermission && serviceActive) controller.startSpectrum(source)
        onPauseOrDispose { controller.stopSpectrum() }
    }
    LaunchedEffect(frame) {
        val f = frame
        peakHold = if (f != null && f.peakDb > peakHold) f.peakDb else (peakHold - 1.5f).coerceAtLeast(-60f)
    }

    val eqFreqs = if (engine.appliedBands.isEmpty()) Bands.centersHz else engine.appliedBands.map { it.freqHz }.toFloatArray()
    val eqGains = if (engine.appliedBands.isEmpty()) params.effectiveBandGains(false) else engine.appliedBands.map { it.gainDb }.toFloatArray()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader("Espectro", "Señal real de la sesión elegida; nunca datos simulados")

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VisualizerMode.entries.forEach { m ->
                FilterChip(
                    selected = settings.visualizerMode == m,
                    onClick = { controller.updateSettings { it.copy(visualizerMode = m) } },
                    label = { Text(m.label) },
                )
            }
        }

        Surface(
            Modifier.fillMaxWidth().height(240.dp),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
        ) {
            val f = frame
            when {
                !serviceActive -> Placeholder("Activa el motor en la pestaña EQ para analizar el audio.")
                !hasPermission -> Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Android exige el permiso de audio para leer el espectro de una sesión (API Visualizer). MONO EQ no graba el micrófono.",
                        style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Conceder permiso") }
                }
                status is AnalyzerStatus.Failed -> Placeholder("No se pudo abrir el analizador en esta sesión: ${(status as AnalyzerStatus.Failed).reason}")
                f == null || !f.hasSignal -> Placeholder("Sin señal real en la sesión elegida: silencio, sesión sin reproducción o captura bloqueada por el sistema o la app. No se muestran datos simulados.")
                else -> when (settings.visualizerMode) {
                    VisualizerMode.BARS -> SpectrumBars(f.bars, Modifier.fillMaxSize().padding(12.dp))
                    VisualizerMode.CURVE -> SpectrumCurve(f, eqFreqs, eqGains, Modifier.fillMaxSize().padding(12.dp))
                    VisualizerMode.METER -> Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
                        LevelMeter(f.rmsDb, f.peakDb, peakHold, Modifier.fillMaxWidth().height(90.dp))
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            InfoText("RMS ${f.rmsDb.roundToInt()} dBFS")
                            InfoText("Pico ${f.peakDb.roundToInt()} dBFS")
                            InfoText("Retención ${peakHold.roundToInt()} dBFS")
                        }
                    }
                }
            }
        }

        frame?.let { f ->
            if (f.hasSignal && f.clipping) {
                StatusBanner("Posible clipping", "Hay muestras en el límite del rango de captura (8 bits). Es un indicio, no una medición exacta.")
            }
        }

        SectionCard("Fuente") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = source == null, onClick = { source = null }, label = { Text("Auto") })
                controller.spectrumSources().forEach { (id, name) ->
                    FilterChip(selected = source == id, onClick = { source = id }, label = { Text(name) })
                }
            }
            InfoText(
                "Auto elige la señal de prueba, la última sesión anunciada por una app o, si no hay ninguna, la mezcla global. " +
                    "La mezcla global suele estar bloqueada en Android 10 o superior."
            )
            Button(
                onClick = { if (testRunning) controller.stopTest() else controller.startTest(withEffects = true) },
                enabled = serviceActive,
            ) { Text(if (testRunning) "Detener señal de prueba" else "Reproducir señal de prueba") }
            ValueSlider(
                "Suavizado visual", "${(settings.smoothing * 100f).roundToInt()} %", settings.smoothing,
                { v -> controller.updateSettings { it.copy(smoothing = v) } }, 0f..0.95f,
            )
            InfoText("El espectro se mide antes de que el sistema aplique sus propios efectos y tiene resolución de 8 bits (unos 48 dB de rango).")
        }
    }
}

@Composable
private fun Placeholder(text: String) {
    Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
