package com.monoeq.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AudioController
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.Profile

private sealed interface ProfileDialog {
    data object Create : ProfileDialog
    data class Rename(val profile: Profile) : ProfileDialog
    data class Delete(val profile: Profile) : ProfileDialog
}

@Composable
fun ProfilesScreen(controller: AudioController, settings: AppSettings) {
    val t = LocalStrings.current
    val custom by controller.customProfiles.collectAsStateWithLifecycle()
    val params by controller.params.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<ProfileDialog?>(null) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 8.dp),
    ) {
        item {
            ScreenHeader(t.profilesTitle, t.profilesSubtitle)
            Spacer(Modifier.height(8.dp))
            PillButton(t.pillSaveProfile, true, { dialog = ProfileDialog.Create }, enabled = custom.size < Profile.MAX_CUSTOM)
        }
        item { CapsLabel(t.profilesMine, Modifier.padding(top = 12.dp)) }
        if (custom.isEmpty()) item { InfoText(t.profilesEmpty) }
        items(custom, key = { it.id }) { p ->
            ProfileRow(p, settings.activeProfileId == p.id, settings.activeProfileId == p.id && params != p.params, controller) { dialog = it }
        }
        item { CapsLabel(t.profilesBuiltIn, Modifier.padding(top = 12.dp)) }
        items(BuiltInProfiles.all, key = { it.id }) { p ->
            ProfileRow(p, settings.activeProfileId == p.id, settings.activeProfileId == p.id && params != p.params, controller) { dialog = it }
        }
    }

    when (val d = dialog) {
        ProfileDialog.Create -> NameDialog(t.dialogNewProfile, "", { dialog = null }) { name ->
            controller.saveCurrentAsProfile(name); dialog = null
        }
        is ProfileDialog.Rename -> NameDialog(t.dialogRenameProfile, d.profile.name, { dialog = null }) { name ->
            controller.renameProfile(d.profile.id, name); dialog = null
        }
        is ProfileDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(t.dialogDeleteTitle) },
            text = { Text(t.dialogDeleteBody(d.profile.name)) },
            confirmButton = { TextButton(onClick = { controller.deleteProfile(d.profile.id); dialog = null }) { Text(t.dialogDelete) } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(t.dialogCancel) } },
        )
        null -> Unit
    }
}

@Composable
private fun ProfileRow(profile: Profile, selected: Boolean, dirty: Boolean, controller: AudioController, openDialog: (ProfileDialog) -> Unit) {
    val t = LocalStrings.current
    var menu by remember { mutableStateOf(false) }
    val accent = MaterialTheme.colorScheme.primary
    val shape = MonoStyle.cardShape
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MonoStyle.cardBrush)
            .then(if (selected) Modifier.border(1.dp, accent, shape) else Modifier.border(1.dp, MonoStyle.cardBorder, shape))
            .clickable { controller.applyProfile(profile.id) }
            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(t.profileName(profile), style = MaterialTheme.typography.bodyLarge, color = MonoColors.White)
            Text(
                when {
                    selected && dirty -> t.profileInUseDirty
                    selected -> t.profileInUse
                    profile.builtIn -> t.profileBuiltIn
                    else -> t.profileCustom
                },
                style = MaterialTheme.typography.bodySmall, color = if (selected) accent else MonoColors.MidGray,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = t.profileOptions(t.profileName(profile)), tint = MonoColors.LightGray)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (!profile.builtIn) {
                    if (selected && dirty) DropdownMenuItem(text = { Text(t.menuSaveChanges) }, onClick = { menu = false; controller.updateProfileFromCurrent(profile.id) })
                    DropdownMenuItem(text = { Text(t.menuRename) }, onClick = { menu = false; openDialog(ProfileDialog.Rename(profile)) })
                }
                DropdownMenuItem(text = { Text(t.menuDuplicate) }, onClick = { menu = false; controller.duplicateProfile(profile.id) })
                if (!profile.builtIn) DropdownMenuItem(text = { Text(t.menuDelete) }, onClick = { menu = false; openDialog(ProfileDialog.Delete(profile)) })
            }
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    val t = LocalStrings.current
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it.take(Profile.MAX_NAME) }, singleLine = true, label = { Text(t.dialogName) }) },
        confirmButton = { TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(t.dialogSave) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t.dialogCancel) } },
    )
}
