package com.monoeq.app.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.monoeq.app.domain.AccentChoice
import com.monoeq.app.domain.AudioParams
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.domain.RouteType
import com.monoeq.app.domain.VisualizerMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONObject
import java.io.IOException

class SettingsRepository(private val context: Context) {

    private object K {
        val engineEnabled = booleanPreferencesKey("engine_enabled")
        val activeProfile = stringPreferencesKey("active_profile_id")
        val paramsJson = stringPreferencesKey("params_json")
        val coverage = stringPreferencesKey("coverage")
        val startOnBoot = booleanPreferencesKey("start_on_boot")
        val idleRelease = booleanPreferencesKey("idle_release")
        val pauseOnDisconnect = booleanPreferencesKey("pause_on_disconnect")
        val autoProfile = booleanPreferencesKey("auto_profile")
        val routeWired = stringPreferencesKey("route_profile_wired")
        val routeBluetooth = stringPreferencesKey("route_profile_bluetooth")
        val routeSpeaker = stringPreferencesKey("route_profile_speaker")
        val accent = stringPreferencesKey("accent")
        val smoothing = floatPreferencesKey("smoothing")
        val visualizerMode = stringPreferencesKey("visualizer_mode")
    }

    val settings: Flow<AppSettings> = context.monoDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { it.toSettings() }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.monoDataStore.edit { prefs -> prefs.write(transform(prefs.toSettings())) }
    }

    private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T =
        enumValues<T>().firstOrNull { it.name == this } ?: default

    private fun Preferences.toSettings(): AppSettings {
        val prefs = this
        val params = prefs[K.paramsJson]?.let { json ->
            try { AudioParams.fromJson(JSONObject(json)) } catch (e: Exception) { null }
        } ?: AudioParams()
        val routes = HashMap<RouteType, String>()
        prefs[K.routeWired]?.takeIf { it.isNotEmpty() }?.let { routes[RouteType.WIRED] = it }
        prefs[K.routeBluetooth]?.takeIf { it.isNotEmpty() }?.let { routes[RouteType.BLUETOOTH] = it }
        prefs[K.routeSpeaker]?.takeIf { it.isNotEmpty() }?.let { routes[RouteType.SPEAKER] = it }
        return AppSettings(
            engineEnabled = prefs[K.engineEnabled] ?: false,
            activeProfileId = prefs[K.activeProfile] ?: BuiltInProfiles.NORMAL_ID,
            params = params,
            coverage = prefs[K.coverage].toEnum(CoverageMode.SESSIONS),
            startOnBoot = prefs[K.startOnBoot] ?: true,
            idleRelease = prefs[K.idleRelease] ?: false,
            pauseOnDisconnect = prefs[K.pauseOnDisconnect] ?: false,
            autoProfile = prefs[K.autoProfile] ?: false,
            routeProfiles = routes,
            accent = prefs[K.accent].toEnum(AccentChoice.WHITE),
            smoothing = (prefs[K.smoothing] ?: 0.6f).coerceIn(0f, 0.95f),
            visualizerMode = prefs[K.visualizerMode].toEnum(VisualizerMode.BARS),
        )
    }

    private fun MutablePreferences.write(s: AppSettings) {
        this[K.engineEnabled] = s.engineEnabled
        this[K.activeProfile] = s.activeProfileId
        this[K.paramsJson] = s.params.sanitized().toJson().toString()
        this[K.coverage] = s.coverage.name
        this[K.startOnBoot] = s.startOnBoot
        this[K.idleRelease] = s.idleRelease
        this[K.pauseOnDisconnect] = s.pauseOnDisconnect
        this[K.autoProfile] = s.autoProfile
        this[K.routeWired] = s.routeProfiles[RouteType.WIRED].orEmpty()
        this[K.routeBluetooth] = s.routeProfiles[RouteType.BLUETOOTH].orEmpty()
        this[K.routeSpeaker] = s.routeProfiles[RouteType.SPEAKER].orEmpty()
        this[K.accent] = s.accent.name
        this[K.smoothing] = s.smoothing.coerceIn(0f, 0.95f)
        this[K.visualizerMode] = s.visualizerMode.name
    }
}
