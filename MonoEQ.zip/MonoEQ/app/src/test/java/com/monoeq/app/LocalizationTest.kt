package com.monoeq.app

import com.monoeq.app.audio.EffectId
import com.monoeq.app.audio.EffectState
import com.monoeq.app.audio.EqBackend
import com.monoeq.app.domain.AccentChoice
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.domain.ReverbPreset
import com.monoeq.app.domain.RouteType
import com.monoeq.app.domain.VisualizerMode
import com.monoeq.app.i18n.AppStrings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalizationTest {
    private fun textGetters(s: AppStrings) = AppStrings::class.java.methods
        .filter { it.parameterCount == 0 && it.returnType == String::class.java && it.name.startsWith("get") }

    @Test
    fun noTextIsBlankInAnyLanguage() {
        AppLanguage.entries.forEach { lang ->
            val s = AppStrings.of(lang)
            val getters = textGetters(s)
            assertTrue("pocas claves en $lang", getters.size > 150)
            getters.forEach { g -> assertTrue("${g.name} vacío en $lang", (g.invoke(s) as String).isNotBlank()) }
        }
    }

    @Test
    fun spanishDiffersFromEnglishForCoreTexts() {
        val en = AppStrings.of(AppLanguage.EN)
        val es = AppStrings.of(AppLanguage.ES)
        assertEquals("Settings", en.navSettings)
        assertEquals("Ajustes", es.navSettings)
        assertNotEquals(en.statusOffTitle, es.statusOffTitle)
        assertNotEquals(en.diagLimitsTitle, es.diagLimitsTitle)
    }

    @Test
    fun everyEnumValueHasAName() {
        AppLanguage.entries.forEach { lang ->
            val s = AppStrings.of(lang)
            EffectId.entries.forEach { assertTrue(s.effectName(it).isNotBlank()) }
            EffectState.entries.forEach { assertTrue(s.stateName(it).isNotBlank()) }
            EqBackend.entries.forEach { assertTrue(s.backendName(it).isNotBlank()) }
            RouteType.entries.forEach { assertTrue(s.routeName(it).isNotBlank()) }
            ReverbPreset.entries.forEach { assertTrue(s.reverbName(it).isNotBlank()) }
            AccentChoice.entries.forEach { assertTrue(s.accentName(it).isNotBlank()) }
            VisualizerMode.entries.forEach { assertTrue(s.vizModeName(it).isNotBlank()) }
            CoverageMode.entries.forEach { assertTrue(s.coverageName(it).isNotBlank() && s.coverageDescription(it).isNotBlank()) }
            BuiltInProfiles.all.forEach { assertTrue(s.profileName(it).isNotBlank()) }
        }
    }

    @Test
    fun builtInProfileNamesAreTranslated() {
        val night = BuiltInProfiles.all.first { it.id == "builtin_night" }
        assertEquals("Night", AppStrings.of(AppLanguage.EN).profileName(night))
        assertEquals("Nocturno", AppStrings.of(AppLanguage.ES).profileName(night))
    }

    @Test
    fun englishIsTheDefaultLanguage() {
        assertEquals(AppLanguage.EN, com.monoeq.app.data.AppSettings().language)
    }
}
