package com.monoeq.app.audio

import com.monoeq.app.domain.CoverageMode

enum class EqBackend(val label: String) {
    NONE("Sin motor"),
    DYNAMICS("DynamicsProcessing (10 bandas exactas)"),
    EQUALIZER("Equalizer nativo (bandas del dispositivo)")
}

enum class ChainKind(val label: String) {
    GLOBAL("Mezcla global (sesión 0)"),
    APP("Sesión de app"),
    TEST("Sesión de prueba propia")
}

enum class EffectState(val label: String) {
    ACTIVE("Activo"), OFF("Apagado"), UNSUPPORTED("No soportado"), FAILED("Error"), NO_CONTROL("Sin control")
}

object EffectNames {
    const val DYNAMICS = "DynamicsProcessing"
    const val EQ = "Ecualizador"
    const val GAIN = "Ganancia y limitador"
    const val BASS = "Refuerzo de graves"
    const val VIRT = "Amplitud estéreo"
    const val REVERB = "Reverberación"
}

data class EffectStatus(val name: String, val state: EffectState, val detail: String = "")

data class ChainInfo(
    val sessionId: Int,
    val kind: ChainKind,
    val label: String,
    val backend: EqBackend,
    val effects: List<EffectStatus>,
)

/** Banda realmente enviada al motor (tras límites del dispositivo). */
data class AppliedBand(val freqHz: Float, val gainDb: Float)

data class Capabilities(
    val dynamics: Boolean,
    val balance: Boolean,
    val limiter: Boolean,
    val bassBoostNative: Boolean,
    val virtualizer: Boolean,
    val reverb: Boolean,
)

data class AudioSessionInfo(
    val sessionId: Int,
    val packageName: String?,
    val label: String,
    val contentType: Int,
)

data class EngineState(
    val running: Boolean = false,
    val bypass: Boolean = false,
    val suspended: Boolean = false,
    val coverage: CoverageMode = CoverageMode.SESSIONS,
    val backend: EqBackend = EqBackend.NONE,
    val chains: List<ChainInfo> = emptyList(),
    val appliedBands: List<AppliedBand> = emptyList(),
    val capabilities: Capabilities? = null,
    val deviceEffects: List<String> = emptyList(),
    val selfTest: ChainInfo? = null,
)

internal fun ChainInfo.toCapabilities(): Capabilities {
    fun usable(name: String) = effects.firstOrNull { it.name == name }?.state.let { it == EffectState.ACTIVE || it == EffectState.OFF || it == EffectState.NO_CONTROL }
    return Capabilities(
        dynamics = backend == EqBackend.DYNAMICS,
        balance = backend == EqBackend.DYNAMICS,
        limiter = backend == EqBackend.DYNAMICS,
        bassBoostNative = usable(EffectNames.BASS),
        virtualizer = usable(EffectNames.VIRT),
        reverb = usable(EffectNames.REVERB),
    )
}
