package com.monoeq.app

import android.app.Application
import com.monoeq.app.audio.AudioController
import com.monoeq.app.data.ProfileRepository
import com.monoeq.app.data.SettingsRepository

class MonoEqApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

class AppContainer(app: Application) {
    val settingsRepo = SettingsRepository(app)
    val profileRepo = ProfileRepository(app)
    val controller = AudioController(app, settingsRepo, profileRepo)
}
