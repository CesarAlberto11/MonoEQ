package com.monoeq.app.audio

import com.monoeq.app.domain.CoverageMode

enum class EqBackend { NONE, DYNAMICS, EQUALIZER }

enum class ChainKind { GLOBAL, APP, TEST, SELF_TEST }

enum class EffectState { ACTIVE, OFF, UNSUPPORTED, FAILED, NO_CONTROL }

enum class EffectId { DYNAMICS, EQ, GAIN, BASS, VIRT, REVERB }

/** [detail] ya viene en el idioma activo cuando se creó el estado. */
data class EffectStatus(val id: EffectId, val state: EffectState, val detail: String = "")

/** [label] solo se usa en las sesiones de apps (nombre de la app); en el resto va vacío. */
data class ChainInfo(
    val sessionId: Int,
    val kind: ChainKind,
    val label: String,
    val backend: EqBackend,
    val effects: List<EffectStatus>,
)

/** Banda realmente enviada al motor (tras límites del dispositivo). */
data class AppliedBand(val freqHz: Float, val gainDb: Float)

data class Capabilities(
    val dynamics: Boolean,
    val balance: Boolean,
    val limiter: Boolean,
    val bassBoostNative: Boolean,
    val virtualizer: Boolean,
    val reverb: Boolean,
)

data class AudioSessionInfo(
    val sessionId: Int,
    val packageName: String?,
    val label: String,
    val contentType: Int,
)

enum class SourceKind { GLOBAL, APP, TEST }

data class SpectrumSource(val sessionId: Int, val kind: SourceKind, val label: String)

data class EngineState(
    val running: Boolean = false,
    val bypass: Boolean = false,
    val suspended: Boolean = false,
    val coverage: CoverageMode = CoverageMode.SESSIONS,
    val backend: EqBackend = EqBackend.NONE,
    val chains: List<ChainInfo> = emptyList(),
    val appliedBands: List<AppliedBand> = emptyList(),
    val capabilities: Capabilities? = null,
    val deviceEffects: List<String> = emptyList(),
    val selfTest: ChainInfo? = null,
)

internal fun ChainInfo.toCapabilities(): Capabilities {
    fun usable(id: EffectId): Boolean {
        val st = effects.firstOrNull { it.id == id }?.state
        return st == EffectState.ACTIVE || st == EffectState.OFF || st == EffectState.NO_CONTROL
    }
    return Capabilities(
        dynamics = backend == EqBackend.DYNAMICS,
        balance = backend == EqBackend.DYNAMICS,
        limiter = backend == EqBackend.DYNAMICS,
        bassBoostNative = usable(EffectId.BASS),
        virtualizer = usable(EffectId.VIRT),
        reverb = usable(EffectId.REVERB),
    )
}
