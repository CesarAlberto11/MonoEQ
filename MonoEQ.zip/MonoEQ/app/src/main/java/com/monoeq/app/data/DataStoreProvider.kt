package com.monoeq.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore

/** Un único DataStore para ajustes y perfiles. Si el archivo se corrompe se reinicia en vacío. */
internal val Context.monoDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "mono_eq",
    corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() }
)
