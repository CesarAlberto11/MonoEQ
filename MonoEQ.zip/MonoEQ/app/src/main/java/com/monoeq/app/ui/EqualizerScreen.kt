package com.monoeq.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AudioController
import com.monoeq.app.audio.EngineState
import com.monoeq.app.audio.EqBackend
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.Balance
import com.monoeq.app.domain.Bands
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun EqualizerScreen(controller: AudioController, settings: AppSettings) {
    val ctx = LocalContext.current
    val params by controller.params.collectAsStateWithLifecycle()
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val bypass by controller.userBypass.collectAsStateWithLifecycle()
    val route by controller.route.collectAsStateWithLifecycle()

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // El servicio funciona aunque se rechace el permiso; solo se oculta la notificación.
        controller.setEngineEnabled(ctx, true)
    }
    fun toggleEngine(on: Boolean) {
        val needsPermission = on && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else controller.setEngineEnabled(ctx, on)
    }

    val (statusTitle, statusDetail) = describeStatus(engine, settings.engineEnabled, bypass)
    val gains = remember(params, engine.backend) { params.effectiveBandGains(emulateBass = engine.capabilities?.bassBoostNative == false) }
    val applied = engine.appliedBands
    val preview = applied.isEmpty()
    val curveFreqs = if (preview) Bands.centersHz else applied.map { it.freqHz }.toFloatArray()
    val curveGains = if (preview) gains else applied.map { it.gainDb }.toFloatArray()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader(
            title = "MONO EQ",
            subtitle = "Salida: ${route.name}",
            trailing = {
                Switch(
                    checked = settings.engineEnabled,
                    onCheckedChange = ::toggleEngine,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                        checkedTrackColor = MaterialTheme.colorScheme.primary,
                        uncheckedThumbColor = MaterialTheme.colorScheme.secondary,
                        uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant,
                        uncheckedBorderColor = MaterialTheme.colorScheme.outline,
                    ),
                )
            },
        )
        StatusBanner(statusTitle, statusDetail)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = bypass,
                onClick = { controller.setBypass(!bypass) },
                label = { Text("Escuchar original") },
                enabled = engine.running,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { controller.resetParams() }) { Text("Restablecer") }
        }

        SectionCard(if (preview) "Curva de respuesta (vista previa)" else "Curva de respuesta aplicada") {
            EqCurveView(curveFreqs, curveGains, preview, Modifier.fillMaxWidth().height(130.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                InfoText("20 Hz"); InfoText("±15 dB"); InfoText("20 kHz")
            }
            InfoText(
                if (preview) "Motor apagado o sin sesiones: la línea punteada muestra los valores que se enviarían."
                else "Calculada con las ganancias que el motor tiene aplicadas; no es una medición del audio."
            )
            if (engine.backend == EqBackend.EQUALIZER) {
                InfoText("Este dispositivo solo ofrece ${applied.size} bandas nativas: la curva de 10 bandas se aproxima.")
            }
        }

        SectionCard("Ecualizador de 10 bandas") {
            Row(Modifier.fillMaxWidth().height(230.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (i in 0 until Bands.COUNT) {
                    BandSlider(
                        label = Bands.labels[i],
                        value = params.bands[i],
                        onValueChange = { v -> controller.updateParams { p -> p.copy(bands = p.bands.toMutableList().also { it[i] = v }) } },
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    )
                }
            }
            InfoText("Valores en dB (−12 a +12). Toca o arrastra cada banda.")
        }

        SectionCard("Tono") {
            ValueSlider("Graves", formatDb(params.bassDb), params.bassDb, { v -> controller.updateParams { it.copy(bassDb = v) } }, -10f..10f)
            ValueSlider("Medios", formatDb(params.midDb), params.midDb, { v -> controller.updateParams { it.copy(midDb = v) } }, -10f..10f)
            ValueSlider("Agudos", formatDb(params.trebleDb), params.trebleDb, { v -> controller.updateParams { it.copy(trebleDb = v) } }, -10f..10f)
        }

        SectionCard("Ganancia y balance") {
            ValueSlider("Preamplificación", formatDb(params.preampDb), params.preampDb, { v -> controller.updateParams { it.copy(preampDb = v) } }, -12f..12f)
            ValueSlider("Ganancia general", formatDb(params.masterDb), params.masterDb, { v -> controller.updateParams { it.copy(masterDb = v) } }, -12f..12f)
            val balanceSupported = engine.capabilities?.balance != false
            ValueSlider(
                "Balance estéreo", balanceText(params.balance), params.balance,
                { v -> controller.updateParams { it.copy(balance = v) } }, -1f..1f, enabled = balanceSupported,
            )
            if (!balanceSupported) InfoText("El balance requiere DynamicsProcessing (Android 9+), que este dispositivo no ofrece.")
            SwitchRow(
                "Margen automático", "Reduce la preamplificación al subir bandas para evitar clipping.",
                params.autoHeadroom, onChange = { v -> controller.updateParams { it.copy(autoHeadroom = v) } },
            )
            if (params.masterDb > 0f && !params.limiterEnabled) {
                InfoText("Ganancia general positiva sin limitador: puede producir clipping en pasajes fuertes.")
            }
        }
    }
}

private fun balanceText(b: Float): String {
    val pct = (abs(b) * 100f).roundToInt()
    return when {
        pct == 0 -> "Centro"
        b < 0f -> "Izquierda $pct %"
        else -> "Derecha $pct %"
    }
}

private fun describeStatus(e: EngineState, enabled: Boolean, bypass: Boolean): Pair<String, String> {
    val sessions = e.chains.count { it.backend != EqBackend.NONE }
    return when {
        !enabled || !e.running -> "Motor apagado" to "Activa el interruptor para iniciar el servicio en segundo plano."
        bypass -> "Sonido original" to "Los efectos están desactivados temporalmente para comparar."
        e.suspended -> "En espera" to "Sin reproducción detectada: los efectos se liberaron para ahorrar batería."
        e.chains.isEmpty() -> "Motor listo, sin sesiones" to "Ninguna app ha anunciado una sesión de audio. Reproduce música en una app compatible (o usa la señal de prueba en Ajustes → Diagnóstico)."
        sessions == 0 -> "Sin efectos disponibles" to "Android rechazó crear efectos. Revisa Ajustes → Diagnóstico."
        else -> "Efectos activos en $sessions sesión(es)" to "${e.backend.label}. Que cada app los respete depende de Android y del fabricante."
    }
}
