# MONO EQ

Ecualizador de audio para Android (Samsung One UI), sin root, instalable con un APK normal.
Kotlin · Jetpack Compose · Material 3 · DataStore · API oficiales de efectos de audio de Android.

> **Estado honesto de este código:** se escribió sin acceso al SDK de Android, así que **no se ha compilado ni
> ejecutado todavía**. Las pruebas unitarias y de integración existen, pero no se han corrido. Mira
> «Verificado / pendiente» al final.

## Compilar el APK

Requisitos: Android Studio (Ladybug o más reciente), JDK 17 (incluido en Android Studio) y conexión para descargar Gradle 8.9.

1. Abre la carpeta `MonoEQ` con **File → Open**. Android Studio descargará Gradle y las dependencias.
2. Espera a que termine el *Sync*. Si sugiere actualizar AGP o Kotlin, puedes aceptar.
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**, o por terminal:
   - `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
   - `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk` (firmado con la clave de depuración; para Google Play usa tu propio keystore)
   - Si no existe `gradlew`, ejecuta una vez `gradle wrapper --gradle-version 8.9` (o usa solo Android Studio).
4. Pruebas: `./gradlew test` (unitarias, en tu PC) y `./gradlew connectedAndroidTest` (integración, con el móvil conectado).

## Compilar en GitHub (sin PC)

1. Crea un repositorio y sube todo el contenido de esta carpeta (incluida `.github/workflows/build.yml`).
2. Abre la pestaña **Actions**. Se ejecuta *Build MONO EQ* con cada push (o pulsa **Run workflow**).
3. Al terminar (unos 5–8 minutos), entra en la ejecución y descarga el artefacto **MonoEQ-debug-apk**.
4. Si falla, abre el paso en rojo, copia el error y envíalo para corregirlo.

## Instalar en un Samsung

1. Pasa el APK al teléfono (cable, Drive, etc.) y ábrelo desde **Mis archivos**.
2. Permite «Instalar apps desconocidas» para esa app cuando Android lo pida.
3. Abre MONO EQ → pestaña **EQ** → activa el interruptor (acepta el permiso de notificaciones).
4. **Importante en One UI:** Ajustes → Batería → Límites de uso en segundo plano → *Apps que nunca se suspenden* → añade MONO EQ. Si no, Samsung puede matar el servicio.
5. Abre Spotify (u otro reproductor), pon música y mira **Ajustes → Diagnóstico**: allí verás si la app anunció su sesión y qué efectos aceptó Android.
6. Para comprobar que el motor suena de verdad: Diagnóstico → **Señal de prueba → Con efectos**, y mueve el ecualizador o pulsa «Escuchar original».

## Cómo intenta cubrir el audio (y por qué hay límites)

Android no deja que una APK normal lea ni modifique el audio de otras apps. Lo único oficial es crear **efectos de audio**
(`Equalizer`, `DynamicsProcessing`, `BassBoost`, `Virtualizer`, `PresetReverb`, `LoudnessEnhancer`) sobre una **sesión de audio**.
MONO EQ usa dos vías:

| Vía | Qué hace | Cobertura real |
|---|---|---|
| **Sesiones de apps** (por defecto) | Escucha los avisos `OPEN/CLOSE_AUDIO_EFFECT_CONTROL_SESSION` que envían los reproductores y crea los efectos en esa sesión. Además se registra como «ecualizador del sistema» para que apps como Spotify puedan abrirlo. | Apps que anuncian su sesión. No cubre las que no lo hacen (muchos navegadores, YouTube, algunos juegos). |
| **Mezcla global (sesión 0)** | Intenta aplicar los efectos a toda la salida. | Obsoleta desde Android 10; muchos dispositivos la ignoran. Se puede comprobar con la prueba «Solo global». |

Motor de ecualización: usa **DynamicsProcessing** (Android 9+) con exactamente 10 bandas (31 Hz–16 kHz), balance por canal y limitador.
Si el dispositivo no lo ofrece, recurre al **Equalizer** nativo y aproxima la curva a las bandas reales del chip.
Los efectos no soportados se marcan como tales; nada se simula.

El **espectro** usa la API `Visualizer` (requiere el permiso de audio aunque no grabe el micrófono). Solo muestra señal real; si la
sesión está en silencio o el sistema bloquea la captura, lo dice en lugar de dibujar datos inventados.
La **curva del ecualizador** se calcula con las ganancias aplicadas al motor; no es una medición del audio.

### Limitaciones que debes conocer

- Si ya estabas reproduciendo cuando se inició MONO EQ, la app no volverá a anunciar su sesión hasta que pause/reanude o la reabras.
- El «3D» es el `Virtualizer` de Android (ensanchado espacial). El sonido 3D posicional real (Spatializer) no está disponible para una APK normal.
- Otra app o los efectos de Samsung (Dolby Atmos, Calidad de sonido) pueden tener prioridad y dejar a MONO EQ «sin control» sobre un efecto.
- Con el motor `Equalizer` (sin DynamicsProcessing) no hay balance ni limitador real.
- Un servicio en primer plano mantiene viva la app; no da acceso al audio de otras apps.
- Android 12+ puede impedir arrancar servicios desde segundo plano; el inicio tras reiniciar usa `BOOT_COMPLETED` y puede variar según fabricante.
- La detección de reproducción (`AudioPlaybackCallback`) puede no ver a otras apps en algunos dispositivos; por eso «Liberar efectos sin reproducción» viene desactivado.

## Permisos

`MODIFY_AUDIO_SETTINGS` (crear efectos) · `RECORD_AUDIO` (solo para el espectro, opcional) · `POST_NOTIFICATIONS` (notificación del servicio) ·
`FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE` (servicio en primer plano) · `RECEIVE_BOOT_COMPLETED` (inicio tras reiniciar).
No se pide ningún permiso de Bluetooth: se detecta el tipo de salida, no el modelo del dispositivo.

## Estructura

```
app/src/main/java/com/monoeq/app/
  domain/    parámetros, bandas, perfiles, curvas (Kotlin puro, probado)
  data/      DataStore: ajustes y perfiles personalizados
  audio/     EqEngine, EffectChain, SpectrumAnalyzer, Fft, TestSignalPlayer, AudioRouteMonitor, AudioController
  service/   AudioEngineService (primer plano), BootReceiver
  ui/        Compose: EQ, Espectro, Efectos, Perfiles, Ajustes y diagnóstico
app/src/test/          pruebas unitarias (parámetros, perfiles, curvas, FFT)
app/src/androidTest/   pruebas de integración (efectos reales en el dispositivo)
```

## Verificado / pendiente

**Hecho en este entorno:** revisión estática del código (balance de llaves y paréntesis, coherencia de firmas entre archivos).

**No ejecutado (pendiente de ti):**
- Compilación con Gradle (puede haber errores de nombres de API o dependencias que solo el compilador detecta).
- Pruebas unitarias (`./gradlew test`) y de integración (`connectedAndroidTest`).
- Comportamiento en un Samsung real: si Spotify/YouTube/Chrome anuncian sesión, si respetan los efectos, si la sesión global funciona en tu modelo.
- Autoinicio tras reiniciar, cambio automático de perfil con Bluetooth/cable, consumo de batería.
- Aspecto visual en pantallas distintas.

Si algo no compila, copia el error de Android Studio y se corrige.
