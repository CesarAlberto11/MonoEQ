package com.monoeq.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.*
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.AccentChoice
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.domain.RouteType

@Composable
fun SettingsScreen(controller: AudioController, settings: AppSettings) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp)) { ScreenHeader("Ajustes y diagnóstico") }
        TabRow(
            selectedTabIndex = tab,
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.primary,
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Ajustes") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Diagnóstico") })
        }
        if (tab == 0) SettingsTab(controller, settings) else DiagnosticsTab(controller, settings)
    }
}

@Composable
private fun SettingsTab(controller: AudioController, s: AppSettings) {
    val ctx = LocalContext.current
    val custom by controller.customProfiles.collectAsStateWithLifecycle()
    val profileNames = remember(custom) { (BuiltInProfiles.all + custom).associate { it.id to it.name } }

    var notificationsGranted by remember { mutableStateOf(notificationsAllowed(ctx)) }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notificationsGranted = it }
    var batteryUnrestricted by remember { mutableStateOf(isIgnoringBatteryOptimizations(ctx)) }
    LifecycleResumeEffect(Unit) {
        batteryUnrestricted = isIgnoringBatteryOptimizations(ctx)
        notificationsGranted = notificationsAllowed(ctx)
        onPauseOrDispose { }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Cobertura del audio") {
            CoverageMode.entries.forEach { mode ->
                Row(
                    Modifier.fillMaxWidth().selectable(selected = s.coverage == mode, role = Role.RadioButton) {
                        controller.updateSettings { it.copy(coverage = mode) }
                    },
                    verticalAlignment = Alignment.Top,
                ) {
                    RadioButton(selected = s.coverage == mode, onClick = null)
                    Column(Modifier.padding(start = 12.dp, bottom = 8.dp)) {
                        Text(mode.label, style = MaterialTheme.typography.bodyLarge)
                        InfoText(mode.description)
                    }
                }
            }
        }

        SectionCard("Segundo plano y automatización") {
            SwitchRow("Iniciar al encender el dispositivo", "Solo si el motor estaba activado. Algunos fabricantes lo limitan.", s.startOnBoot) { v -> controller.updateSettings { it.copy(startOnBoot = v) } }
            SwitchRow("Liberar efectos sin reproducción", "Ahorra batería. Si Android no informa de la reproducción, el procesamiento podría no reanudarse.", s.idleRelease) { v -> controller.updateSettings { it.copy(idleRelease = v) } }
            SwitchRow("Procesar solo con auriculares", "Pausa al quedar solo el altavoz y reanuda al conectar cable, USB o Bluetooth.", s.pauseOnDisconnect) { v -> controller.updateSettings { it.copy(pauseOnDisconnect = v) } }
            SwitchRow("Perfil automático por salida", "Cambia de perfil al detectar la salida de audio.", s.autoProfile) { v -> controller.updateSettings { it.copy(autoProfile = v) } }
            if (s.autoProfile) {
                RouteProfilePicker("Auriculares con cable / USB", RouteType.WIRED, s, profileNames, controller)
                RouteProfilePicker("Bluetooth", RouteType.BLUETOOTH, s, profileNames, controller)
                RouteProfilePicker("Altavoz", RouteType.SPEAKER, s, profileNames, controller)
                InfoText("Se identifica el tipo de salida, no el modelo de cada dispositivo Bluetooth (así no se pide el permiso Bluetooth).")
            }
        }

        SectionCard("Permisos y batería") {
            if (Build.VERSION.SDK_INT >= 33) {
                SwitchRowLike("Notificaciones", if (notificationsGranted) "Concedido" else "Necesario para ver los controles del motor", if (notificationsGranted) null else "Conceder") {
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            SwitchRowLike(
                "Sin restricciones de batería",
                if (batteryUnrestricted) "MONO EQ está excluida de la optimización" else "Samsung puede suspender el servicio si está optimizada",
                if (batteryUnrestricted) null else "Abrir ajustes",
            ) { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            InfoText("En One UI: Ajustes → Batería → Límites de uso en segundo plano → Apps que nunca se suspenden → añade MONO EQ.")
        }

        SectionCard("Apariencia") {
            Text("Color de acento", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AccentChoice.entries.forEach { a ->
                    AccentDot(Color(a.argb), s.accent == a, a.label) { controller.updateSettings { it.copy(accent = a) } }
                }
            }
        }
    }
}

@Composable
private fun SwitchRowLike(title: String, subtitle: String, actionLabel: String?, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            InfoText(subtitle)
        }
        if (actionLabel != null) OutlinedButton(onClick = onAction) { Text(actionLabel) }
    }
}

@Composable
private fun RouteProfilePicker(label: String, route: RouteType, s: AppSettings, names: Map<String, String>, controller: AudioController) {
    var open by remember { mutableStateOf(false) }
    val current = s.routeProfiles[route]
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Box {
            OutlinedButton(onClick = { open = true }) { Text(names[current] ?: "Ninguno") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("Ninguno") }, onClick = { open = false; controller.updateSettings { it.copy(routeProfiles = it.routeProfiles - route) } })
                names.forEach { (id, name) ->
                    DropdownMenuItem(text = { Text(name) }, onClick = { open = false; controller.updateSettings { it.copy(routeProfiles = it.routeProfiles + (route to id)) } })
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsTab(controller: AudioController, s: AppSettings) {
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val sessions by controller.sessions.collectAsStateWithLifecycle()
    val route by controller.route.collectAsStateWithLifecycle()
    val playback by controller.playback.collectAsStateWithLifecycle()
    val serviceActive by controller.serviceActive.collectAsStateWithLifecycle()
    val testRunning by controller.testSignal.running.collectAsStateWithLifecycle()
    val analyzerStatus by controller.analyzer.status.collectAsStateWithLifecycle()
    val bypass by controller.effectiveBypass.collectAsStateWithLifecycle()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Motor") {
            KeyValue("Método de procesamiento", engine.backend.label)
            KeyValue("Cobertura elegida", s.coverage.label)
            KeyValue("Servicio en segundo plano", if (serviceActive) "En ejecución" else "Detenido")
            KeyValue("Estado", when {
                !engine.running -> "Apagado"
                bypass -> "Pausado (sonido original)"
                engine.suspended -> "En espera (sin reproducción)"
                else -> "Efectos habilitados"
            })
            KeyValue("Reproducción detectada", when (playback) {
                PlaybackState.PLAYING -> "Sí"
                PlaybackState.IDLE -> "No"
                PlaybackState.UNKNOWN -> "Desconocido"
            })
            KeyValue("Salida de audio", "${route.type.label}: ${route.name}")
            KeyValue("Analizador de espectro", when (val a = analyzerStatus) {
                AnalyzerStatus.Idle -> "Inactivo"
                AnalyzerStatus.NoPermission -> "Sin permiso de audio"
                is AnalyzerStatus.Running -> "Leyendo la sesión ${a.sessionId}"
                is AnalyzerStatus.Failed -> "Error: ${a.reason}"
            })
            InfoText("«Efectos habilitados» significa que Android aceptó los efectos, no que se haya comprobado que cada app los reproduzca.")
        }

        SectionCard("Sesiones con efectos (${engine.chains.size})") {
            if (engine.chains.isEmpty()) InfoText("Ninguna. Con la cobertura por sesiones, cada app debe anunciar su sesión de audio. Si ya estaba reproduciendo al iniciar MONO EQ, pausa y reanuda la reproducción.")
            engine.chains.forEach { ChainView(it) }
        }

        SectionCard("Sesiones anunciadas por apps (${sessions.size})") {
            if (sessions.isEmpty()) InfoText("Ninguna app ha anunciado sesión desde que se inició el motor.")
            sessions.forEach { InfoText("${it.label} · sesión ${it.sessionId}${it.packageName?.let { p -> " · $p" } ?: ""}") }
        }

        SectionCard("Pruebas reales") {
            InfoText("Estas pruebas se ejecutan en tu dispositivo. Son la única forma fiable de saber qué se aplica de verdad.")
            OutlinedButton(onClick = { controller.runSelfTest() }) { Text("Autodiagnóstico de efectos") }
            engine.selfTest?.let { ChainView(it) }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Text("Señal de prueba (ruido rosa, volumen moderado)", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (testRunning) controller.stopTest() else controller.startTest(withEffects = true) }, enabled = serviceActive) {
                    Text(if (testRunning) "Detener" else "Con efectos")
                }
                OutlinedButton(onClick = { controller.stopTest(); controller.startTest(withEffects = false) }, enabled = serviceActive) { Text("Solo global") }
            }
            InfoText(
                "«Con efectos» aplica la cadena a una sesión propia: si oyes cambios al mover el ecualizador o al pulsar «Escuchar original», " +
                    "el motor funciona. «Solo global» no aplica nada a esa sesión: si aun así oyes cambios, tu dispositivo respeta la sesión global (0) y puedes elegir ese método."
            )
            if (!serviceActive) InfoText("Activa el motor en la pestaña EQ para usar la señal de prueba.")
        }

        SectionCard("Efectos que declara el dispositivo (${engine.deviceEffects.size})") {
            if (engine.deviceEffects.isEmpty()) InfoText("Se muestran al iniciar el motor.")
            engine.deviceEffects.forEach { InfoText(it) }
        }

        SectionCard("Limitaciones de Android sin root") {
            InfoText("• Una APK normal no puede leer ni modificar el audio de otras apps. Solo puede crear efectos de Android sobre sesiones que conoce.")
            InfoText("• La sesión global (0) está obsoleta desde Android 10; muchos dispositivos la ignoran.")
            InfoText("• Las apps que no anuncian su sesión (muchos navegadores, YouTube, algunos juegos) pueden quedar sin ecualizar.")
            InfoText("• Un servicio en primer plano mantiene viva la app; no da acceso al audio de nadie.")
            InfoText("• Otras apps o los efectos de Samsung (Dolby Atmos, Calidad de sonido) pueden tener prioridad sobre un efecto.")
            InfoText("• El sonido 3D posicional real no está disponible para una APK normal.")
        }

        SectionCard("Dispositivo") {
            KeyValue("Modelo", "${Build.MANUFACTURER} ${Build.MODEL}")
            KeyValue("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            semPlatformInt()?.let { KeyValue("Plataforma Samsung (SEM)", it.toString()) }
            KeyValue("MONO EQ", "1.0.0")
        }
    }
}

@Composable
private fun KeyValue(key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(key, Modifier.weight(0.45f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.weight(0.55f), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ChainView(chain: ChainInfo) {
    Surface(Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceContainerLow) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${chain.label} · sesión ${chain.sessionId}", style = MaterialTheme.typography.titleSmall)
            InfoText("Motor: ${chain.backend.label}")
            chain.effects.forEach { e ->
                InfoText("${e.name}: ${e.state.label}${if (e.detail.isNotEmpty()) " – ${e.detail}" else ""}")
            }
        }
    }
}

private fun notificationsAllowed(ctx: Context): Boolean =
    Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

private fun isIgnoringBatteryOptimizations(ctx: Context): Boolean =
    (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)

/** Campo público solo presente en dispositivos Samsung; null en el resto. */
private fun semPlatformInt(): Int? = try {
    Build.VERSION::class.java.getField("SEM_PLATFORM_INT").getInt(null)
} catch (e: Exception) {
    null
}
