package com.monoeq.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.BuildConfig
import com.monoeq.app.audio.AnalyzerStatus
import com.monoeq.app.audio.AudioController
import com.monoeq.app.audio.ChainInfo
import com.monoeq.app.audio.ChainKind
import com.monoeq.app.audio.PlaybackState
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.AccentChoice
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.domain.RouteType

@Composable
fun SettingsScreen(controller: AudioController, settings: AppSettings) {
    val t = LocalStrings.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            ScreenHeader(t.settingsTitle)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton(t.tabSettings, tab == 0, { tab = 0 })
                PillButton(t.tabDiagnostics, tab == 1, { tab = 1 })
            }
        }
        if (tab == 0) SettingsTab(controller, settings) else DiagnosticsTab(controller, settings)
    }
}

@Composable
private fun SettingsTab(controller: AudioController, s: AppSettings) {
    val t = LocalStrings.current
    val ctx = LocalContext.current
    val custom by controller.customProfiles.collectAsStateWithLifecycle()
    val profileNames = (BuiltInProfiles.all + custom).associate { it.id to t.profileName(it) }

    var notificationsGranted by remember { mutableStateOf(notificationsAllowed(ctx)) }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notificationsGranted = it }
    var batteryUnrestricted by remember { mutableStateOf(isIgnoringBatteryOptimizations(ctx)) }
    LifecycleResumeEffect(Unit) {
        batteryUnrestricted = isIgnoringBatteryOptimizations(ctx)
        notificationsGranted = notificationsAllowed(ctx)
        onPauseOrDispose { }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        MonoCard(title = t.cardLanguage) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppLanguage.entries.forEach { lang ->
                    PillButton(lang.nativeName, s.language == lang, { controller.updateSettings { it.copy(language = lang) } })
                }
            }
            InfoText(t.languageNote)
        }

        MonoCard(title = t.cardCoverage) {
            CoverageMode.entries.forEach { mode ->
                Row(
                    Modifier.fillMaxWidth().selectable(selected = s.coverage == mode, role = Role.RadioButton) {
                        controller.updateSettings { it.copy(coverage = mode) }
                    },
                    verticalAlignment = Alignment.Top,
                ) {
                    RadioButton(selected = s.coverage == mode, onClick = null)
                    Column(Modifier.padding(start = 12.dp, bottom = 8.dp)) {
                        Text(t.coverageName(mode), style = MaterialTheme.typography.bodyLarge)
                        InfoText(t.coverageDescription(mode))
                    }
                }
            }
        }

        MonoCard(title = t.cardBackground) {
            SwitchRow(t.setBoot, t.setBootNote, s.startOnBoot) { v -> controller.updateSettings { it.copy(startOnBoot = v) } }
            SwitchRow(t.setIdle, t.setIdleNote, s.idleRelease) { v -> controller.updateSettings { it.copy(idleRelease = v) } }
            SwitchRow(t.setHeadphonesOnly, t.setHeadphonesOnlyNote, s.pauseOnDisconnect) { v -> controller.updateSettings { it.copy(pauseOnDisconnect = v) } }
            SwitchRow(t.setAutoProfile, t.setAutoProfileNote, s.autoProfile) { v -> controller.updateSettings { it.copy(autoProfile = v) } }
            if (s.autoProfile) {
                RouteProfilePicker(t.routeWiredUsb, RouteType.WIRED, s, profileNames, controller)
                RouteProfilePicker(t.routeName(RouteType.BLUETOOTH), RouteType.BLUETOOTH, s, profileNames, controller)
                RouteProfilePicker(t.routeName(RouteType.SPEAKER), RouteType.SPEAKER, s, profileNames, controller)
                InfoText(t.autoProfileNote)
            }
        }

        MonoCard(title = t.cardPermissions) {
            if (Build.VERSION.SDK_INT >= 33) {
                ActionRow(
                    t.permNotifications,
                    if (notificationsGranted) t.permGranted else t.permNotificationsNeeded,
                    if (notificationsGranted) null else t.permGrant,
                ) { notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
            ActionRow(
                t.permBattery,
                if (batteryUnrestricted) t.permBatteryOk else t.permBatteryWarn,
                if (batteryUnrestricted) null else t.permOpenSettings,
            ) { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            InfoText(t.permSamsungHint)
        }

        MonoCard(title = t.cardAppearance) {
            CapsLabel(t.accentLabel)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AccentChoice.entries.forEach { a ->
                    AccentDot(Color(a.argb), s.accent == a, t.accentName(a)) { controller.updateSettings { it.copy(accent = a) } }
                }
            }
        }
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String, actionLabel: String?, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            InfoText(subtitle)
        }
        if (actionLabel != null) PillButton(actionLabel, false, onAction)
    }
}

@Composable
private fun RouteProfilePicker(label: String, route: RouteType, s: AppSettings, names: Map<String, String>, controller: AudioController) {
    val t = LocalStrings.current
    var open by remember { mutableStateOf(false) }
    val current = s.routeProfiles[route]
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Box {
            PillButton(names[current] ?: t.profileNone, current != null, { open = true })
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text(t.profileNone) }, onClick = { open = false; controller.updateSettings { it.copy(routeProfiles = it.routeProfiles - route) } })
                names.forEach { (id, name) ->
                    DropdownMenuItem(text = { Text(name) }, onClick = { open = false; controller.updateSettings { it.copy(routeProfiles = it.routeProfiles + (route to id)) } })
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsTab(controller: AudioController, s: AppSettings) {
    val t = LocalStrings.current
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val sessions by controller.sessions.collectAsStateWithLifecycle()
    val route by controller.route.collectAsStateWithLifecycle()
    val playback by controller.playback.collectAsStateWithLifecycle()
    val serviceActive by controller.serviceActive.collectAsStateWithLifecycle()
    val testRunning by controller.testSignal.running.collectAsStateWithLifecycle()
    val analyzerStatus by controller.analyzer.status.collectAsStateWithLifecycle()
    val bypass by controller.effectiveBypass.collectAsStateWithLifecycle()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        MonoCard(title = t.diagEngine) {
            KeyValue(t.diagMethod, t.backendName(engine.backend))
            KeyValue(t.diagCoverage, t.coverageName(s.coverage))
            KeyValue(t.diagService, if (serviceActive) t.diagRunning else t.diagStopped)
            KeyValue(t.diagState, when {
                !engine.running -> t.diagStateOff
                bypass -> t.diagStatePaused
                engine.suspended -> t.diagStateStandby
                else -> t.diagStateEnabled
            })
            KeyValue(t.diagPlayback, when (playback) {
                PlaybackState.PLAYING -> t.yes
                PlaybackState.IDLE -> t.no
                PlaybackState.UNKNOWN -> t.unknown
            })
            KeyValue(t.diagOutput, t.routeText(t.routeName(route.type), route.deviceName))
            KeyValue(t.diagAnalyzer, when (val a = analyzerStatus) {
                AnalyzerStatus.Idle -> t.diagAnalyzerIdle
                AnalyzerStatus.NoPermission -> t.diagAnalyzerNoPermission
                is AnalyzerStatus.Running -> t.diagAnalyzerRunning(a.sessionId)
                is AnalyzerStatus.Failed -> t.diagAnalyzerFailed(a.reason)
            })
            InfoText(t.diagEnabledNote)
        }

        MonoCard(title = t.diagChains(engine.chains.size)) {
            if (engine.chains.isEmpty()) InfoText(t.diagChainsEmpty)
            engine.chains.forEach { ChainView(it) }
        }

        MonoCard(title = t.diagAnnounced(sessions.size)) {
            if (sessions.isEmpty()) InfoText(t.diagAnnouncedEmpty)
            sessions.forEach { InfoText(t.diagSessionLine(it.label, it.sessionId, it.packageName)) }
        }

        MonoCard(title = t.diagTests) {
            InfoText(t.diagTestsIntro)
            PillButton(t.diagSelfTest, false, { controller.runSelfTest() })
            engine.selfTest?.let { ChainView(it) }
            HorizontalDivider(color = MonoColors.Hairline)
            CapsLabel(t.diagTestSignal)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton(if (testRunning) t.diagStop else t.diagWithEffects, testRunning, { if (testRunning) controller.stopTest() else controller.startTest(withEffects = true) }, enabled = serviceActive)
                PillButton(t.diagGlobalOnly, false, { controller.stopTest(); controller.startTest(withEffects = false) }, enabled = serviceActive)
            }
            InfoText(t.diagTestExplain)
            if (!serviceActive) InfoText(t.diagNeedsEngine)
        }

        MonoCard(title = t.diagDeviceEffects(engine.deviceEffects.size)) {
            if (engine.deviceEffects.isEmpty()) InfoText(t.diagDeviceEffectsEmpty)
            engine.deviceEffects.forEach { InfoText(it) }
        }

        MonoCard(title = t.diagLimitsTitle) {
            t.diagLimits.forEach { InfoText("• $it") }
        }

        MonoCard(title = t.diagDevice) {
            KeyValue(t.diagModel, "${Build.MANUFACTURER} ${Build.MODEL}")
            KeyValue("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            semPlatformInt()?.let { KeyValue(t.diagSamsungPlatform, it.toString()) }
            KeyValue("MONO EQ", BuildConfig.VERSION_NAME)
        }
    }
}

@Composable
private fun KeyValue(key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(key, Modifier.weight(0.45f), style = MaterialTheme.typography.bodySmall, color = MonoColors.MidGray)
        Text(value, Modifier.weight(0.55f), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ChainView(chain: ChainInfo) {
    val t = LocalStrings.current
    val title = when (chain.kind) {
        ChainKind.GLOBAL -> t.chainGlobal
        ChainKind.APP -> chain.label
        ChainKind.TEST -> t.chainTest
        ChainKind.SELF_TEST -> t.chainSelfTest
    }
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF0F0F11), MonoStyle.cardShape).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(t.chainTitle(title, chain.sessionId), style = MaterialTheme.typography.titleSmall)
        InfoText(t.chainEngine(t.backendName(chain.backend)))
        chain.effects.forEach { e ->
            InfoText("${t.effectName(e.id)}: ${t.stateName(e.state)}${if (e.detail.isNotEmpty()) " – ${e.detail}" else ""}")
        }
    }
}

private fun notificationsAllowed(ctx: Context): Boolean =
    Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

private fun isIgnoringBatteryOptimizations(ctx: Context): Boolean =
    (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)

/** Campo público solo presente en dispositivos Samsung; null en el resto. */
private fun semPlatformInt(): Int? = try {
    Build.VERSION::class.java.getField("SEM_PLATFORM_INT").getInt(null)
} catch (e: Exception) {
    null
}
