package com.monoeq.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AudioController
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.Profile

private sealed interface ProfileDialog {
    data object Create : ProfileDialog
    data class Rename(val profile: Profile) : ProfileDialog
    data class Delete(val profile: Profile) : ProfileDialog
}

@Composable
fun ProfilesScreen(controller: AudioController, settings: AppSettings) {
    val custom by controller.customProfiles.collectAsStateWithLifecycle()
    val params by controller.params.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<ProfileDialog?>(null) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 8.dp),
    ) {
        item {
            ScreenHeader("Perfiles", "El último perfil usado se guarda automáticamente")
            Spacer(Modifier.height(4.dp))
            Button(onClick = { dialog = ProfileDialog.Create }, enabled = custom.size < Profile.MAX_CUSTOM) {
                Text("Guardar ajustes actuales como perfil")
            }
        }
        item { SectionLabel("Mis perfiles") }
        if (custom.isEmpty()) item { InfoText("Aún no tienes perfiles propios. Ajusta el ecualizador y guárdalo aquí.") }
        items(custom, key = { it.id }) { p ->
            ProfileRow(p, settings.activeProfileId == p.id, dirty = settings.activeProfileId == p.id && params != p.params, controller) { dialog = it }
        }
        item { SectionLabel("Predefinidos") }
        items(BuiltInProfiles.all, key = { it.id }) { p ->
            ProfileRow(p, settings.activeProfileId == p.id, dirty = settings.activeProfileId == p.id && params != p.params, controller) { dialog = it }
        }
    }

    when (val d = dialog) {
        ProfileDialog.Create -> NameDialog("Nuevo perfil", "", { dialog = null }) { name ->
            controller.saveCurrentAsProfile(name); dialog = null
        }
        is ProfileDialog.Rename -> NameDialog("Renombrar perfil", d.profile.name, { dialog = null }) { name ->
            controller.renameProfile(d.profile.id, name); dialog = null
        }
        is ProfileDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Eliminar perfil") },
            text = { Text("Se eliminará «${d.profile.name}». Esta acción no se puede deshacer.") },
            confirmButton = { TextButton(onClick = { controller.deleteProfile(d.profile.id); dialog = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancelar") } },
        )
        null -> Unit
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
}

@Composable
private fun ProfileRow(profile: Profile, selected: Boolean, dirty: Boolean, controller: AudioController, openDialog: (ProfileDialog) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Surface(
        Modifier.fillMaxWidth().clickable { controller.applyProfile(profile.id) },
        shape = RoundedCornerShape(14.dp),
        color = if (selected) MaterialTheme.colorScheme.surfaceContainerHighest else MaterialTheme.colorScheme.surfaceVariant,
        border = if (selected) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(profile.name, style = MaterialTheme.typography.bodyLarge)
                val sub = when {
                    selected && dirty -> "En uso, con cambios sin guardar"
                    selected -> "En uso"
                    profile.builtIn -> "Predefinido"
                    else -> "Personalizado"
                }
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Opciones de ${profile.name}") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (!profile.builtIn) {
                        if (selected && dirty) DropdownMenuItem(text = { Text("Guardar cambios") }, onClick = { menu = false; controller.updateProfileFromCurrent(profile.id) })
                        DropdownMenuItem(text = { Text("Renombrar") }, onClick = { menu = false; openDialog(ProfileDialog.Rename(profile)) })
                    }
                    DropdownMenuItem(text = { Text("Duplicar") }, onClick = { menu = false; controller.duplicateProfile(profile.id) })
                    if (!profile.builtIn) DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; openDialog(ProfileDialog.Delete(profile)) })
                }
            }
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it.take(Profile.MAX_NAME) }, singleLine = true, label = { Text("Nombre") }) },
        confirmButton = { TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
