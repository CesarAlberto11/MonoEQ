package com.monoeq.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object MonoColors {
    val Black = Color(0xFF0B0B0D)
    val DarkGray = Color(0xFF242428)
    val MidGray = Color(0xFF77777F)
    val LightGray = Color(0xFFC6C6CC)
    val White = Color(0xFFFFFFFF)
    val Hairline = Color(0xFF38383E)
}

@Composable
fun MonoEqTheme(accent: Color, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = MonoColors.Black,
        primaryContainer = MonoColors.DarkGray,
        onPrimaryContainer = MonoColors.White,
        secondary = MonoColors.LightGray,
        onSecondary = MonoColors.Black,
        background = MonoColors.Black,
        onBackground = MonoColors.White,
        surface = MonoColors.Black,
        onSurface = MonoColors.White,
        surfaceVariant = MonoColors.DarkGray,
        onSurfaceVariant = MonoColors.LightGray,
        surfaceContainerLowest = MonoColors.Black,
        surfaceContainerLow = Color(0xFF151518),
        surfaceContainer = Color(0xFF151518),
        surfaceContainerHigh = MonoColors.DarkGray,
        surfaceContainerHighest = Color(0xFF2E2E33),
        outline = MonoColors.MidGray,
        outlineVariant = MonoColors.Hairline,
        error = Color(0xFFE29A9A),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
