package com.monoeq.app.audio

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.util.Log
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.domain.AudioParams
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.i18n.AppStrings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

/**
 * Motor de efectos. Todo el acceso a las API de AudioEffect ocurre en un único hilo,
 * y los cambios de parámetros se fusionan (solo se aplica el último valor pendiente).
 */
class EqEngine(private val context: Context) {
    private val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "mono-eq-engine") }.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)

    private val chains = LinkedHashMap<Int, EffectChain>()
    private val appSessions = LinkedHashMap<Int, AudioSessionInfo>()
    private var testSessionId: Int? = null
    private var params = AudioParams()
    private var bypass = false
    private var running = false
    private var suspended = false
    private var coverage = CoverageMode.SESSIONS
    private var deviceEffects: List<String> = emptyList()
    private var selfTest: ChainInfo? = null
    private var strings: AppStrings = AppStrings.of(AppLanguage.EN)
    private val pendingParams = AtomicReference<AudioParams?>(null)

    private val _state = MutableStateFlow(EngineState())
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private fun post(block: () -> Unit) {
        scope.launch {
            try { block() } catch (e: Throwable) { Log.e(TAG, "Error en el motor", e) }
        }
    }

    fun start(p: AudioParams, mode: CoverageMode, bypassNow: Boolean) = post {
        running = true
        suspended = false
        params = p
        coverage = mode
        bypass = bypassNow
        if (deviceEffects.isEmpty()) deviceEffects = queryDeviceEffects()
        applyAll()
    }

    fun stop() = post {
        running = false
        applyAll()
    }

    fun updateParams(p: AudioParams) {
        pendingParams.set(p)
        post {
            val next = pendingParams.getAndSet(null) ?: return@post
            params = next
            applyAll()
        }
    }

    fun setBypass(value: Boolean) = post { bypass = value; applyAll() }

    /** Cambia el idioma de los textos de estado; reaplica para regenerarlos. */
    fun setStrings(value: AppStrings) = post { strings = value; applyAll() }

    fun setCoverage(mode: CoverageMode) = post { coverage = mode; applyAll() }

    /** Libera todos los efectos sin detener el servicio (modo en espera). */
    fun setSuspended(value: Boolean) = post { suspended = value; applyAll() }

    fun onSessionOpened(info: AudioSessionInfo) = post {
        appSessions.remove(info.sessionId)
        appSessions[info.sessionId] = info
        while (appSessions.size > MAX_APP_SESSIONS) appSessions.remove(appSessions.keys.first())
        suspended = false
        applyAll()
    }

    fun onSessionClosed(sessionId: Int) = post {
        appSessions.remove(sessionId)
        applyAll()
    }

    fun addTestSession(sessionId: Int) = post { testSessionId = sessionId; applyAll() }
    fun removeTestSession() = post { testSessionId = null; applyAll() }

    /** Crea una cadena en una sesión propia y comprueba qué efectos acepta el dispositivo. */
    fun runSelfTest(p: AudioParams) = post {
        val session = (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId()
        if (session <= 0) {
            selfTest = ChainInfo(session, ChainKind.SELF_TEST, "", EqBackend.NONE,
                listOf(EffectStatus(EffectId.DYNAMICS, EffectState.FAILED, strings.dNoSessionId)))
        } else {
            val chain = EffectChain(session, ChainKind.SELF_TEST, "")
            chain.apply(p, true, strings)
            selfTest = chain.info()
            chain.release()
        }
        publish()
    }

    private fun reconcile() {
        val wanted = LinkedHashMap<Int, Pair<ChainKind, String>>()
        if (running && !suspended) {
            if (coverage.usesGlobal) wanted[GLOBAL_SESSION] = ChainKind.GLOBAL to ""
            if (coverage.usesSessions) appSessions.values.forEach { wanted[it.sessionId] = ChainKind.APP to it.label }
            testSessionId?.let { wanted[it] = ChainKind.TEST to "" }
        }
        val iterator = chains.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (!wanted.containsKey(entry.key)) {
                entry.value.release()
                iterator.remove()
            }
        }
        wanted.forEach { (id, w) -> if (!chains.containsKey(id)) chains[id] = EffectChain(id, w.first, w.second) }
    }

    private fun applyAll() {
        reconcile()
        chains.values.forEach { it.apply(params, processing = !bypass, strings = strings) }
        publish()
    }

    private fun publish() {
        val infos = chains.values.map { it.info() }
        val primary = chains.values.firstOrNull { it.backend != EqBackend.NONE }
        val caps = (infos.firstOrNull { it.backend != EqBackend.NONE } ?: selfTest)?.toCapabilities()
        _state.value = EngineState(
            running = running,
            bypass = bypass,
            suspended = suspended,
            coverage = coverage,
            backend = primary?.backend ?: EqBackend.NONE,
            chains = infos,
            appliedBands = primary?.applied.orEmpty(),
            capabilities = caps,
            deviceEffects = deviceEffects,
            selfTest = selfTest,
        )
    }

    private fun queryDeviceEffects(): List<String> = try {
        AudioEffect.queryEffects()?.map { d -> "${d.name} (${typeName(d.type)}) – ${d.implementor}" }.orEmpty()
    } catch (e: Exception) {
        emptyList()
    }

    private fun typeName(type: UUID): String = when (type) {
        AudioEffect.EFFECT_TYPE_EQUALIZER -> "Equalizer"
        AudioEffect.EFFECT_TYPE_BASS_BOOST -> "BassBoost"
        AudioEffect.EFFECT_TYPE_VIRTUALIZER -> "Virtualizer"
        AudioEffect.EFFECT_TYPE_ENV_REVERB -> "Reverb ambiental"
        AudioEffect.EFFECT_TYPE_PRESET_REVERB -> "Reverb preset"
        AudioEffect.EFFECT_TYPE_LOUDNESS_ENHANCER -> "LoudnessEnhancer"
        else -> type.toString().take(8)
    }

    companion object {
        private const val TAG = "MonoEqEngine"
        const val GLOBAL_SESSION = 0
        private const val MAX_APP_SESSIONS = 12
    }
}
