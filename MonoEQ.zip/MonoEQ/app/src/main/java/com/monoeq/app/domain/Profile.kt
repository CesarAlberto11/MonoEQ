package com.monoeq.app.domain

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Profile(val id: String, val name: String, val params: AudioParams, val builtIn: Boolean = false) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("params", params.toJson())

    companion object {
        const val MAX_CUSTOM = 100
        const val MAX_NAME = 40

        fun newId() = "custom_" + UUID.randomUUID().toString()
        fun cleanName(raw: String): String = raw.trim().replace(Regex("\\s+"), " ").take(MAX_NAME)

        fun fromJson(o: JSONObject): Profile? {
            val id = o.optString("id")
            val name = cleanName(o.optString("name"))
            val params = o.optJSONObject("params") ?: return null
            if (id.isEmpty() || name.isEmpty()) return null
            return Profile(id, name, AudioParams.fromJson(params))
        }

        fun listToJson(list: List<Profile>): String = JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }.toString()

        fun listFromJson(json: String?): List<Profile> {
            if (json.isNullOrBlank()) return emptyList()
            return try {
                val arr = JSONArray(json)
                (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(::fromJson) }.take(MAX_CUSTOM)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}

object BuiltInProfiles {
    const val NORMAL_ID = "builtin_normal"

    private fun p(
        bands: FloatArray,
        bassBoost: Float = 0f,
        clarity: Float = 0f,
        width: Float = 0f,
        reverb: ReverbPreset = ReverbPreset.OFF,
        limiter: Boolean = false,
        threshold: Float = -3f,
    ) = AudioParams(
        bands = bands.toList(), bassBoost = bassBoost, vocalClarity = clarity, stereoWidth = width,
        reverb = reverb, limiterEnabled = limiter, limiterThresholdDb = threshold,
    ).sanitized()

    val all: List<Profile> = listOf(
        Profile(NORMAL_ID, "Normal", AudioParams(), true),
        Profile("builtin_bass", "Bass Boost", p(floatArrayOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f), bassBoost = 0.5f, limiter = true), true),
        Profile("builtin_rock", "Rock", p(floatArrayOf(4f, 3f, 2f, -1f, -2f, -1f, 1f, 3f, 4f, 4f)), true),
        Profile("builtin_pop", "Pop", p(floatArrayOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f)), true),
        Profile("builtin_electronic", "Electrónica", p(floatArrayOf(5f, 4f, 1f, 0f, -2f, 2f, 1f, 2f, 4f, 5f), width = 0.3f), true),
        Profile("builtin_hiphop", "Hip-Hop", p(floatArrayOf(5f, 4f, 2f, 3f, -1f, -1f, 1f, -1f, 2f, 3f), bassBoost = 0.3f), true),
        Profile("builtin_jazz", "Jazz", p(floatArrayOf(3f, 2f, 1f, 2f, -2f, -2f, 0f, 1f, 2f, 3f)), true),
        Profile("builtin_classical", "Clásica", p(floatArrayOf(3f, 2f, 1f, 1f, 0f, 0f, 0f, 1f, 2f, 3f), width = 0.2f), true),
        Profile("builtin_vocals", "Voces", p(floatArrayOf(-3f, -3f, -2f, -1f, 1f, 3f, 4f, 3f, 1f, 0f), clarity = 0.5f), true),
        Profile("builtin_podcast", "Podcast", p(floatArrayOf(-5f, -4f, -2f, 0f, 2f, 3f, 3f, 2f, 0f, -2f), clarity = 0.4f, limiter = true), true),
        Profile("builtin_cinema", "Cine", p(floatArrayOf(4f, 3f, 1f, 0f, -1f, 0f, 1f, 2f, 3f, 3f), bassBoost = 0.3f, width = 0.5f), true),
        Profile("builtin_gaming", "Gaming", p(floatArrayOf(3f, 2f, 0f, -1f, 0f, 2f, 4f, 4f, 3f, 1f), clarity = 0.2f, width = 0.4f), true),
        Profile("builtin_night", "Nocturno", p(floatArrayOf(-3f, -2f, 0f, 1f, 1f, 1f, 0f, -1f, -3f, -4f), limiter = true, threshold = -9f), true),
    )

    fun find(id: String, custom: List<Profile>): Profile? = (all + custom).firstOrNull { it.id == id }
}
