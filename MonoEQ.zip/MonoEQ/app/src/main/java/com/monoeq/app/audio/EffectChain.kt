package com.monoeq.app.audio

import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.os.Build
import androidx.annotation.RequiresApi
import com.monoeq.app.domain.AudioParams
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.domain.Balance
import com.monoeq.app.domain.Bands
import com.monoeq.app.domain.ResponseCurve
import com.monoeq.app.domain.ReverbPreset
import com.monoeq.app.i18n.AppStrings
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val EFFECT_PRIORITY = 1

@RequiresApi(Build.VERSION_CODES.P)
private fun createDynamics(session: Int): AudioEffect {
    val cfg = DynamicsProcessing.Config.Builder(
        DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
        2,                   // canales
        true, Bands.COUNT,   // pre-EQ: 10 bandas
        false, 0,            // MBC no usado
        false, 0,            // post-EQ no usado
        true                 // limitador
    ).build()
    return DynamicsProcessing(EFFECT_PRIORITY, session, cfg)
}

/**
 * Cadena de efectos de Android enganchada a UNA sesión de audio (0 = mezcla global).
 * Crear los efectos solo demuestra que Android los aceptó; no prueba que esa sesión
 * esté realmente reproduciendo audio ni que el fabricante los respete.
 */
internal class EffectChain(val sessionId: Int, val kind: ChainKind, val label: String) {
    private var dynamics: AudioEffect? = null
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null
    private var reverb: PresetReverb? = null
    private var created = false
    private var s: AppStrings = AppStrings.of(AppLanguage.EN)
    private val status = LinkedHashMap<EffectId, EffectStatus>()

    var backend: EqBackend = EqBackend.NONE
        private set
    var applied: List<AppliedBand> = emptyList()
        private set

    fun info() = ChainInfo(sessionId, kind, label, backend, status.values.toList())

    private fun set(id: EffectId, state: EffectState, detail: String = "") {
        status[id] = EffectStatus(id, state, detail)
    }

    private fun fail(id: EffectId, e: Throwable) =
        set(id, EffectState.FAILED, "${e.javaClass.simpleName}: ${e.message ?: s.dNoDetail}")

    private fun oneDecimal(x: Float) = (x * 10f).roundToInt() / 10f

    private fun ensureCreated() {
        if (created) return
        created = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                dynamics = createDynamics(sessionId)
                backend = EqBackend.DYNAMICS
                set(EffectId.EQ, EffectState.OFF)
                set(EffectId.GAIN, EffectState.OFF)
            } catch (e: Exception) {
                fail(EffectId.DYNAMICS, e)
            }
        }
        if (backend == EqBackend.NONE) {
            try {
                eq = Equalizer(EFFECT_PRIORITY, sessionId)
                backend = EqBackend.EQUALIZER
                set(EffectId.EQ, EffectState.OFF)
                try {
                    loud = LoudnessEnhancer(sessionId)
                    set(EffectId.GAIN, EffectState.OFF)
                } catch (e: Exception) {
                    fail(EffectId.GAIN, e)
                }
            } catch (e: Exception) {
                fail(EffectId.EQ, e)
            }
        }
        try { bass = BassBoost(EFFECT_PRIORITY, sessionId); set(EffectId.BASS, EffectState.OFF) } catch (e: Exception) { fail(EffectId.BASS, e) }
        try { virt = Virtualizer(EFFECT_PRIORITY, sessionId); set(EffectId.VIRT, EffectState.OFF) } catch (e: Exception) { fail(EffectId.VIRT, e) }
        try { reverb = PresetReverb(EFFECT_PRIORITY, sessionId); set(EffectId.REVERB, EffectState.OFF) } catch (e: Exception) { fail(EffectId.REVERB, e) }
    }

    /** Envía los parámetros al motor. Con [processing] = false apaga todo (sonido original). */
    fun apply(p: AudioParams, processing: Boolean, strings: AppStrings) {
        s = strings
        ensureCreated()
        val b = bass
        val bassNative = b != null && (try { b.strengthSupported } catch (e: Exception) { false })
        val gains = p.effectiveBandGains(emulateBass = !bassNative)
        val preamp = p.effectivePreampDb(gains)

        if (backend == EqBackend.DYNAMICS && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            guard(EffectId.EQ) { applyDynamics(dynamics!!, p, gains, preamp, processing) }
        } else if (backend == EqBackend.EQUALIZER) {
            guard(EffectId.EQ) { applyClassicEq(eq!!, p, gains, preamp, processing) }
            applyLoudness(p, preamp, processing)
        }
        applyBass(p, processing)
        applyVirtualizer(p, processing)
        applyReverb(p, processing)
    }

    private inline fun guard(id: EffectId, block: () -> Unit) {
        try { block() } catch (e: Exception) { fail(id, e) }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun applyDynamics(effect: AudioEffect, p: AudioParams, gains: FloatArray, preDb: Float, on: Boolean) {
        val d = effect as DynamicsProcessing
        if (!on) {
            d.setEnabled(false)
            set(EffectId.EQ, EffectState.OFF, s.dBypass)
            set(EffectId.GAIN, EffectState.OFF, s.dBypass)
            return
        }
        for (i in 0 until Bands.COUNT) {
            d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, Bands.upperEdgesHz[i], gains[i]))
        }
        val (left, right) = Balance.gainsDb(p.balance)
        d.setInputGainbyChannel(0, preDb + left)
        d.setInputGainbyChannel(1, preDb + right)
        val limiter = if (p.limiterEnabled) {
            DynamicsProcessing.Limiter(true, true, 0, 1f, 80f, 12f, p.limiterThresholdDb, p.masterDb)
        } else {
            // Relación 1:1 y umbral 0 dBFS: no comprime; solo aplica la ganancia general.
            DynamicsProcessing.Limiter(true, true, 0, 1f, 80f, 1f, 0f, p.masterDb)
        }
        d.setLimiterAllChannelsTo(limiter)
        d.setEnabled(true)
        applied = List(Bands.COUNT) { AppliedBand(Bands.centersHz[it], gains[it]) }
        val state = if (d.hasControl()) EffectState.ACTIVE else EffectState.NO_CONTROL
        set(EffectId.EQ, state, s.dTenBands(oneDecimal(preDb)))
        set(
            EffectId.GAIN, state,
            if (p.limiterEnabled) s.dLimiterOn(oneDecimal(p.limiterThresholdDb), oneDecimal(p.masterDb))
            else s.dLimiterOff(oneDecimal(p.masterDb))
        )
    }

    private fun applyClassicEq(e: Equalizer, p: AudioParams, gains: FloatArray, preDb: Float, on: Boolean) {
        if (!on) {
            e.setEnabled(false)
            set(EffectId.EQ, EffectState.OFF, s.dBypass)
            return
        }
        val n = e.numberOfBands.toInt()
        val range = e.bandLevelRange
        val minMb = range[0].toInt()
        val maxMb = range[1].toInt()
        // Sin DynamicsProcessing, las bajadas de ganancia se aplican desplazando las bandas.
        val offset = min(preDb, 0f) + min(p.masterDb, 0f)
        val out = ArrayList<AppliedBand>(n)
        for (i in 0 until n) {
            val centerHz = e.getCenterFreq(i.toShort()) / 1000f
            val g = ResponseCurve.gainAt(Bands.centersHz, gains, centerHz) + offset
            val mb = (g * 100f).roundToInt().coerceIn(minMb, maxMb)
            e.setBandLevel(i.toShort(), mb.toShort())
            out += AppliedBand(centerHz, mb / 100f)
        }
        e.setEnabled(true)
        applied = out
        set(EffectId.EQ, if (e.hasControl()) EffectState.ACTIVE else EffectState.NO_CONTROL, s.dNativeBands(n))
    }

    private fun applyLoudness(p: AudioParams, preDb: Float, on: Boolean) {
        val l = loud ?: return
        guard(EffectId.GAIN) {
            val g = max(0f, preDb) + max(0f, p.masterDb)
            if (!on || g < 0.05f) {
                l.setEnabled(false)
                set(EffectId.GAIN, EffectState.OFF, s.dNoPositiveGain)
            } else {
                l.setTargetGain((g * 100f).roundToInt().coerceAtMost(1500))
                l.setEnabled(true)
                set(EffectId.GAIN, if (l.hasControl()) EffectState.ACTIVE else EffectState.NO_CONTROL, s.dPositiveGain(oneDecimal(g)))
            }
        }
    }

    private fun applyBass(p: AudioParams, on: Boolean) {
        val b = bass ?: return
        guard(EffectId.BASS) {
            if (!b.strengthSupported) {
                set(EffectId.BASS, EffectState.UNSUPPORTED, s.dBassEmulated)
                return@guard
            }
            val st = (p.bassBoost * 1000f).roundToInt().coerceIn(0, 1000)
            b.setStrength(st.toShort())
            val active = on && st > 0
            b.setEnabled(active)
            set(EffectId.BASS, if (!active) EffectState.OFF else if (b.hasControl()) EffectState.ACTIVE else EffectState.NO_CONTROL, if (active) s.dStrength(st) else "")
        }
    }

    private fun applyVirtualizer(p: AudioParams, on: Boolean) {
        val v = virt ?: return
        guard(EffectId.VIRT) {
            if (!v.strengthSupported) {
                set(EffectId.VIRT, EffectState.UNSUPPORTED, s.dVirtUnsupported)
                return@guard
            }
            val st = (p.stereoWidth * 1000f).roundToInt().coerceIn(0, 1000)
            v.setStrength(st.toShort())
            val active = on && st > 0
            v.setEnabled(active)
            set(EffectId.VIRT, if (!active) EffectState.OFF else if (v.hasControl()) EffectState.ACTIVE else EffectState.NO_CONTROL, if (active) s.dVirtStrength(st) else "")
        }
    }

    private fun applyReverb(p: AudioParams, on: Boolean) {
        val r = reverb ?: return
        guard(EffectId.REVERB) {
            val preset: Short = when (p.reverb) {
                ReverbPreset.OFF -> PresetReverb.PRESET_NONE
                ReverbPreset.SMALL_ROOM -> PresetReverb.PRESET_SMALLROOM
                ReverbPreset.MEDIUM_ROOM -> PresetReverb.PRESET_MEDIUMROOM
                ReverbPreset.LARGE_ROOM -> PresetReverb.PRESET_LARGEROOM
                ReverbPreset.MEDIUM_HALL -> PresetReverb.PRESET_MEDIUMHALL
                ReverbPreset.LARGE_HALL -> PresetReverb.PRESET_LARGEHALL
                ReverbPreset.PLATE -> PresetReverb.PRESET_PLATE
            }
            r.setPreset(preset)
            val active = on && p.reverb != ReverbPreset.OFF
            r.setEnabled(active)
            set(EffectId.REVERB, if (!active) EffectState.OFF else if (r.hasControl()) EffectState.ACTIVE else EffectState.NO_CONTROL, if (active) s.reverbName(p.reverb) else "")
        }
    }

    fun release() {
        val effects: List<AudioEffect?> = listOf(dynamics, eq, bass, virt, loud, reverb)
        effects.forEach { try { it?.release() } catch (_: Exception) { } }
        dynamics = null; eq = null; bass = null; virt = null; loud = null; reverb = null
    }
}
