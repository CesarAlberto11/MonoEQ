package com.monoeq.app.data

import com.monoeq.app.domain.AccentChoice
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.domain.AudioParams
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.domain.RouteType
import com.monoeq.app.domain.VisualizerMode

data class AppSettings(
    val engineEnabled: Boolean = false,
    val activeProfileId: String = BuiltInProfiles.NORMAL_ID,
    val params: AudioParams = AudioParams(),
    val coverage: CoverageMode = CoverageMode.SESSIONS,
    val startOnBoot: Boolean = true,
    /** Libera los efectos cuando Android no informa de reproducción (ahorra batería). */
    val idleRelease: Boolean = false,
    /** Procesa solo con auriculares, USB o Bluetooth conectados. */
    val pauseOnDisconnect: Boolean = false,
    val autoProfile: Boolean = false,
    /** Perfil por tipo de salida: solo se usan WIRED, BLUETOOTH y SPEAKER. */
    val routeProfiles: Map<RouteType, String> = emptyMap(),
    val accent: AccentChoice = AccentChoice.WHITE,
    val smoothing: Float = 0.6f,
    val visualizerMode: VisualizerMode = VisualizerMode.BARS,
    /** Inglés por defecto; se cambia a español en Ajustes. */
    val language: AppLanguage = AppLanguage.EN,
)
