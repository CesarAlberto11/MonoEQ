package com.monoeq.app.i18n

import com.monoeq.app.audio.EffectId
import com.monoeq.app.audio.EffectState
import com.monoeq.app.audio.EqBackend
import com.monoeq.app.domain.AccentChoice
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.domain.Profile
import com.monoeq.app.domain.ReverbPreset
import com.monoeq.app.domain.RouteType
import com.monoeq.app.domain.VisualizerMode
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Todos los textos de la app en inglés (por defecto) y español.
 * Cada texto se define una sola vez con tr(inglés, español), así no puede faltar un idioma.
 */
class AppStrings private constructor(val lang: AppLanguage) {
    private fun tr(en: String, es: String) = if (lang == AppLanguage.ES) es else en

    // ---- Navegación ----
    val navEq = tr("EQ", "EQ")
    val navSpectrum = tr("Spectrum", "Espectro")
    val navEffects = tr("Effects", "Efectos")
    val navProfiles = tr("Profiles", "Perfiles")
    val navSettings = tr("Settings", "Ajustes")

    // ---- Ecualizador ----
    val powerDescription = tr("Turn the audio engine on or off", "Encender o apagar el motor de audio")
    fun outputLine(route: String, device: String) = tr("Output: ", "Salida: ") + routeText(route, device)
    fun routeText(route: String, device: String) = if (device.isBlank()) route else "$route – $device"
    val pillOriginal = tr("A/B original", "A/B original")
    val pillHeadroom = tr("Auto headroom", "Margen auto")
    val pillReset = tr("Reset", "Restablecer")
    val cardResponse = tr("Applied response", "Respuesta aplicada")
    val cardResponsePreview = tr("Response preview", "Vista previa de la respuesta")
    val responsePreviewNote = tr(
        "Engine off or no sessions: the dashed line shows the values that would be sent.",
        "Motor apagado o sin sesiones: la línea discontinua muestra los valores que se enviarían."
    )
    val responseAppliedNote = tr(
        "Calculated from the gains currently applied to the engine; it is not a measurement of the audio.",
        "Calculada con las ganancias que el motor tiene aplicadas; no es una medición del audio."
    )
    fun responseFewBands(n: Int) = tr(
        "This device only offers $n native bands, so the 10-band curve is approximated.",
        "Este dispositivo solo ofrece $n bandas nativas: la curva de 10 bandas se aproxima."
    )
    val cardBands = tr("10-band equalizer", "Ecualizador de 10 bandas")
    val bandsHint = tr("Values in dB (−12 to +12). Tap or drag each band.", "Valores en dB (−12 a +12). Toca o arrastra cada banda.")
    val cardTone = tr("Tone", "Tono")
    val toneBass = tr("Bass", "Graves")
    val toneMid = tr("Mid", "Medios")
    val toneTreble = tr("Treble", "Agudos")
    val cardGain = tr("Gain & balance", "Ganancia y balance")
    val knobPreamp = tr("Preamp", "Preamp")
    val knobMaster = tr("Master", "General")
    val knobBalance = tr("Balance", "Balance")
    fun balanceText(b: Float): String {
        val pct = (abs(b) * 100f).roundToInt()
        return when {
            pct == 0 -> tr("Center", "Centro")
            b < 0f -> tr("L $pct %", "Izq. $pct %")
            else -> tr("R $pct %", "Der. $pct %")
        }
    }
    val knobsHint = tr("Drag a knob up or down. Double-tap to reset it.", "Arrastra una perilla hacia arriba o abajo. Doble toque para restablecerla.")
    val balanceUnsupported = tr(
        "Balance needs DynamicsProcessing (Android 9+), which this device doesn't offer.",
        "El balance requiere DynamicsProcessing (Android 9+), que este dispositivo no ofrece."
    )
    val masterClipWarning = tr(
        "Positive master gain without the limiter can clip on loud passages.",
        "Una ganancia general positiva sin limitador puede producir clipping en pasajes fuertes."
    )

    // ---- Estado del motor ----
    val statusOffTitle = tr("Engine off", "Motor apagado")
    val statusOffDetail = tr("Press the power button to start the background service.", "Pulsa el botón de encendido para iniciar el servicio en segundo plano.")
    val statusOriginalTitle = tr("Original sound", "Sonido original")
    val statusOriginalDetail = tr("Effects are temporarily off so you can compare.", "Los efectos están desactivados temporalmente para comparar.")
    val statusStandbyTitle = tr("Standby", "En espera")
    val statusStandbyDetail = tr("No playback detected: effects were released to save battery.", "Sin reproducción detectada: los efectos se liberaron para ahorrar batería.")
    val statusNoSessionsTitle = tr("Engine ready, no sessions", "Motor listo, sin sesiones")
    val statusNoSessionsDetail = tr(
        "No app has announced an audio session yet. Play music in a compatible app, or use the test signal in Settings → Diagnostics.",
        "Ninguna app ha anunciado una sesión de audio. Reproduce música en una app compatible o usa la señal de prueba en Ajustes → Diagnóstico."
    )
    val statusNoEffectsTitle = tr("No effects available", "Sin efectos disponibles")
    val statusNoEffectsDetail = tr("Android refused to create effects. Check Settings → Diagnostics.", "Android rechazó crear efectos. Revisa Ajustes → Diagnóstico.")
    fun statusActiveTitle(n: Int) = tr("Effects active on $n session(s)", "Efectos activos en $n sesión(es)")
    fun statusActiveDetail(backend: String) = tr(
        "$backend. Whether each app honors them depends on Android and the manufacturer.",
        "$backend. Que cada app los respete depende de Android y del fabricante."
    )

    // ---- Efectos ----
    val effectsTitle = tr("Effects", "Efectos")
    val effectsSubtitle = tr("Only effects Android can really apply are enabled", "Solo se activan efectos que Android puede aplicar de verdad")
    val pillCompare = tr("Compare with original", "Comparar con el original")
    val capsUnknown = tr(
        "Real compatibility is checked when the engine starts, or with the self-test (Settings → Diagnostics).",
        "La compatibilidad real se comprueba al activar el motor o con el autodiagnóstico (Ajustes → Diagnóstico)."
    )
    val toggleBass = tr("Bass", "Graves")
    val toggleBassCaption = tr("Boost", "Refuerzo")
    val toggleVocal = tr("Vocal", "Voz")
    val toggleVocalCaption = tr("Clarity", "Claridad")
    val toggleReverb = tr("Reverb", "Reverb")
    val toggleReverbCaption = tr("Hall", "Salón")
    val toggleSpatial = tr("Spatial", "Espacial")
    val toggleSpatialCaption = tr("Wide", "Amplio")
    val cardBassVoice = tr("Bass & voice", "Graves y voz")
    val sliderBassBoost = tr("Bass boost", "Refuerzo de graves")
    val bassEmulatedNote = tr(
        "This device has no native BassBoost: it is emulated by raising the lows of the equalizer by up to 6 dB.",
        "Este dispositivo no tiene BassBoost nativo: se emula subiendo hasta 6 dB los graves del ecualizador."
    )
    val sliderVocal = tr("Vocal clarity", "Claridad vocal")
    val vocalNote = tr(
        "Vocal clarity uses the equalizer curve: it lifts 2–4 kHz and gently cuts around 300 Hz.",
        "La claridad vocal usa la curva del ecualizador: realza 2–4 kHz y recorta suavemente cerca de 300 Hz."
    )
    val cardSpace = tr("Space", "Espacio")
    val sliderStereo = tr("Stereo width", "Amplitud estéreo")
    val stereoNote = tr(
        "Uses Android's Virtualizer (spatial widening). It is not true positional 3D sound: Android doesn't let a regular APK enable the system Spatializer.",
        "Usa el Virtualizer de Android (ensanchado espacial). No es sonido 3D posicional real: Android no permite que una APK active el Spatializer del sistema."
    )
    val virtualizerMissing = tr("This device doesn't offer a Virtualizer.", "Este dispositivo no ofrece Virtualizer.")
    val labelReverb = tr("Reverb", "Reverberación")
    val reverbMissing = tr("This device doesn't offer preset reverb.", "Este dispositivo no ofrece reverberación por preajuste.")
    val reverbNote = tr(
        "Android only allows presets. On some devices the reverb is accepted but barely audible.",
        "Android solo permite elegir preajustes. En algunos dispositivos la reverberación se acepta pero casi no se oye."
    )
    val cardDynamics = tr("Dynamics", "Dinámica")
    val pillLimiter = tr("Limiter", "Limitador")
    val limiterNote = tr("Prevents clipping when you raise the gain or the bands.", "Evita el clipping cuando subes ganancia o bandas.")
    val sliderThreshold = tr("Threshold", "Umbral")
    val limiterMissing = tr(
        "The limiter needs DynamicsProcessing (Android 9+), which this device doesn't offer.",
        "El limitador requiere DynamicsProcessing (Android 9+), que este dispositivo no ofrece."
    )

    // ---- Espectro ----
    val vizTitle = tr("Spectrum", "Espectro")
    val vizSubtitle = tr("Real signal from the chosen session; never simulated data", "Señal real de la sesión elegida; nunca datos simulados")
    fun vizModeName(m: VisualizerMode) = when (m) {
        VisualizerMode.BARS -> tr("Bars", "Barras")
        VisualizerMode.CURVE -> tr("Curve", "Curva")
        VisualizerMode.METER -> tr("Meter", "Medidor")
    }
    val vizLive = tr("Live FFT spectrum", "Espectro FFT en vivo")
    val vizLegend = tr("Line: signal · Dashed: EQ", "Línea: señal · Discontinua: EQ")
    val vizNeedsEngine = tr("Turn the engine on in the EQ tab to analyze audio.", "Activa el motor en la pestaña EQ para analizar el audio.")
    val vizPermissionText = tr(
        "Android requires the audio permission to read a session's spectrum (Visualizer API). MONO EQ does not record the microphone.",
        "Android exige el permiso de audio para leer el espectro de una sesión (API Visualizer). MONO EQ no graba el micrófono."
    )
    val vizGrantPermission = tr("Grant permission", "Conceder permiso")
    fun vizFailed(reason: String) = tr("Couldn't open the analyzer on this session: $reason", "No se pudo abrir el analizador en esta sesión: $reason")
    val vizNoSignal = tr(
        "No real signal on the chosen session: silence, no playback, or capture blocked by the system or the app. No simulated data is shown.",
        "Sin señal real en la sesión elegida: silencio, sesión sin reproducción o captura bloqueada por el sistema o la app. No se muestran datos simulados."
    )
    val vizRms = tr("RMS", "RMS")
    val vizPeak = tr("Peak", "Pico")
    val vizInputLevel = tr("Input level", "Nivel de entrada")
    val vizClip = tr("Clip", "Clip")
    val cardSource = tr("Source", "Fuente")
    val srcAuto = tr("Auto", "Auto")
    val srcGlobal = tr("Global mix (0)", "Mezcla global (0)")
    val srcTest = tr("Test signal", "Señal de prueba")
    val srcHint = tr(
        "Auto picks the test signal, else the last session announced by an app, else the global mix. The global mix is usually blocked on Android 10 and later.",
        "Auto elige la señal de prueba, la última sesión anunciada por una app o, si no hay ninguna, la mezcla global. La mezcla global suele estar bloqueada en Android 10 o superior."
    )
    val testStart = tr("Play test signal", "Reproducir señal de prueba")
    val testStop = tr("Stop test signal", "Detener señal de prueba")
    val vizSmoothing = tr("Smoothing", "Suavizado")
    val vizResolutionNote = tr(
        "The spectrum has 8-bit resolution (about 48 dB of range) and is measured before the system applies its own effects.",
        "El espectro tiene resolución de 8 bits (unos 48 dB de rango) y se mide antes de que el sistema aplique sus propios efectos."
    )

    // ---- Perfiles ----
    val profilesTitle = tr("Profiles", "Perfiles")
    val profilesSubtitle = tr("The last profile used is saved automatically", "El último perfil usado se guarda automáticamente")
    val pillSaveProfile = tr("Save current as profile", "Guardar ajustes actuales")
    val profilesMine = tr("My profiles", "Mis perfiles")
    val profilesEmpty = tr("You have no custom profiles yet. Adjust the equalizer and save it here.", "Aún no tienes perfiles propios. Ajusta el ecualizador y guárdalo aquí.")
    val profilesBuiltIn = tr("Built-in", "Predefinidos")
    val profileInUse = tr("In use", "En uso")
    val profileInUseDirty = tr("In use, with unsaved changes", "En uso, con cambios sin guardar")
    val profileBuiltIn = tr("Built-in", "Predefinido")
    val profileCustom = tr("Custom", "Personalizado")
    val profileNone = tr("None", "Ninguno")
    val menuSaveChanges = tr("Save changes", "Guardar cambios")
    val menuRename = tr("Rename", "Renombrar")
    val menuDuplicate = tr("Duplicate", "Duplicar")
    val menuDelete = tr("Delete", "Eliminar")
    fun profileOptions(name: String) = tr("Options for $name", "Opciones de $name")
    val dialogNewProfile = tr("New profile", "Nuevo perfil")
    val dialogRenameProfile = tr("Rename profile", "Renombrar perfil")
    val dialogName = tr("Name", "Nombre")
    val dialogSave = tr("Save", "Guardar")
    val dialogCancel = tr("Cancel", "Cancelar")
    val dialogDeleteTitle = tr("Delete profile", "Eliminar perfil")
    fun dialogDeleteBody(name: String) = tr("“$name” will be deleted. This can't be undone.", "Se eliminará «$name». Esta acción no se puede deshacer.")
    val dialogDelete = tr("Delete", "Eliminar")
    val copySuffix = tr(" (copy)", " (copia)")

    /** Los perfiles predefinidos se traducen por id; los personalizados conservan el nombre del usuario. */
    fun profileName(p: Profile): String {
        if (!p.builtIn) return p.name
        return when (p.id) {
            "builtin_normal" -> "Normal"
            "builtin_bass" -> "Bass Boost"
            "builtin_rock" -> "Rock"
            "builtin_pop" -> "Pop"
            "builtin_electronic" -> tr("Electronic", "Electrónica")
            "builtin_hiphop" -> "Hip-Hop"
            "builtin_jazz" -> "Jazz"
            "builtin_classical" -> tr("Classical", "Clásica")
            "builtin_vocals" -> tr("Vocals", "Voces")
            "builtin_podcast" -> "Podcast"
            "builtin_cinema" -> tr("Cinema", "Cine")
            "builtin_gaming" -> "Gaming"
            "builtin_night" -> tr("Night", "Nocturno")
            else -> p.name
        }
    }

    // ---- Ajustes ----
    val settingsTitle = tr("Settings", "Ajustes")
    val tabSettings = tr("Settings", "Ajustes")
    val tabDiagnostics = tr("Diagnostics", "Diagnóstico")
    val cardLanguage = tr("Language", "Idioma")
    val languageNote = tr("English is the default. The change applies immediately.", "El inglés es el idioma por defecto. El cambio se aplica al instante.")
    val cardCoverage = tr("Audio coverage", "Cobertura del audio")
    fun coverageName(m: CoverageMode) = when (m) {
        CoverageMode.SESSIONS -> tr("App sessions (recommended)", "Sesiones de apps (recomendado)")
        CoverageMode.GLOBAL -> tr("Global mix (session 0)", "Mezcla global (sesión 0)")
        CoverageMode.BOTH -> tr("Both (may double the effect)", "Ambos (puede duplicar el efecto)")
    }
    fun coverageDescription(m: CoverageMode) = when (m) {
        CoverageMode.SESSIONS -> tr(
            "Applies the effects to the audio sessions each app announces to Android. Works with Spotify, many players and apps that respect the system equalizer.",
            "Aplica los efectos a las sesiones de audio que cada app anuncia a Android. Funciona con Spotify, muchos reproductores y apps que respetan el ecualizador del sistema."
        )
        CoverageMode.GLOBAL -> tr(
            "Tries to apply the effects to the whole output mix. Android deprecated it in version 10 and many devices ignore it. Use the test in Diagnostics to check.",
            "Intenta aplicar los efectos a toda la mezcla de salida. Android la marcó como obsoleta desde la versión 10 y muchos dispositivos la ignoran. Usa la prueba de Diagnóstico para comprobarlo."
        )
        CoverageMode.BOTH -> tr(
            "Enables both methods. If your device honors the global session, the equalizer would be applied twice.",
            "Activa los dos métodos. Si tu dispositivo respeta la sesión global, el ecualizador se aplicaría dos veces."
        )
    }
    val cardBackground = tr("Background & automation", "Segundo plano y automatización")
    val setBoot = tr("Start at boot", "Iniciar al encender el dispositivo")
    val setBootNote = tr("Only if the engine was on. Some manufacturers limit this.", "Solo si el motor estaba activado. Algunos fabricantes lo limitan.")
    val setIdle = tr("Release effects when idle", "Liberar efectos sin reproducción")
    val setIdleNote = tr(
        "Saves battery. If Android doesn't report playback, processing might not resume.",
        "Ahorra batería. Si Android no informa de la reproducción, el procesamiento podría no reanudarse."
    )
    val setHeadphonesOnly = tr("Process only with headphones", "Procesar solo con auriculares")
    val setHeadphonesOnlyNote = tr(
        "Pauses on the speaker and resumes when a wired, USB or Bluetooth output connects.",
        "Pausa al quedar solo el altavoz y reanuda al conectar cable, USB o Bluetooth."
    )
    val setAutoProfile = tr("Automatic profile per output", "Perfil automático por salida")
    val setAutoProfileNote = tr("Switches profile when the audio output changes.", "Cambia de perfil al detectar la salida de audio.")
    val routeWiredUsb = tr("Wired / USB headphones", "Auriculares con cable / USB")
    val autoProfileNote = tr(
        "The output type is detected, not each Bluetooth device's model (so no Bluetooth permission is needed).",
        "Se identifica el tipo de salida, no el modelo de cada dispositivo Bluetooth (así no se pide el permiso Bluetooth)."
    )
    val cardPermissions = tr("Permissions & battery", "Permisos y batería")
    val permNotifications = tr("Notifications", "Notificaciones")
    val permGranted = tr("Granted", "Concedido")
    val permNotificationsNeeded = tr("Needed to show the engine controls", "Necesario para ver los controles del motor")
    val permGrant = tr("Grant", "Conceder")
    val permBattery = tr("Unrestricted battery", "Sin restricciones de batería")
    val permBatteryOk = tr("MONO EQ is excluded from optimization", "MONO EQ está excluida de la optimización")
    val permBatteryWarn = tr("Samsung may suspend the service if the app is optimized", "Samsung puede suspender el servicio si la app está optimizada")
    val permOpenSettings = tr("Open settings", "Abrir ajustes")
    val permSamsungHint = tr(
        "On One UI: Settings → Battery → Background usage limits → Never sleeping apps → add MONO EQ.",
        "En One UI: Ajustes → Batería → Límites de uso en segundo plano → Apps que nunca se suspenden → añade MONO EQ."
    )
    val cardAppearance = tr("Appearance", "Apariencia")
    val accentLabel = tr("Accent color", "Color de acento")
    fun accentName(a: AccentChoice) = when (a) {
        AccentChoice.WHITE -> tr("White", "Blanco")
        AccentChoice.STEEL -> tr("Steel", "Acero")
        AccentChoice.SAGE -> tr("Sage", "Salvia")
        AccentChoice.AMBER -> tr("Amber", "Ámbar")
        AccentChoice.ROSE -> tr("Rose", "Rosa")
    }

    // ---- Diagnóstico ----
    val diagEngine = tr("Engine", "Motor")
    val diagMethod = tr("Processing method", "Método de procesamiento")
    val diagCoverage = tr("Chosen coverage", "Cobertura elegida")
    val diagService = tr("Background service", "Servicio en segundo plano")
    val diagRunning = tr("Running", "En ejecución")
    val diagStopped = tr("Stopped", "Detenido")
    val diagState = tr("State", "Estado")
    val diagStateOff = tr("Off", "Apagado")
    val diagStatePaused = tr("Paused (original sound)", "Pausado (sonido original)")
    val diagStateStandby = tr("Standby (no playback)", "En espera (sin reproducción)")
    val diagStateEnabled = tr("Effects enabled", "Efectos habilitados")
    val diagPlayback = tr("Playback detected", "Reproducción detectada")
    val yes = tr("Yes", "Sí")
    val no = tr("No", "No")
    val unknown = tr("Unknown", "Desconocido")
    val diagOutput = tr("Audio output", "Salida de audio")
    val diagAnalyzer = tr("Spectrum analyzer", "Analizador de espectro")
    val diagAnalyzerIdle = tr("Idle", "Inactivo")
    val diagAnalyzerNoPermission = tr("No audio permission", "Sin permiso de audio")
    fun diagAnalyzerRunning(session: Int) = tr("Reading session $session", "Leyendo la sesión $session")
    fun diagAnalyzerFailed(reason: String) = tr("Error: $reason", "Error: $reason")
    val diagEnabledNote = tr(
        "“Effects enabled” means Android accepted the effects, not that each app is confirmed to play them.",
        "«Efectos habilitados» significa que Android aceptó los efectos, no que se haya comprobado que cada app los reproduzca."
    )
    fun diagChains(n: Int) = tr("Sessions with effects ($n)", "Sesiones con efectos ($n)")
    val diagChainsEmpty = tr(
        "None. With session coverage, each app must announce its audio session. If it was already playing when MONO EQ started, pause and resume playback.",
        "Ninguna. Con la cobertura por sesiones, cada app debe anunciar su sesión de audio. Si ya estaba reproduciendo al iniciar MONO EQ, pausa y reanuda la reproducción."
    )
    fun diagAnnounced(n: Int) = tr("Sessions announced by apps ($n)", "Sesiones anunciadas por apps ($n)")
    val diagAnnouncedEmpty = tr("No app has announced a session since the engine started.", "Ninguna app ha anunciado sesión desde que se inició el motor.")
    fun diagSessionLine(label: String, session: Int, pkg: String?) =
        tr("$label · session $session", "$label · sesión $session") + (if (pkg != null) " · $pkg" else "")
    val diagTests = tr("Real tests", "Pruebas reales")
    val diagTestsIntro = tr(
        "These tests run on your device. They're the only reliable way to know what really applies.",
        "Estas pruebas se ejecutan en tu dispositivo. Son la única forma fiable de saber qué se aplica de verdad."
    )
    val diagSelfTest = tr("Effects self-test", "Autodiagnóstico de efectos")
    val diagTestSignal = tr("Test signal (pink noise, moderate volume)", "Señal de prueba (ruido rosa, volumen moderado)")
    val diagWithEffects = tr("With effects", "Con efectos")
    val diagStop = tr("Stop", "Detener")
    val diagGlobalOnly = tr("Global only", "Solo global")
    val diagTestExplain = tr(
        "“With effects” applies the chain to an own session: if you hear changes when moving the equalizer or pressing “A/B original”, the engine works. “Global only” applies nothing to that session: if you still hear changes, your device honors the global session (0) and you can choose that method.",
        "«Con efectos» aplica la cadena a una sesión propia: si oyes cambios al mover el ecualizador o al pulsar «A/B original», el motor funciona. «Solo global» no aplica nada a esa sesión: si aun así oyes cambios, tu dispositivo respeta la sesión global (0) y puedes elegir ese método."
    )
    val diagNeedsEngine = tr("Turn the engine on in the EQ tab to use the test signal.", "Activa el motor en la pestaña EQ para usar la señal de prueba.")
    fun diagDeviceEffects(n: Int) = tr("Effects the device declares ($n)", "Efectos que declara el dispositivo ($n)")
    val diagDeviceEffectsEmpty = tr("Shown when the engine starts.", "Se muestran al iniciar el motor.")
    val diagLimitsTitle = tr("Limits of Android without root", "Limitaciones de Android sin root")
    val diagLimits: List<String> = listOf(
        tr("A regular APK can't read or modify other apps' audio. It can only create Android audio effects on sessions it knows about.",
            "Una APK normal no puede leer ni modificar el audio de otras apps. Solo puede crear efectos de Android sobre sesiones que conoce."),
        tr("The global session (0) has been deprecated since Android 10; many devices ignore it.",
            "La sesión global (0) está obsoleta desde Android 10; muchos dispositivos la ignoran."),
        tr("Apps that don't announce their session (many browsers, YouTube, some games) may stay unequalized.",
            "Las apps que no anuncian su sesión (muchos navegadores, YouTube, algunos juegos) pueden quedar sin ecualizar."),
        tr("A foreground service keeps the app alive; it doesn't give access to anyone's audio.",
            "Un servicio en primer plano mantiene viva la app; no da acceso al audio de nadie."),
        tr("Other apps or Samsung effects (Dolby Atmos, Sound quality) may take priority over an effect.",
            "Otras apps o los efectos de Samsung (Dolby Atmos, Calidad de sonido) pueden tener prioridad sobre un efecto."),
        tr("True positional 3D sound isn't available to a regular APK.",
            "El sonido 3D posicional real no está disponible para una APK normal."),
    )
    val diagDevice = tr("Device", "Dispositivo")
    val diagModel = tr("Model", "Modelo")
    val diagSamsungPlatform = tr("Samsung platform (SEM)", "Plataforma Samsung (SEM)")
    val chainGlobal = tr("Global mix (session 0)", "Mezcla global (sesión 0)")
    val chainTest = tr("Own test session", "Sesión de prueba propia")
    val chainSelfTest = tr("Self-test (own session)", "Autodiagnóstico (sesión propia)")
    fun chainTitle(title: String, session: Int) = tr("$title · session $session", "$title · sesión $session")
    fun chainEngine(backend: String) = tr("Engine: $backend", "Motor: $backend")

    fun effectName(id: EffectId) = when (id) {
        EffectId.DYNAMICS -> "DynamicsProcessing"
        EffectId.EQ -> tr("Equalizer", "Ecualizador")
        EffectId.GAIN -> tr("Gain & limiter", "Ganancia y limitador")
        EffectId.BASS -> tr("Bass boost", "Refuerzo de graves")
        EffectId.VIRT -> tr("Stereo width", "Amplitud estéreo")
        EffectId.REVERB -> tr("Reverb", "Reverberación")
    }
    fun stateName(s: EffectState) = when (s) {
        EffectState.ACTIVE -> tr("Active", "Activo")
        EffectState.OFF -> tr("Off", "Apagado")
        EffectState.UNSUPPORTED -> tr("Unsupported", "No soportado")
        EffectState.FAILED -> tr("Error", "Error")
        EffectState.NO_CONTROL -> tr("No control", "Sin control")
    }
    fun backendName(b: EqBackend) = when (b) {
        EqBackend.NONE -> tr("No engine", "Sin motor")
        EqBackend.DYNAMICS -> tr("DynamicsProcessing (exact 10 bands)", "DynamicsProcessing (10 bandas exactas)")
        EqBackend.EQUALIZER -> tr("Native Equalizer (device bands)", "Equalizer nativo (bandas del dispositivo)")
    }
    fun routeName(r: RouteType) = when (r) {
        RouteType.SPEAKER -> tr("Speaker", "Altavoz")
        RouteType.WIRED -> tr("Wired headphones", "Auriculares con cable")
        RouteType.USB -> tr("USB audio", "Audio USB")
        RouteType.BLUETOOTH -> "Bluetooth"
        RouteType.UNKNOWN -> tr("Unknown", "Desconocida")
    }
    fun reverbName(r: ReverbPreset) = when (r) {
        ReverbPreset.OFF -> tr("Off", "Desactivada")
        ReverbPreset.SMALL_ROOM -> tr("Small room", "Sala pequeña")
        ReverbPreset.MEDIUM_ROOM -> tr("Medium room", "Sala media")
        ReverbPreset.LARGE_ROOM -> tr("Large room", "Sala grande")
        ReverbPreset.MEDIUM_HALL -> tr("Medium hall", "Salón medio")
        ReverbPreset.LARGE_HALL -> tr("Large hall", "Salón grande")
        ReverbPreset.PLATE -> "Plate"
    }

    // ---- Detalles del estado de cada efecto (los genera el motor) ----
    val dNoDetail = tr("no details", "sin detalle")
    val dNoSessionId = tr("Android didn't generate a session ID", "Android no generó un ID de sesión")
    val dBypass = tr("Original sound", "Sonido original")
    fun dTenBands(preDb: Float) = tr("10 bands, preamp $preDb dB", "10 bandas, preamp $preDb dB")
    fun dLimiterOn(thresholdDb: Float, masterDb: Float) = tr("Limiter $thresholdDb dB, master $masterDb dB", "Limitador $thresholdDb dB, general $masterDb dB")
    fun dLimiterOff(masterDb: Float) = tr("No limiter, master $masterDb dB", "Sin limitador, general $masterDb dB")
    fun dNativeBands(n: Int) = tr("$n native bands (the 10-band curve is approximated)", "$n bandas nativas (se aproxima la curva de 10 bandas)")
    val dNoPositiveGain = tr("No positive gain; no limiter in this method", "Sin ganancia positiva; sin limitador en este método")
    fun dPositiveGain(db: Float) = tr("+$db dB (LoudnessEnhancer, no real limiter)", "+$db dB (LoudnessEnhancer, sin limitador real)")
    val dBassEmulated = tr("No native BassBoost: emulated with the equalizer curve", "Sin BassBoost nativo: se emula con la curva del ecualizador")
    fun dStrength(s: Int) = tr("Strength $s/1000", "Fuerza $s/1000")
    val dVirtUnsupported = tr("The device can't adjust the virtualizer strength", "El dispositivo no permite ajustar la fuerza del virtualizador")
    fun dVirtStrength(s: Int) = tr("Strength $s/1000 (virtualizer, not positional 3D)", "Fuerza $s/1000 (virtualizador, no 3D posicional)")

    // ---- Notificación del servicio ----
    val channelName = tr("Audio engine", "Motor de audio")
    val channelDescription = tr("Background audio processing status", "Estado del procesamiento de audio en segundo plano")
    val notifStarting = tr("Starting…", "Iniciando…")
    val notifPaused = tr("Paused: original sound", "En pausa: sonido original")
    val notifStandby = tr("Standby: no playback", "En espera: sin reproducción")
    val notifWaiting = tr("Ready: waiting for an audio session", "Listo: esperando una sesión de audio")
    fun notifActive(n: Int) = tr("Effects on $n session(s)", "Efectos en $n sesión(es)")
    val notifPause = tr("Pause", "Pausar")
    val notifResume = tr("Resume", "Reanudar")
    val notifStop = tr("Stop", "Detener")

    companion object {
        private val cache = AppLanguage.entries.associateWith { AppStrings(it) }
        fun of(lang: AppLanguage): AppStrings = cache.getValue(lang)
    }
}
