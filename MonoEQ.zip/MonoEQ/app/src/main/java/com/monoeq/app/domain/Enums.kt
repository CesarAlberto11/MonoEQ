package com.monoeq.app.domain

/** Cómo se engancha el motor al audio del sistema. */
enum class CoverageMode(val label: String, val description: String) {
    SESSIONS(
        "Sesiones de apps (recomendado)",
        "Aplica los efectos a las sesiones de audio que cada app anuncia a Android. Funciona con Spotify, " +
            "muchos reproductores y apps que respetan el ecualizador del sistema."
    ),
    GLOBAL(
        "Mezcla global (sesión 0)",
        "Intenta aplicar los efectos a toda la mezcla de salida. Android la marcó como obsoleta desde la versión 10 " +
            "y muchos dispositivos la ignoran. Usa la prueba de Diagnóstico para comprobarlo."
    ),
    BOTH(
        "Ambos (puede duplicar el efecto)",
        "Activa los dos métodos. Si tu dispositivo respeta la sesión global, el ecualizador se aplicaría dos veces."
    );

    val usesGlobal get() = this != SESSIONS
    val usesSessions get() = this != GLOBAL
}

enum class RouteType(val label: String) {
    SPEAKER("Altavoz"),
    WIRED("Auriculares con cable"),
    USB("Audio USB"),
    BLUETOOTH("Bluetooth"),
    UNKNOWN("Desconocida");

    val isExternal get() = this == WIRED || this == USB || this == BLUETOOTH
}

enum class VisualizerMode(val label: String) { BARS("Barras"), CURVE("Curva"), METER("Medidor") }

enum class AccentChoice(val label: String, val argb: Long) {
    WHITE("Blanco", 0xFFFFFFFF),
    STEEL("Acero", 0xFF9DB3CF),
    SAGE("Salvia", 0xFF9DBFA8),
    AMBER("Ámbar", 0xFFCDB07A),
    ROSE("Rosa", 0xFFC9A0AF)
}

enum class ReverbPreset(val label: String) {
    OFF("Desactivada"),
    SMALL_ROOM("Sala pequeña"),
    MEDIUM_ROOM("Sala media"),
    LARGE_ROOM("Sala grande"),
    MEDIUM_HALL("Salón medio"),
    LARGE_HALL("Salón grande"),
    PLATE("Plate")
}
