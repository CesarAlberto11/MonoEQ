package com.monoeq.app

import com.monoeq.app.domain.AudioParams
import com.monoeq.app.domain.Balance
import com.monoeq.app.domain.Bands
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.Profile
import com.monoeq.app.domain.ResponseCurve
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioParamsTest {
    @Test
    fun sanitizedClampsAndFixesSize() {
        val p = AudioParams(bands = listOf(99f, -99f, Float.NaN), bassDb = 50f, balance = 5f, bassBoost = 2f).sanitized()
        assertEquals(Bands.COUNT, p.bands.size)
        assertEquals(Bands.USER_MAX_DB, p.bands[0], 0f)
        assertEquals(Bands.USER_MIN_DB, p.bands[1], 0f)
        assertEquals(0f, p.bands[2], 0f)
        assertEquals(0f, p.bands[9], 0f)
        assertEquals(10f, p.bassDb, 0f)
        assertEquals(1f, p.balance, 0f)
        assertEquals(1f, p.bassBoost, 0f)
    }

    @Test
    fun jsonRoundTripKeepsEveryBuiltInProfile() {
        BuiltInProfiles.all.forEach { profile ->
            val back = AudioParams.fromJson(JSONObject(profile.params.toJson().toString()))
            assertEquals(profile.name, profile.params, back)
        }
    }

    @Test
    fun corruptJsonFallsBackToSafeValues() {
        val p = AudioParams.fromJson(JSONObject("""{"bands":[1,"x"],"bassDb":"abc","reverb":"NOPE"}"""))
        assertEquals(Bands.COUNT, p.bands.size)
        assertEquals(0f, p.bassDb, 0f)
        assertEquals(com.monoeq.app.domain.ReverbPreset.OFF, p.reverb)
    }

    @Test
    fun headroomCompensatesBoost() {
        val p = AudioParams(bands = List(Bands.COUNT) { if (it == 0) 6f else 0f })
        val gains = p.effectiveBandGains(false)
        assertEquals(-6f, p.effectivePreampDb(gains), 1e-4f)
        assertEquals(0f, p.copy(autoHeadroom = false).effectivePreampDb(gains), 1e-4f)
    }

    @Test
    fun toneControlsAffectExpectedRegions() {
        val gains = AudioParams(bassDb = 6f).effectiveBandGains(false)
        assertEquals(6f, gains[0], 1e-3f)
        assertEquals(0f, gains[9], 1e-3f)
        val treble = AudioParams(trebleDb = 6f).effectiveBandGains(false)
        assertEquals(0f, treble[0], 1e-3f)
        assertEquals(6f, treble[9], 1e-3f)
    }

    @Test
    fun effectiveGainsNeverExceedEngineLimit() {
        val p = AudioParams(bands = List(Bands.COUNT) { 12f }, bassDb = 10f, midDb = 10f, trebleDb = 10f, vocalClarity = 1f, bassBoost = 1f).sanitized()
        p.effectiveBandGains(true).forEach { assertTrue(it <= Bands.ENGINE_LIMIT_DB && it >= -Bands.ENGINE_LIMIT_DB) }
    }

    @Test
    fun balanceAttenuatesOnlyTheOppositeChannel() {
        assertEquals(0f to 0f, Balance.gainsDb(0f))
        val (l, r) = Balance.gainsDb(1f)
        assertEquals(-60f, l, 0f)
        assertEquals(0f, r, 0f)
        val (l2, r2) = Balance.gainsDb(-0.5f)
        assertEquals(0f, l2, 0f)
        assertTrue(r2 < -5f && r2 > -7f)
    }

    @Test
    fun responseCurvePassesThroughControlPoints() {
        val gains = floatArrayOf(1f, 2f, 3f, 4f, 5f, 6f, 7f, 8f, 9f, 10f)
        Bands.centersHz.forEachIndexed { i, f -> assertEquals(gains[i], ResponseCurve.gainAt(Bands.centersHz, gains, f), 1e-3f) }
        assertEquals(1f, ResponseCurve.gainAt(Bands.centersHz, gains, 20f), 0f)
        assertEquals(10f, ResponseCurve.gainAt(Bands.centersHz, gains, 20000f), 0f)
    }

    @Test
    fun builtInProfilesAreValid() {
        assertEquals(13, BuiltInProfiles.all.size)
        assertEquals(BuiltInProfiles.all.size, BuiltInProfiles.all.map { it.id }.toSet().size)
        BuiltInProfiles.all.forEach { assertEquals(it.name, it.params.sanitized(), it.params) }
    }

    @Test
    fun customProfilesSerializeAndRejectGarbage() {
        val list = listOf(Profile("custom_1", "Mi perfil", AudioParams(bassDb = 3f)))
        val back = Profile.listFromJson(Profile.listToJson(list))
        assertEquals(1, back.size)
        assertEquals("Mi perfil", back[0].name)
        assertEquals(3f, back[0].params.bassDb, 0f)
        assertTrue(Profile.listFromJson("esto no es json").isEmpty())
        assertEquals("a b", Profile.cleanName("   a    b  "))
        assertNotNull(Profile.newId())
    }

    @Test
    fun dynamicsBandEdgesAreAscending() {
        for (i in 1 until Bands.COUNT) assertTrue(Bands.upperEdgesHz[i] > Bands.upperEdgesHz[i - 1])
    }
}
