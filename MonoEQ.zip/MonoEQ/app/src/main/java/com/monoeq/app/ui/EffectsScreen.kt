package com.monoeq.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.audio.AudioController
import com.monoeq.app.domain.ReverbPreset
import kotlin.math.roundToInt

private fun pct(v: Float) = "${(v * 100f).roundToInt()} %"

@Composable
fun EffectsScreen(controller: AudioController) {
    val t = LocalStrings.current
    val params by controller.params.collectAsStateWithLifecycle()
    val engine by controller.engine.state.collectAsStateWithLifecycle()
    val bypass by controller.userBypass.collectAsStateWithLifecycle()
    val caps = engine.capabilities

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader(t.effectsTitle, t.effectsSubtitle)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton(t.pillCompare, bypass, { controller.setBypass(!bypass) }, enabled = engine.running)
        }
        if (caps == null) InfoText(t.capsUnknown)

        MonoCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RoundToggle(t.toggleBass, t.toggleBassCaption, params.bassBoost > 0f, {
                    controller.updateParams { it.copy(bassBoost = if (it.bassBoost > 0f) 0f else 0.5f) }
                })
                RoundToggle(t.toggleVocal, t.toggleVocalCaption, params.vocalClarity > 0f, {
                    controller.updateParams { it.copy(vocalClarity = if (it.vocalClarity > 0f) 0f else 0.5f) }
                })
                RoundToggle(t.toggleReverb, t.toggleReverbCaption, params.reverb != ReverbPreset.OFF, {
                    controller.updateParams { it.copy(reverb = if (it.reverb != ReverbPreset.OFF) ReverbPreset.OFF else ReverbPreset.MEDIUM_HALL) }
                }, enabled = caps?.reverb != false)
                RoundToggle(t.toggleSpatial, t.toggleSpatialCaption, params.stereoWidth > 0f, {
                    controller.updateParams { it.copy(stereoWidth = if (it.stereoWidth > 0f) 0f else 0.5f) }
                }, enabled = caps?.virtualizer != false)
            }
        }

        MonoCard(title = t.cardBassVoice) {
            MonoSlider(t.sliderBassBoost, pct(params.bassBoost), params.bassBoost, { v -> controller.updateParams { it.copy(bassBoost = v) } }, 0f..1f)
            if (caps?.bassBoostNative == false) InfoText(t.bassEmulatedNote)
            MonoSlider(t.sliderVocal, pct(params.vocalClarity), params.vocalClarity, { v -> controller.updateParams { it.copy(vocalClarity = v) } }, 0f..1f, bigKnob = true)
            InfoText(t.vocalNote)
        }

        MonoCard(title = t.cardSpace) {
            MonoSlider(
                t.sliderStereo, pct(params.stereoWidth), params.stereoWidth,
                { v -> controller.updateParams { it.copy(stereoWidth = v) } }, 0f..1f,
                enabled = caps?.virtualizer != false,
            )
            InfoText(t.stereoNote)
            if (caps?.virtualizer == false) InfoText(t.virtualizerMissing)
            CapsLabel(t.labelReverb)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReverbPreset.entries.forEach { preset ->
                    PillButton(t.reverbName(preset), params.reverb == preset, { controller.updateParams { it.copy(reverb = preset) } }, enabled = caps?.reverb != false)
                }
            }
            InfoText(if (caps?.reverb == false) t.reverbMissing else t.reverbNote)
        }

        MonoCard(
            title = t.cardDynamics,
            trailing = {
                PillButton(
                    t.pillLimiter, params.limiterEnabled,
                    { controller.updateParams { it.copy(limiterEnabled = !it.limiterEnabled) } },
                    enabled = caps?.limiter != false,
                )
            },
        ) {
            InfoText(t.limiterNote)
            if (params.limiterEnabled) {
                MonoSlider(t.sliderThreshold, formatDb(params.limiterThresholdDb), params.limiterThresholdDb, { v -> controller.updateParams { it.copy(limiterThresholdDb = v) } }, -24f..0f)
            }
            if (caps?.limiter == false) InfoText(t.limiterMissing)
        }
    }
}
