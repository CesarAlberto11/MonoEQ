package com.monoeq.app.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** FFT radix-2 con ventana de Hann. [n] debe ser potencia de dos. */
class Fft(val n: Int) {
    init { require(n >= 2 && (n and (n - 1)) == 0) { "n debe ser potencia de dos" } }

    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { (-sin(2.0 * PI * it / n)).toFloat() }
    private val window = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
    private val re = FloatArray(n)
    private val im = FloatArray(n)

    fun transform(real: FloatArray, imag: FloatArray) {
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = real[i]; real[i] = real[j]; real[j] = tr
                val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2
            val step = n / len
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = sinT[k * step]
                    val a = i + k
                    val b = a + half
                    val vr = real[b] * wr - imag[b] * wi
                    val vi = real[b] * wi + imag[b] * wr
                    real[b] = real[a] - vr; imag[b] = imag[a] - vi
                    real[a] = real[a] + vr; imag[a] = imag[a] + vi
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** Devuelve n/2 magnitudes en dBFS (0 dB = seno de amplitud completa). */
    fun magnitudeDbFs(samples: FloatArray): FloatArray {
        for (i in 0 until n) { re[i] = samples[i] * window[i]; im[i] = 0f }
        transform(re, im)
        val norm = n / 4f
        return FloatArray(n / 2) { k ->
            val mag = sqrt(re[k] * re[k] + im[k] * im[k]) / norm
            20f * log10(max(mag, 1e-6f))
        }
    }
}
