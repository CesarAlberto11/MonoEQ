package com.monoeq.app.domain

import kotlin.math.sqrt

object Bands {
    const val COUNT = 10
    val centersHz = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
    val labels = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

    const val USER_MIN_DB = -12f
    const val USER_MAX_DB = 12f

    /** Límite de seguridad tras sumar tono, claridad vocal y emulación de graves. */
    const val ENGINE_LIMIT_DB = 15f

    /** Frecuencia superior de cada banda (media geométrica entre centros) para DynamicsProcessing. */
    val upperEdgesHz = FloatArray(COUNT) { i ->
        if (i == COUNT - 1) 20000f else sqrt(centersHz[i] * centersHz[i + 1])
    }
}
