@file:OptIn(kotlinx.coroutines.FlowPreview::class)

package com.monoeq.app.audio

import android.content.Context
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.os.Handler
import android.os.Looper
import com.monoeq.app.data.AppSettings
import com.monoeq.app.data.ProfileRepository
import com.monoeq.app.data.SettingsRepository
import com.monoeq.app.domain.AppLanguage
import com.monoeq.app.domain.AudioParams
import com.monoeq.app.domain.BuiltInProfiles
import com.monoeq.app.domain.CoverageMode
import com.monoeq.app.domain.Profile
import com.monoeq.app.domain.RouteType
import com.monoeq.app.i18n.AppStrings
import com.monoeq.app.service.ServiceLauncher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.updateAndGet
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PlaybackState { UNKNOWN, IDLE, PLAYING }

/**
 * Orquestador de la app: une ajustes persistentes, perfiles, motor de efectos, sesiones de audio,
 * salida activa, analizador y señal de prueba. Vive mientras viva el proceso (lo comparten UI y servicio).
 */
class AudioController(
    private val app: Context,
    private val settingsRepo: SettingsRepository,
    private val profileRepo: ProfileRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val engine = EqEngine(app)
    val analyzer = SpectrumAnalyzer()
    val testSignal = TestSignalPlayer(app)

    private val _settings = MutableStateFlow<AppSettings?>(null)
    val settings: StateFlow<AppSettings?> = _settings.asStateFlow()

    private val _params = MutableStateFlow(AudioParams())
    val params: StateFlow<AudioParams> = _params.asStateFlow()

    val customProfiles: StateFlow<List<Profile>> =
        profileRepo.profiles.stateIn(scope, SharingStarted.Eagerly, emptyList())

    /** Textos en el idioma elegido (inglés por defecto). */
    val strings: StateFlow<AppStrings> = _settings
        .map { AppStrings.of(it?.language ?: AppLanguage.EN) }
        .distinctUntilChanged()
        .stateIn(scope, SharingStarted.Eagerly, AppStrings.of(AppLanguage.EN))

    private val _userBypass = MutableStateFlow(false)
    val userBypass: StateFlow<Boolean> = _userBypass.asStateFlow()
    private val _routePaused = MutableStateFlow(false)

    /** Bypass real enviado al motor: pausa manual o pausa por salida desconectada. */
    val effectiveBypass: StateFlow<Boolean> =
        combine(_userBypass, _routePaused) { a, b -> a || b }.stateIn(scope, SharingStarted.Eagerly, false)

    private val _route = MutableStateFlow(RouteInfo(RouteType.UNKNOWN, ""))
    val route: StateFlow<RouteInfo> = _route.asStateFlow()

    private val _playback = MutableStateFlow(PlaybackState.UNKNOWN)
    val playback: StateFlow<PlaybackState> = _playback.asStateFlow()

    private val _sessions = MutableStateFlow<List<AudioSessionInfo>>(emptyList())
    val sessions: StateFlow<List<AudioSessionInfo>> = _sessions.asStateFlow()

    private val _serviceActive = MutableStateFlow(false)
    val serviceActive: StateFlow<Boolean> = _serviceActive.asStateFlow()

    private var routeMonitor: AudioRouteMonitor? = null
    private var playbackCallback: AudioManager.AudioPlaybackCallback? = null
    private var playbackAudioManager: AudioManager? = null
    private var idleJob: Job? = null

    init {
        scope.launch {
            settingsRepo.settings.collect { s ->
                if (_settings.value == null) _params.value = s.params.sanitized()
                _settings.value = s
            }
        }
        // Guardado automático de los ajustes de sonido (con retardo para no escribir en cada movimiento).
        scope.launch {
            _params.drop(1).debounce(400).collect { p -> settingsRepo.update { it.copy(params = p) } }
        }
        scope.launch { _settings.filterNotNull().map { it.coverage }.distinctUntilChanged().collect { engine.setCoverage(it) } }
        scope.launch { _settings.filterNotNull().map { it.smoothing }.distinctUntilChanged().collect { analyzer.smoothing = it } }
        scope.launch { _settings.filterNotNull().map { it.idleRelease }.distinctUntilChanged().collect { reevaluateIdle() } }
        scope.launch { _settings.filterNotNull().map { it.pauseOnDisconnect }.distinctUntilChanged().collect { updateRoutePause() } }
        scope.launch { effectiveBypass.collect { engine.setBypass(it) } }
        scope.launch { strings.collect { engine.setStrings(it) } }
    }

    // ---------- Servicio ----------

    fun onServiceCreated(service: Context) {
        scope.launch {
            val s = settings.filterNotNull().first()
            _serviceActive.value = true
            engine.start(_params.value, s.coverage, effectiveBypass.value)
            _sessions.value.forEach { engine.onSessionOpened(it) }
            withContext(Dispatchers.Main) { startMonitors(service) }
        }
    }

    fun onServiceDestroyed() {
        _serviceActive.value = false
        idleJob?.cancel()
        stopTest()
        analyzer.stop()
        stopMonitors()
        engine.stop()
    }

    fun setEngineEnabled(ctx: Context, enabled: Boolean) {
        persistEngineEnabled(enabled)
        if (enabled) ServiceLauncher.start(ctx) else ServiceLauncher.stop(ctx)
    }

    fun persistEngineEnabled(enabled: Boolean) {
        scope.launch { settingsRepo.update { it.copy(engineEnabled = enabled) } }
    }

    fun setBypass(value: Boolean) { _userBypass.value = value }

    // ---------- Parámetros y perfiles ----------

    fun updateParams(transform: (AudioParams) -> AudioParams) {
        val p = _params.updateAndGet { transform(it).sanitized() }
        engine.updateParams(p)
    }

    fun resetParams() {
        applyParams(AudioParams())
        scope.launch { settingsRepo.update { it.copy(activeProfileId = BuiltInProfiles.NORMAL_ID) } }
    }

    private fun applyParams(p: AudioParams) {
        val clean = p.sanitized()
        _params.value = clean
        engine.updateParams(clean)
    }

    fun allProfiles(): List<Profile> = BuiltInProfiles.all + customProfiles.value

    fun applyProfile(id: String) {
        val profile = allProfiles().firstOrNull { it.id == id } ?: return
        applyParams(profile.params)
        scope.launch { settingsRepo.update { it.copy(activeProfileId = id) } }
    }

    fun saveCurrentAsProfile(name: String): Boolean {
        val clean = Profile.cleanName(name)
        if (clean.isEmpty() || customProfiles.value.size >= Profile.MAX_CUSTOM) return false
        val profile = Profile(Profile.newId(), clean, _params.value)
        scope.launch {
            profileRepo.upsert(profile)
            settingsRepo.update { it.copy(activeProfileId = profile.id) }
        }
        return true
    }

    fun updateProfileFromCurrent(id: String) {
        val current = customProfiles.value.firstOrNull { it.id == id } ?: return
        scope.launch { profileRepo.upsert(current.copy(params = _params.value)) }
    }

    fun renameProfile(id: String, name: String) {
        val clean = Profile.cleanName(name)
        val current = customProfiles.value.firstOrNull { it.id == id } ?: return
        if (clean.isEmpty()) return
        scope.launch { profileRepo.upsert(current.copy(name = clean)) }
    }

    fun duplicateProfile(id: String) {
        val source = allProfiles().firstOrNull { it.id == id } ?: return
        if (customProfiles.value.size >= Profile.MAX_CUSTOM) return
        val t = strings.value
        val copy = Profile(Profile.newId(), Profile.cleanName(t.profileName(source) + t.copySuffix), source.params)
        scope.launch { profileRepo.upsert(copy) }
    }

    fun deleteProfile(id: String) {
        scope.launch {
            profileRepo.delete(id)
            settingsRepo.update { s ->
                s.copy(
                    activeProfileId = if (s.activeProfileId == id) BuiltInProfiles.NORMAL_ID else s.activeProfileId,
                    routeProfiles = s.routeProfiles.filterValues { it != id },
                )
            }
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        scope.launch { settingsRepo.update(transform) }
    }

    // ---------- Sesiones de audio anunciadas por las apps ----------

    fun onSessionOpened(sessionId: Int, packageName: String?, contentType: Int) {
        if (sessionId <= 0) return
        val info = AudioSessionInfo(sessionId, packageName, resolveLabel(packageName), contentType)
        _sessions.update { (it.filterNot { s -> s.sessionId == sessionId } + info).takeLast(12) }
        engine.onSessionOpened(info)
        idleJob?.cancel()
    }

    fun onSessionClosed(sessionId: Int) {
        _sessions.update { it.filterNot { s -> s.sessionId == sessionId } }
        engine.onSessionClosed(sessionId)
    }

    private fun resolveLabel(pkg: String?): String {
        if (pkg.isNullOrEmpty()) return "App desconocida"
        return try {
            val pm = app.packageManager
            @Suppress("DEPRECATION")
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    // ---------- Salida de audio y reproducción ----------

    private fun startMonitors(ctx: Context) {
        stopMonitors()
        routeMonitor = AudioRouteMonitor(ctx) { onRouteChanged(it) }.also { it.start() }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val cb = object : AudioManager.AudioPlaybackCallback() {
            override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) {
                onPlaybackCount(configs?.size ?: 0)
            }
        }
        am.registerAudioPlaybackCallback(cb, Handler(Looper.getMainLooper()))
        playbackCallback = cb
        playbackAudioManager = am
        onPlaybackCount(am.activePlaybackConfigurations?.size ?: 0)
    }

    private fun stopMonitors() {
        routeMonitor?.stop()
        routeMonitor = null
        playbackCallback?.let { cb -> try { playbackAudioManager?.unregisterAudioPlaybackCallback(cb) } catch (_: Exception) { } }
        playbackCallback = null
    }

    private fun onRouteChanged(r: RouteInfo) {
        _route.value = r
        updateRoutePause()
        val s = _settings.value ?: return
        if (!s.autoProfile) return
        val key = when (r.type) {
            RouteType.WIRED, RouteType.USB -> RouteType.WIRED
            RouteType.BLUETOOTH -> RouteType.BLUETOOTH
            RouteType.SPEAKER -> RouteType.SPEAKER
            else -> return
        }
        val id = s.routeProfiles[key]
        if (!id.isNullOrEmpty() && id != s.activeProfileId) applyProfile(id)
    }

    private fun updateRoutePause() {
        val s = _settings.value
        _routePaused.value = s != null && s.pauseOnDisconnect && _route.value.type == RouteType.SPEAKER
    }

    private fun onPlaybackCount(count: Int) {
        _playback.value = if (count > 0) PlaybackState.PLAYING else PlaybackState.IDLE
        reevaluateIdle()
    }

    private fun reevaluateIdle() {
        idleJob?.cancel()
        val idleRelease = _settings.value?.idleRelease == true
        if (!idleRelease || _playback.value != PlaybackState.IDLE) {
            engine.setSuspended(false)
            return
        }
        idleJob = scope.launch {
            delay(IDLE_DELAY_MS)
            engine.setSuspended(true)
        }
    }

    // ---------- Diagnóstico, espectro y señal de prueba ----------

    fun runSelfTest() = engine.runSelfTest(_params.value)

    /** Fuentes disponibles para el espectro. La UI traduce los nombres de GLOBAL y TEST. */
    fun spectrumSources(): List<SpectrumSource> = buildList {
        add(SpectrumSource(EqEngine.GLOBAL_SESSION, SourceKind.GLOBAL, ""))
        _sessions.value.forEach { add(SpectrumSource(it.sessionId, SourceKind.APP, it.label)) }
        if (testSignal.running.value) add(SpectrumSource(testSignal.sessionId, SourceKind.TEST, ""))
    }

    fun autoSpectrumSession(): Int =
        (if (testSignal.running.value) testSignal.sessionId else null)
            ?: _sessions.value.lastOrNull()?.sessionId
            ?: EqEngine.GLOBAL_SESSION

    fun startSpectrum(sessionId: Int?) = analyzer.start(app, sessionId ?: autoSpectrumSession())
    fun stopSpectrum() = analyzer.stop()

    /** Reproduce ruido rosa en una sesión propia. Con [withEffects] aplica la cadena de efectos a esa sesión. */
    fun startTest(withEffects: Boolean): Boolean {
        if (!_serviceActive.value) return false
        val id = testSignal.start()
        if (withEffects) engine.addTestSession(id) else engine.removeTestSession()
        return true
    }

    fun stopTest() {
        testSignal.stop()
        engine.removeTestSession()
    }

    companion object {
        private const val IDLE_DELAY_MS = 20_000L
    }
}
