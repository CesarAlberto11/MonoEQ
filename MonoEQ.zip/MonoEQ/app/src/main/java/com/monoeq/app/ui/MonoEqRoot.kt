package com.monoeq.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.monoeq.app.R
import com.monoeq.app.audio.AudioController
import com.monoeq.app.data.AppSettings
import com.monoeq.app.domain.AccentChoice

private data class NavTab(val label: String, val icon: Int)

@Composable
fun MonoEqRoot(controller: AudioController) {
    val settings by controller.settings.collectAsStateWithLifecycle()
    val s = settings
    MonoEqTheme(accent = Color(s?.accent?.argb ?: AccentChoice.WHITE.argb)) {
        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            if (s != null) MainScaffold(controller, s)
        }
    }
}

@Composable
private fun MainScaffold(controller: AudioController, settings: AppSettings) {
    val tabs = remember {
        listOf(
            NavTab("EQ", R.drawable.ic_eq),
            NavTab("Espectro", R.drawable.ic_spectrum),
            NavTab("Efectos", R.drawable.ic_effects),
            NavTab("Perfiles", R.drawable.ic_profiles),
            NavTab("Ajustes", R.drawable.ic_tune),
        )
    }
    var selected by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                tabs.forEachIndexed { i, tab ->
                    NavigationBarItem(
                        selected = selected == i,
                        onClick = { selected = i },
                        icon = { Icon(painterResource(tab.icon), contentDescription = tab.label) },
                        label = { Text(tab.label, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                            selectedTextColor = MaterialTheme.colorScheme.onSurface,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.outline,
                            unselectedTextColor = MaterialTheme.colorScheme.outline,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            Crossfade(targetState = selected, label = "tabs") { tab ->
                when (tab) {
                    0 -> EqualizerScreen(controller, settings)
                    1 -> VisualizerScreen(controller, settings)
                    2 -> EffectsScreen(controller)
                    3 -> ProfilesScreen(controller, settings)
                    else -> SettingsScreen(controller, settings)
                }
            }
        }
    }
}
