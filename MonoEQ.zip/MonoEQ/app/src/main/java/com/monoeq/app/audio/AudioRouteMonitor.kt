package com.monoeq.app.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.monoeq.app.domain.RouteType

/** [deviceName] es el nombre del producto si Android lo informa (puede estar vacío). */
data class RouteInfo(val type: RouteType, val deviceName: String)

/** Detecta la salida de audio activa (cable, USB, Bluetooth o altavoz) sin pedir permisos de Bluetooth. */
class AudioRouteMonitor(context: Context, private val onChange: (RouteInfo) -> Unit) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val callback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = onChange(currentRoute())
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = onChange(currentRoute())
    }

    fun start() {
        audioManager.registerAudioDeviceCallback(callback, handler)
        onChange(currentRoute())
    }

    fun stop() {
        try { audioManager.unregisterAudioDeviceCallback(callback) } catch (_: Exception) { }
    }

    fun currentRoute(): RouteInfo {
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        fun pick(type: RouteType) = outputs.firstOrNull { classify(it.type) == type }
        pick(RouteType.BLUETOOTH)?.let { return RouteInfo(RouteType.BLUETOOTH, it.productName?.toString().orEmpty()) }
        pick(RouteType.USB)?.let { return RouteInfo(RouteType.USB, it.productName?.toString().orEmpty()) }
        pick(RouteType.WIRED)?.let { return RouteInfo(RouteType.WIRED, "") }
        pick(RouteType.SPEAKER)?.let { return RouteInfo(RouteType.SPEAKER, "") }
        return RouteInfo(RouteType.UNKNOWN, "")
    }

    private fun classify(type: Int): RouteType = when (type) {
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> RouteType.WIRED
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY -> RouteType.USB
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> RouteType.BLUETOOTH
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> RouteType.SPEAKER
        else -> when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && type == AudioDeviceInfo.TYPE_HEARING_AID -> RouteType.BLUETOOTH
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                (type == AudioDeviceInfo.TYPE_BLE_HEADSET || type == AudioDeviceInfo.TYPE_BLE_SPEAKER) -> RouteType.BLUETOOTH
            else -> RouteType.UNKNOWN
        }
    }
}
